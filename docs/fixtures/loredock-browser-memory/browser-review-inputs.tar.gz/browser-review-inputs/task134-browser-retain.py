"""Review stopped catalog copies and browser response retention without touching originals."""
from pathlib import Path
import hashlib
import importlib.util
import json
import shutil
import sqlite3
import subprocess

base = Path('/home/toshiba/aew')
repository = base / 'worktrees/task134-browser-memory'
source, output = base / 'task134-browser-first', base / 'task134-browser-retention'
output.mkdir()
spec = importlib.util.spec_from_file_location('assessment', repository / 'scripts/loredock-browser-memory/assess.py')
module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
inventory = module.inventory
before = inventory(source)
read = lambda file: json.loads(file.read_bytes())
sha = lambda raw: hashlib.sha256(raw).hexdigest()
inputs = read(base / 'task133-native-v1-first/run/inputs.json')
owner = read(source / 'result.json')
report = {'catalogs': [], 'originalChecks': 0, 'sourceFiles': 0, 'gitIdentities': 0,
          'httpResponses': 0, 'browserResponses': 0, 'sessionRedactions': 0,
          'realModelCalls': 0, 'controlledRuntimeCalls': 0, 'resourceQualification': False}
env = {'PATH': '/usr/bin:/bin', 'LC_ALL': 'C', 'GIT_CONFIG_NOSYSTEM': '1', 'GIT_CONFIG_GLOBAL': '/dev/null', 'GIT_OPTIONAL_LOCKS': '0'}
for name, files in inputs['corpus'].items():
    directory = base / 'task133-native-v1-first/run/sources' / name
    for key, ref in [('revision', 'HEAD'), ('tree', 'HEAD^{tree}')]:
        assert subprocess.check_output(['/usr/bin/git', 'rev-parse', ref], cwd=directory, env=env, text=True).strip() == inputs['sources']['revisions'][name][key]
    assert not subprocess.check_output(['/usr/bin/git', 'status', '--porcelain'], cwd=directory, env=env)
    report['gitIdentities'] += 1
    for file, text in files.items():
        assert (directory / file).read_bytes() == text.encode()
        report['sourceFiles'] += 1
for relative in owner['catalogRoots']:
    original, copied = source / relative, output / relative
    copied.parent.mkdir(parents=True, exist_ok=True); shutil.copytree(original, copied)
    assert inventory(original) == inventory(copied)
    db = sqlite3.connect('file:' + str(copied / 'loredock.db') + '?mode=ro', uri=True); db.row_factory = sqlite3.Row
    try:
        assert [tuple(row) for row in db.execute('PRAGMA integrity_check')] == [('ok',)]
        assert not list(db.execute('PRAGMA foreign_key_check'))
        rows = list(db.execute('SELECT a.*,w.witness,w.reviewedHash,w.purged FROM answer_attempts a JOIN answer_witnesses w ON w.answerId=a.id'))
        expected = 1 if relative == 'run/ready-and-saved/data' else 0
        assert len(rows) == db.execute('SELECT count(*) FROM answer_attempts').fetchone()[0] == expected
        for row in rows:
            assert row['status'] == 'succeeded' and row['purged'] == 0
            old = read(base / 'task133-native-v2-first/run' / ('snapshot-' + row['id'] + '.json'))
            assert row['context'] == old['contextJson'] and row['witness'] == old['witnessJson'] and row['reviewedHash'] == old['reviewedHash']
            context = json.loads(row['context'])
            for span in context['spans']:
                text = inputs['corpus'][span['sourceName']][span['path']]
                assert span['text'] == '\n'.join(text.splitlines()[span['startLine'] - 1:span['endLine']])
                assert span['revision'] == inputs['sources']['revisions'][span['sourceName']]['revision']
                report['originalChecks'] += 1
        report['catalogs'].append({'relative': relative, 'answers': len(rows), 'integrity': 'ok', 'savedBytesUnchanged': True})
    finally: db.close()
for file in source.rglob('requests.jsonl'):
    requests, responses = {}, set()
    for row in map(json.loads, file.read_text().splitlines()):
        if row['event'] == 'request':
            assert row['id'] not in requests and row['route'] != '/prepared-answers'
            requests[row['id']] = row
        else:
            assert row['event'] == 'response' and row['id'] in requests and row['id'] not in responses
            responses.add(row['id']); raw = (file.parent / (row['id'] + '.json')).read_bytes()
            if requests[row['id']]['route'] == '/session':
                assert json.loads(raw)['token'] == '[removed-session-token]'; report['sessionRedactions'] += 1
            else: assert len(raw) == row['bytes']
            report['httpResponses'] += 1
    assert set(requests) == responses
for file in source.rglob('events.jsonl'):
    if file.parent.name != 'browser': continue
    for row in map(json.loads, file.read_text().splitlines()):
        if row['event'] == 'protocol' and row['value']['method'] == 'Network.requestWillBeSent':
            request = row['value']['params']['request']; assert not request['url'].endswith('/prepared-answers')
        if row['event'] != 'api-body': continue
        raw = (file.parent / row['file']).read_bytes()
        assert len(raw) == row['retainedBytes'] and sha(raw) == row['retainedSha256']
        if row['redacted']:
            assert json.loads(raw)['token'] == '[removed-session-token]'; report['sessionRedactions'] += 1
        else: assert sha(raw) == row['rawSha256'] and len(raw) == row['bytes']
        report['browserResponses'] += 1
assert inventory(source) == before
report.update(rawEntries=len(before), rawUnchanged=True)
(output / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
