from pathlib import Path
import json
base = Path('/home/toshiba/aew')
helper = base / 'task128-kernel-archive.py'
exec(helper.read_text().split("for name in ['core', 'browser', 'crash', 'interruption']:")[0])
repo = base / 'worktrees/task134-browser-memory'
out = repo / 'docs/fixtures/loredock-browser-memory'
assert not (out / 'records.json').exists()
records = {'schemaVersion': 'ordinary-browser-memory-attribution/1', 'base': '1a03c04b03bfa61267d8f631ffb0b17df06470da',
    'retainedCode': 'eae8212', 'firstCode': 'bf89725', 'assessmentCode': '4eab86b',
    'applicationChanged': False, 'modelCalls': 0, 'reservedFamilyReads': 0,
    'resourceQualification': False, 'trees': [], 'logs': []}
for name in ['browser-retained-first', 'browser-first', 'browser-first-inputs', 'browser-assessment-first', 'browser-retention']:
    tree(name, base / ('task134-' + name))
for name in ['browser-install', 'browser-build', 'browser-retained-first', 'browser-first',
             'browser-assessment-first', 'browser-retain-first', 'browser-role-tests-first', 'browser-script-tests-first']:
    log(name, base / ('task134-' + name + '.log'))
for event in ['push', 'pr']:
    log('accepted-native-format-ci-' + event, base / ('task133-native-ci-' + event + '-final.log'))
inputs = base / 'task134-browser-review-inputs'; inputs.mkdir()
for file in [helper, Path(__file__), base / 'task134-browser-static.py', base / 'task134-browser-retain.py',
             base / 'task134-browser-first-launch.py', base / 'task134-integration-handoff.json',
             base / 'task133-integration-handoff.json', repo / 'scripts/loredock-browser-memory/assess.py']:
    (inputs / file.name).write_bytes(file.read_bytes())
tree('browser-review-inputs', inputs)
records['retention'] = json.loads((base / 'task134-browser-retention/result.json').read_bytes())
(out / 'records.json').write_text(json.dumps(records, indent=2) + '\n')
print(json.dumps({'trees': len(records['trees']), 'entries': sum(row['entries'] for row in records['trees']),
    'logs': len(records['logs']), 'resourceQualification': False}, indent=2))
