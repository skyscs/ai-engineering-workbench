from pathlib import Path
import json

base=Path('/home/toshiba/aew');helper=base/'task128-kernel-archive.py'
exec(helper.read_text().split("for name in ['core', 'browser', 'crash', 'interruption']:")[0])
repo=base/'worktrees/task128-network-cases';out=repo/'docs/fixtures/loredock-prepared-flow-network-cases'
out.mkdir(exist_ok=True)
accepted=json.loads((base/'task128-integration-handoff.json').read_text())['latestAccepted']
assert accepted['pr']==144 and accepted['testsPerEvent']==982
records={'schemaVersion':'prepared-flow-network-cases-development/1','resourceQualification':False,
         'modelCalls':0,'reservedFamilyReads':0,'trees':[],'logs':[],'acceptedCancellation':accepted,'screenshots':[]}
tree('network-cases-first',base/'task128-network-cases-first')
tree('network-cases-retention',base/'task128-network-cases-retention')
for name in ['network-cases-first','network-cases-install','network-cases-build',
             'network-cases-retention','network-cases-seal-check','cancel-reopen-ci-push','cancel-reopen-ci-pr']:
    log(name,base/('task128-'+name+'.log'))
inputs=base/'task128-network-cases-inputs';inputs.mkdir()
for source in [repo/'scripts/loredock-prepared-flow/network-cases.mjs',
               repo/'scripts/loredock-prepared-flow/network-cases-development.mjs',
               helper,base/'task128-network-cases-retention.py',Path(__file__)]:
    (inputs/source.name).write_bytes(source.read_bytes())
tree('network-cases-inputs',inputs)
for case,name in [('lost-admission','replayed-answer'),('question-edit','obsolete-context-hidden')]:
    source=base/'task128-network-cases-first/run'/case/'browser'/(name+'.png')
    raw=source.read_bytes();target=out/source.name
    with target.open('xb') as file:file.write(raw)
    records['screenshots'].append({'path':target.name,'source':str(source),'bytes':len(raw),'sha256':sha(raw)})
records['retention']=json.loads((base/'task128-network-cases-retention/result.json').read_text())
(out/'records.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps({'trees':len(records['trees']),'logs':len(records['logs']),'screenshots':len(records['screenshots'])},indent=2))
