from pathlib import Path
import hashlib
import json
import shutil
import sqlite3
import subprocess

base=Path('/home/toshiba/aew');root=base/'task128-network-cases-first';run=root/'run'
output=base/'task128-network-cases-retention';output.mkdir()
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def read(file):return json.loads(file.read_text())
def inventory(directory):
    result={}
    for p in sorted(directory.rglob('*')):
        if p.is_symlink():result[str(p.relative_to(directory))]={'kind':'symlink','target':str(p.readlink())}
        elif p.is_file():result[str(p.relative_to(directory))]={'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}
    return result
before=inventory(root);owner=read(root/'result.json');driver=read(run/'result.json')
assert owner['reason']=='driver-failure' and owner['driverExit']['exit']==1 and owner['errors']==[] and owner['survivors']==[]
assert driver['errors']==[] and [x['id'] for x in driver['cases']]==['cold-base','lost-admission','question-edit']
assert [x['metric'] for x in driver['baseMetricFailures']]==['rawIntervalGapMs']
report={'resourceQualification':False,'modelCalls':0,'reservedFamilyReads':0,'catalogs':[],
        'browsers':[],'httpBodies':0,'redactedSessions':0,'sourceRepositories':0}
sources=read(run/'sources.json')
for row in sources['originals']:
    raw=(run/'sources'/row['source']/row['path']).read_bytes()
    assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
for source,identity in sources['revisions'].items():
    actual=subprocess.check_output(['git','-c','core.hooksPath=/dev/null','rev-parse','HEAD','HEAD^{tree}'],
        cwd=run/'sources'/source,text=True,env={'PATH':'/usr/bin:/bin','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null'}).splitlines()
    assert actual==[identity['revision'],identity['tree']];report['sourceRepositories']+=1
for file in run.rglob('requests.jsonl'):
    requests={};responses=set()
    for line in file.read_text().splitlines():
        row=json.loads(line);key=row['id'];assert row['event']!='failure'
        if row['event']=='request':assert key not in requests;requests[key]=row
        if row['event']=='response':
            assert key in requests and key not in responses;responses.add(key)
            raw=(file.parent/(key+'.json')).read_bytes()
            if requests[key]['route']=='/session':assert json.loads(raw)['token']=='[removed-session-token]';report['redactedSessions']+=1
            else:assert len(raw)==row['bytes'];report['httpBodies']+=1
    assert set(requests)==responses
replay=read(run/'lost-admission/result.json');edit=read(run/'question-edit/result.json')
for name,value in [('lost-admission',replay),('question-edit',edit)]:
    case=run/name;assert value['errors']==[] and value['timingQualified'] is False and value['inputCheckpointUnchanged'] is True
    assert read(case/'controlled/process.json')['fault'] is True
    events=[json.loads(line)['value'] for line in (case/'browser/events.jsonl').read_text().splitlines() if json.loads(line)['event']=='protocol']
    requests={};completed=[];failed=[];preparations=[];admissions=[];reviews=[]
    for event in events:
        params=event['params']
        if event['method']=='Network.requestWillBeSent':
            request=params['request'];requests[params['requestId']]=request
            if request['url'].endswith('/api/question-preparations') and request['method']=='POST':preparations.append(json.loads(request['postData']))
            if request['url'].endswith('/api/prepared-answers') and request['method']=='POST':admissions.append(json.loads(request['postData']))
        if event['method'] in ['Network.loadingFinished','Network.loadingFailed']:
            request=requests.get(params['requestId'],{})
            if request.get('url','').startswith('http://127.0.0.1:4244/api/'):
                if event['method']=='Network.loadingFailed':failed.append({'url':request['url'],'error':params['errorText']});continue
                body=read(case/'browser'/('response-'+params['requestId'].replace('.','-')+'.json'))
                completed.append(params['requestId'])
                if request['url'].endswith('/api/session'):assert body['token']=='[removed-session-material]'
                if '/api/question-preparations/' in request['url'] and request['url'].endswith('/review'):reviews.append(body)
    assert len(preparations)==1 and len(reviews)==1 and reviews[0]['compact']['item']
    if name=='lost-admission':
        assert len(admissions)==2 and admissions[0]==admissions[1]==replay['admission']
        assert len(failed)==1 and failed[0]['url'].endswith('/api/prepared-answers')
        assert read(case/'lost-admission-release.json')['action']=='drop-after-server-response'
        assert read(case/'lost-admission-response.json')['id']==replay['saved']['value']['id']
        assert value['runtime']=={'prepares':1,'calls':1,'closed':1}
        assert replay['saved']['value']['context']==reviews[0]['context']
        assert replay['saved']['value']['nativeContext']==reviews[0]['compact']
        report['review']=reviews[0]
    else:
        assert admissions==[] and failed==[] and value['runtime']=={'prepares':0,'calls':0,'closed':0}
        assert value['lateResponseCompleted'] is True and value['dom']['contextInsertions']==0
        assert value['dom']['contextPresent'] is False and value['dom']['generatePresent'] is False
        captured=read(case/'late-question-request.json');assert captured['networkId'] in completed
        assert read(case/'late-question-response.json')==reviews[0]
        assert read(case/'late-question-release.json')['action']=='continue-original-response'
        assert value['cancelledPreparation']['value']['status']=='cancelled'
    samples=[json.loads(line) for line in (case/'browser/process-tree.jsonl').read_text().splitlines()]
    assert max(x['rssBytes'] for x in samples)==value['browser']['maxRssBytes']
    assert sum(not x['complete'] for x in samples)==value['browser']['incompleteMemorySamples']
    report['browsers'].append({'name':name,'completedApiBodies':len(completed),'failedApiRequests':failed,
        'preparations':len(preparations),'admissionPosts':len(admissions),
        'sampledRssBytes':value['browser']['maxRssBytes'],'incompleteSamples':value['browser']['incompleteMemorySamples']})
for checkpoint in [read(run/'base/result.json')['checkpoint'],replay['checkpoint']]:
    assert inventory(Path(checkpoint['data']))==checkpoint['files']
for original in sorted(run.rglob('loredock.db')):
    relative=original.parent.relative_to(run);copied=output/relative
    copied.parent.mkdir(parents=True,exist_ok=True);shutil.copytree(original.parent,copied)
    assert inventory(original.parent)==inventory(copied)
    db=sqlite3.connect('file:'+str(copied/'loredock.db')+'?mode=ro',uri=True)
    try:
        assert db.execute('PRAGMA integrity_check').fetchall()==[('ok',)] and db.execute('PRAGMA foreign_key_check').fetchall()==[]
        states=db.execute('SELECT status,count(*) FROM answer_attempts GROUP BY status').fetchall()
        assert db.execute('SELECT status,candidates FROM code_analyses').fetchall()==[('completed',5)]
        populated=relative.parts[0]=='lost-admission'
        assert states==([('succeeded',1)] if populated else [])
        assert db.execute('SELECT count(*) FROM answer_witnesses').fetchone()==(int(populated),)
        if populated:
            context,witness_raw,reviewed,purged=db.execute('SELECT a.context,w.witness,w.reviewedHash,w.purged FROM answer_attempts a JOIN answer_witnesses w ON a.id=w.answerId').fetchone()
            witness=json.loads(witness_raw);review=report['review'];request=read(run/'lost-admission/controlled/request-1.json')
            assert json.loads(context)==review['context'] and reviewed==review['reviewedHash'] and purged==0
            assert witness['prompt']==request['prompt'] and witness['compact']==review['compact']
            assert request['schema']['properties']['claims']['items']['properties']['evidenceIds']['items']['enum']==[x['id'] for x in review['context']['spans']]
        report['catalogs'].append({'source':str(original.parent),'copy':str(copied),'integrity':'ok','foreignKeyErrors':[],'answerStates':states})
    finally:db.close()
assert len(report['catalogs'])==5 and report['sourceRepositories']==4
assert inventory(root)==before
del report['review']
report.update(rawInputsUnchanged=True,entries=len(before),baseMetricFailures=driver['baseMetricFailures'])
(output/'result.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
