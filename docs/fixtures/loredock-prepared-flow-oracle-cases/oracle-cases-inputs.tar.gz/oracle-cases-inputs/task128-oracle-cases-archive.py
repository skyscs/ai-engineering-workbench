from pathlib import Path
import json
import re

base=Path('/home/toshiba/aew');helper=base/'task128-kernel-archive.py'
exec(helper.read_text().split("for name in ['core', 'browser', 'crash', 'interruption']:")[0])
repo=base/'worktrees/task128-oracle-cases';out=repo/'docs/fixtures/loredock-prepared-flow-oracle-cases';out.mkdir(exist_ok=True)
accepted=json.loads((base/'task128-integration-handoff.json').read_text())['latestAccepted'];assert accepted['pr']==150 and accepted['testsPerEvent']==984
records={'schemaVersion':'prepared-flow-oracle-cases-development/1','resourceQualification':False,'modelCalls':0,'reservedFamilyReads':0,'trees':[],'logs':[],'acceptedWorkerAccounting':accepted}
for name in ['oracle-cases-first','oracle-cases-retention']:tree(name,base/('task128-'+name))
for name in ['oracle-cases-first','oracle-cases-install','oracle-cases-build','oracle-cases-tests','oracle-cases-retention','oracle-cases-seal-check','worker-accounting-case-ci-push','worker-accounting-case-ci-pr']:log(name,base/('task128-'+name+'.log'))
testlog=(base/'task128-oracle-cases-tests.log').read_text()
for i,location in enumerate(re.findall(r'Retained oracle-input test: (/tmp/loredock-oracle-inputs-[A-Za-z0-9]+)',testlog)):tree('oracle-cases-test-'+str(i+1),Path(location))
inputs=base/'task128-oracle-cases-inputs';inputs.mkdir()
for source in [repo/'scripts/loredock-prepared-flow/oracle-case.mjs',repo/'scripts/loredock-prepared-flow/oracle-cases-development.mjs',repo/'scripts/loredock-prepared-flow/ordinary-oracles.mjs',repo/'scripts/loredock-prepared-flow/assess.mjs',repo/'scripts/tests/loredock-oracle-inputs.test.mjs',helper,base/'task128-oracle-cases-retention.py',Path(__file__)]:
    (inputs/source.name).write_bytes(source.read_bytes())
tree('oracle-cases-inputs',inputs)
records['retention']=json.loads((base/'task128-oracle-cases-retention/result.json').read_text())
(out/'records.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps({'trees':len(records['trees']),'logs':len(records['logs'])},indent=2))
