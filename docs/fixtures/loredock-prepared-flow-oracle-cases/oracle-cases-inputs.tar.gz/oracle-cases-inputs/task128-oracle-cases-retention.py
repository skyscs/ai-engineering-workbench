from pathlib import Path
import hashlib
import json
import shutil
import sqlite3
import subprocess

base=Path('/home/toshiba/aew');root=base/'task128-oracle-cases-first';run=root/'run'
output=base/'task128-oracle-cases-retention';output.mkdir()
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def read(file):return json.loads(file.read_text())
def inventory(directory):return {str(p.relative_to(directory)):{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(directory.rglob('*')) if p.is_file()}
before=inventory(root);owner=read(root/'result.json');driver=read(run/'result.json')
assert owner['reason']=='driver-failure' and owner['driverExit']['exit']==1 and owner['errors']==[] and owner['survivors']==[]
assert driver['errors']==[] and driver['notRun']==[] and len(driver['cases'])==10
assert [row['id'] for row in driver['cases'] if not row['passed']]==['D01-complete-path']
report={'resourceQualification':False,'modelCalls':0,'reservedFamilyReads':0,'catalogs':[],'httpBodies':0,'redactedSessions':0,'sourceGitIdentities':0,'preparations':0,'requiredQuotes':0}
for row in driver['cases']:
    assert row['errors']==[] and row['preparations']==1;report['preparations']+=row['preparations']
    directory=run/row['id'];sources=read(directory/'sources.json');inputs=read(directory/'case/inputs.json')
    for name,identity in sources['revisions'].items():
        source=directory/'sources'/name
        for key,ref in [('revision','HEAD'),('tree','HEAD^{tree}')]:
            assert subprocess.check_output(['git','-c','core.hooksPath=/dev/null','rev-parse',ref],cwd=source,text=True).strip()==identity[key]
        assert not subprocess.check_output(['git','-c','core.hooksPath=/dev/null','status','--porcelain'],cwd=source)
        report['sourceGitIdentities']+=1
    for original in sources['originals']:
        raw=(directory/'sources'/original['source']/original['path']).read_bytes();assert len(raw)==original['bytes'] and sha(raw)==original['sha256']
    for name in inputs['expected']['requiredOriginals']:
        reference=inputs['references'][name]
        assert any(span['sourceName']==reference['source'] and span['path']==reference['path'] and reference['quote'] in span['text'] for span in row['review']['context']['spans'])
        report['requiredQuotes']+=1
    if row['id']=='D01-complete-path':
        assert len(row['assessmentErrors'])==1 and row['assessmentErrors'][0]['code']=='ERR_ASSERTION'
        assert row['review']['compact']['item'] is None and row['review']['compact']['derivedBytes']==8368 and row['review']['compact']['reason']=='derived-size'
    else:assert row['assessmentErrors']==[]
    if row['id'] in ['D03-consumer-gap','D04-dynamic-topic']:
        item=row['review']['compact']['item'];assert item['omissions'][inputs['expected']['native']['requiredGap']]==1
        assert not {'event-delivery','dispatch-candidate'} & {edge[0] for edge in item['edges']}
    if row['id']=='D09-human-note':
        note=row['note'];assert note['provenance']=='human' and note['verification']=='unverified' and note['statement']==inputs['engineerNote']['text']
        assert any(note['statement']==n['statement'] and n['provenance']=='human' and n['verification']=='unverified' for n in row['review']['context']['review']['notes'])
        assert note['targetId']==row['noteTarget']['edge']['id'] and row['noteTarget']['edge']['kind']=='http-target'
        for name in inputs['noteTarget']['requiredOriginals']:
            reference=inputs['references'][name]
            assert any(original['sourceName']==reference['source'] and original['path']==reference['path'] and reference['quote'] in original['text'] for original in row['noteTarget']['originals'])
    if row['id']=='D07-no-analysis':
        checkpoint=row['catalogOnlyCheckpoint'];assert inventory(Path(checkpoint['data']))==checkpoint['files']
        assert row['review']['context']['buildId']==row['build']['id'] and row['build']['status']=='completed' and row['build']['published']
    process=read(directory/'case/production/process.json');assert all(process[key] is False for key in ['controlled','fault','accounting'])
    assert read(directory/'case/production/exit.json')['code']==0
for file in run.rglob('requests.jsonl'):
    pending={};responses=set();preparations=0
    for line in file.read_text().splitlines():
        row=json.loads(line);key=row['id'];assert row['event']!='failure'
        if row['event']=='request':
            assert key not in pending;pending[key]=row
            if row['method']=='POST' and row['route']=='/question-preparations':preparations+=1
        if row['event']=='response':
            assert key in pending and key not in responses and row['status']<400;responses.add(key)
            raw=(file.parent/(key+'.json')).read_bytes()
            if pending[key]['route']=='/session':assert json.loads(raw)['token']=='[removed-session-token]';report['redactedSessions']+=1
            else:assert len(raw)==row['bytes'];report['httpBodies']+=1
    assert set(pending)==responses and preparations==1
for original in sorted(run.rglob('loredock.db')):
    relative=original.parent.relative_to(run);copied=output/relative;copied.parent.mkdir(parents=True,exist_ok=True)
    shutil.copytree(original.parent,copied);assert inventory(original.parent)==inventory(copied)
    db=sqlite3.connect('file:'+str(copied/'loredock.db')+'?mode=ro',uri=True)
    try:
        assert db.execute('PRAGMA integrity_check').fetchall()==[('ok',)] and db.execute('PRAGMA foreign_key_check').fetchall()==[]
        assert db.execute('SELECT count(*) FROM answer_attempts').fetchone()==(0,)
        analyses=db.execute('SELECT count(*) FROM code_analyses').fetchone()[0]
        assert analyses==(0 if relative.parts[0]=='D07-no-analysis' else 1)
        report['catalogs'].append({'source':str(original.parent),'copy':str(copied),'integrity':'ok','foreignKeyErrors':[],'answers':0,'analyses':analyses})
    finally:db.close()
assert len(report['catalogs'])==11 and inventory(root)==before
report.update(rawInputsUnchanged=True,entries=len(before),passedPrerequisites=9,failedRequiredPositives=1)
(output/'result.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
