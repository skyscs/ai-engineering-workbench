CREATE TRIGGER owned_publish_at_admission AFTER INSERT ON answer_witnesses BEGIN
UPDATE project SET publishedBuildId='2b87d5a4-5ce4-4910-b254-9082285174e9' WHERE id=1;
END;
