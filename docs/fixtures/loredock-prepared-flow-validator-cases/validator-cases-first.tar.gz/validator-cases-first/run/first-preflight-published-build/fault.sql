CREATE TRIGGER owned_publish_at_admission AFTER INSERT ON answer_witnesses BEGIN
UPDATE project SET publishedBuildId='b54aaf9c-98cf-4b7f-9380-3479bad455a9' WHERE id=1;
END;
