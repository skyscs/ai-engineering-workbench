# Undisplayed context
This source participates in authority, without a displayed code node.
