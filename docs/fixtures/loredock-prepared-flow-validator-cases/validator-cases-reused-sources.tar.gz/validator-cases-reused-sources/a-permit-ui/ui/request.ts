export function requestPermit(tenant: string, permit: string) {
  return fetch("/permits/grants", { method: "POST", headers: { "X-Permit-Tenant": tenant }, body: JSON.stringify({ permit }) });
}
