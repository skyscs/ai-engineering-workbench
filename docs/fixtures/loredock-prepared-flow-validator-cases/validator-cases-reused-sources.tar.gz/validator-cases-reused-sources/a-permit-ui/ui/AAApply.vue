<script setup lang="ts">
import { requestPermit } from "./request";
const props = defineProps<{ tenant: string; permit: string }>();
const apply = () => requestPermit(props.tenant, props.permit);
</script>
<template><button @click="apply">Request permit</button></template>
