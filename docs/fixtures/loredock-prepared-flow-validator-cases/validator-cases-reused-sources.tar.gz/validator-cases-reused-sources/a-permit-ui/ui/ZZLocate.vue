<script setup lang="ts">
import { locatePermit } from "./missing";
const locate = () => locatePermit();
</script>
<template><button @click="locate">Locate permit</button></template>
