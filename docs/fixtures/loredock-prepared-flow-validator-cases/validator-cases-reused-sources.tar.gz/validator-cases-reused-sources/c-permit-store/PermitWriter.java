record PermitGranted(String tenant, String permit) {}
record TenantKey(String tenant) {}
interface MongoCollection { void replaceOne(TenantKey selector, PermitGranted document, boolean upsert); }
interface KafkaSubscriber { void subscribe(String topic, String group, PermitWriter handler); }
final class PermitWriter {
  private final MongoCollection collection;
  PermitWriter(MongoCollection collection) { this.collection = collection; }
  void start(KafkaSubscriber subscriber, String group) { subscriber.subscribe("permit.granted.v3", group, this); }
  void onMessage(PermitGranted event) {
    var selector = new TenantKey(event.tenant());
    collection.replaceOne(selector, event, true);
  }
}
