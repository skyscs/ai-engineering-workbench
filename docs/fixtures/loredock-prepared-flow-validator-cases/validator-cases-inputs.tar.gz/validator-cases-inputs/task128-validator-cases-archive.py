from pathlib import Path
import json

base=Path('/home/toshiba/aew');helper=base/'task128-kernel-archive.py'
exec(helper.read_text().split("for name in ['core', 'browser', 'crash', 'interruption']:")[0])
repo=base/'worktrees/task128-validator-cases';out=repo/'docs/fixtures/loredock-prepared-flow-validator-cases';out.mkdir(exist_ok=True)
accepted=json.loads((base/'task128-integration-handoff.json').read_text())['latestAccepted']
assert accepted['pr']==147 and accepted['testsPerEvent']==983
records={'schemaVersion':'prepared-flow-validator-cases-development/1','resourceQualification':False,
         'modelCalls':0,'reservedFamilyReads':0,'trees':[],'logs':[],'acceptedInventoryEviction':accepted}
for name in ['first','second','first-inputs','retention']:tree('validator-cases-'+name,base/('task128-validator-cases-'+name))
prior=base/'task128-inventory-eviction-first/run'
tree('validator-cases-reused-sources',prior/'sources');tree('validator-cases-reused-checkpoint',prior/'base/checkpoint')
for name in ['validator-cases-first','validator-cases-second','validator-cases-install','validator-cases-build',
             'validator-cases-retention','validator-cases-build-identities','validator-cases-seal-check','inventory-eviction-ci-push','inventory-eviction-ci-pr']:
    log(name,base/('task128-'+name+'.log'))
inputs=base/'task128-validator-cases-inputs';inputs.mkdir()
for source in [repo/'scripts/loredock-prepared-flow/validator-cases.mjs',repo/'scripts/loredock-prepared-flow/validator-cases-development.mjs',
               helper,base/'task128-validator-cases-retention.py',base/'task128-validator-cases-build-identities.py',prior/'sources.json',
               base/'worktrees/task128-inventory-eviction/docs/fixtures/loredock-prepared-flow-inventory-eviction/inventory-eviction-first.inventory.json.gz',Path(__file__)]:
    (inputs/source.name).write_bytes(source.read_bytes())
tree('validator-cases-inputs',inputs)
records['retention']=json.loads((base/'task128-validator-cases-retention/result.json').read_text())
(out/'records.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps({'trees':len(records['trees']),'logs':len(records['logs'])},indent=2))
