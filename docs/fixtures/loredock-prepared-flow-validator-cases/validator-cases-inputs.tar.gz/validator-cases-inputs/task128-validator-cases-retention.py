from pathlib import Path
import gzip
import hashlib
import json
import shutil
import sqlite3

base=Path('/home/toshiba/aew');output=base/'task128-validator-cases-retention';output.mkdir()
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def read(file):return json.loads(file.read_text())
def inventory(directory):return {str(p.relative_to(directory)):{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(directory.rglob('*')) if p.is_file()}
report={'resourceQualification':False,'modelCalls':0,'reservedFamilyReads':0,'runs':[],'catalogs':[],'httpBodies':0,'redactedSessions':0}
prior=base/'task128-inventory-eviction-first'
manifest=json.loads(gzip.decompress((base/'worktrees/task128-inventory-eviction/docs/fixtures/loredock-prepared-flow-inventory-eviction/inventory-eviction-first.inventory.json.gz').read_bytes()))
bound=0
for name,info in manifest.items():
    if name.startswith(('run/sources/','run/base/checkpoint/')):
        raw=(prior/name).read_bytes();assert len(raw)==info['bytes'] and sha(raw)==info['sha256'];bound+=1
report['reusedFilesBoundToPreviousArchive']=bound
for name in ['first','second']:
    root=base/('task128-validator-cases-'+name);run=root/'run';before=inventory(root)
    owner=read(root/'result.json');driver=read(run/'result.json');inputs=read(run/'inputs.json')
    assert owner['errors']==[] and owner['survivors']==[] and driver['errors']==[]
    assert owner['driverExit']['exit']==int(name=='first') and owner['reason']==('driver-failure' if name=='first' else 'completed')
    assert len(driver['cases'])==10
    assert inventory(Path(inputs['base']['data']))==inputs['base']['files']
    alternative=driver['cases'][0]['value']['checkpoint']
    assert alternative['kind']=='two-published-builds' and alternative['lane']=='fault'
    assert inventory(Path(alternative['data']))==alternative['files']
    assert alternative['first']['id']!=alternative['second']['id']
    for item in [alternative['first'],alternative['second']]:assert item['status']=='completed' and item['published'] is True
    for file in run.rglob('requests.jsonl'):
        pending={};responses=set()
        for line in file.read_text().splitlines():
            row=json.loads(line);key=row['id'];assert row['event']!='failure'
            if row['event']=='request':assert key not in pending;pending[key]=row
            if row['event']=='response':
                assert key in pending and key not in responses;responses.add(key)
                raw=(file.parent/(key+'.json')).read_bytes()
                if pending[key]['route']=='/session':assert json.loads(raw)['token']=='[removed-session-token]';report['redactedSessions']+=1
                else:assert len(raw)==row['bytes'];report['httpBodies']+=1
        assert set(pending)==responses
    outcomes=[]
    for case in driver['cases']:
        value=case['value'];assert value['errors']==[] and value['inputCheckpointUnchanged'] is True and value['timingQualified'] is False
        process=run/case['id']/('production-setup' if case['id']=='alternative-build' else 'controlled')/'process.json'
        assert read(process)['fault'] is True
        if case['id']=='alternative-build':continue
        kind=value['kind'];boundary=value['boundary'];stats=value['runtime']
        expected_prepares=int(boundary!='first-preflight' or (name=='first' and kind=='review'))
        assert stats=={'prepares':expected_prepares,'calls':int(boundary=='before-publication'),'closed':expected_prepares}
        assert value['observedBoundary'] is not (name=='first' and case['id']=='first-preflight-review')
        assert value['terminal']['value']['status'] in ['failed','fenced'] and value['terminal']['value']['answer'] is None
        assert value['terminal']['rawSha256']==value['replayed']['rawSha256']
        requests=[json.loads(line) for line in (run/case['id']/'http-controlled/requests.jsonl').read_text().splitlines() if json.loads(line)['event']=='request']
        admission=next(i for i,row in enumerate(requests) if row['route']=='/prepared-answers')
        if kind=='review':
            if name=='first':assert [row['route'] for row in requests[admission+1:admission+4]]==['/code-flows','/corrections','/corrections']
            else:assert requests[admission+1]['route']=='/corrections' and requests[admission+1]['method']=='POST'
        if kind=='published-build':
            assert value['projectAfterMutation']['publishedBuildId']==alternative['second']['id']
            for key in ['sourceSetVersion','policyVersion','correctionRevision']:assert value['projectAfterMutation'][key]==alternative['project'][key]
        outcomes.append({'id':case['id'],'observedBoundary':value['observedBoundary'],'runtime':stats,'terminalStatus':value['terminal']['value']['status']})
    for original in sorted(run.rglob('loredock.db')):
        relative=original.parent.relative_to(run);copied=output/name/relative;copied.parent.mkdir(parents=True,exist_ok=True)
        shutil.copytree(original.parent,copied);assert inventory(original.parent)==inventory(copied)
        db=sqlite3.connect('file:'+str(copied/'loredock.db')+'?mode=ro',uri=True)
        try:
            assert db.execute('PRAGMA integrity_check').fetchall()==[('ok',)] and db.execute('PRAGMA foreign_key_check').fetchall()==[]
            states=db.execute('SELECT status,count(*) FROM answer_attempts GROUP BY status').fetchall()
            witnesses=db.execute('SELECT witness,witnessBytes,purged,reviewedHash FROM answer_witnesses').fetchall()
            if relative.parts[0]=='alternative-build':assert states==[] and witnesses==[]
            else:
                value=read(run/relative.parts[0]/'result.json');review=value['prepared']['review']
                assert len(states)==1 and states[0][0] in ['failed','fenced'] and states[0][1]==1
                witness,size,purged,reviewed=witnesses[0];assert len(witnesses)==1 and purged==0 and len(witness.encode())==size
                assert reviewed==review['reviewedHash'] and json.loads(witness)['compact']==review['compact']
                context,result,usage=db.execute('SELECT context,result,usage FROM answer_attempts').fetchone()
                assert json.loads(context)==review['context'] and result is None
                if value['boundary']=='before-publication':
                    assert json.loads(usage)=={'inputTokens':80,'outputTokens':20,'cachedInputTokens':0}
                    request=read(run/relative.parts[0]/'controlled/request-1.json')
                    assert json.loads(witness)['prompt']==request['prompt']
                    assert request['schema']['properties']['claims']['items']['properties']['evidenceIds']['items']['enum']==[x['id'] for x in review['context']['spans']]
                else:assert usage is None and not (run/relative.parts[0]/'controlled/request-1.json').exists()
                if value['kind']=='published-build':
                    assert db.execute('SELECT publishedBuildId FROM project').fetchone()==(alternative['second']['id'],)
                    assert db.execute('SELECT buildId FROM answer_attempts').fetchone()==(alternative['first']['id'],)
            report['catalogs'].append({'run':name,'source':str(original.parent),'copy':str(copied),'integrity':'ok','foreignKeyErrors':[],'answerStates':states})
        finally:db.close()
    assert inventory(root)==before
    report['runs'].append({'name':name,'entries':len(before),'rawInputsUnchanged':True,'outcomes':outcomes})
assert len(report['catalogs'])==22
(output/'result.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
