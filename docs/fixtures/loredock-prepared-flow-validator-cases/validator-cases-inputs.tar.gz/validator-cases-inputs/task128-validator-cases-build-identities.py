from pathlib import Path
import json
import sqlite3

base=Path('/home/toshiba/aew');root=base/'task128-validator-cases-retention';report=[]
retention=json.loads((root/'result.json').read_text())
for row in retention['catalogs']:
    source=Path(row['source'])
    if 'alternative-build' not in source.parts and 'published-build' not in str(source):continue
    checkpoint=json.loads((base/('task128-validator-cases-'+row['run'])/'run/alternative-build/checkpoint.json').read_text())
    db=sqlite3.connect('file:'+str(Path(row['copy'])/'loredock.db')+'?mode=ro',uri=True)
    try:
        identities=[]
        for build in [checkpoint['first'],checkpoint['second']]:
            stored=db.execute('SELECT status,published,policyVersion,sourceSetVersion FROM builds WHERE id=?',(build['id'],)).fetchone()
            assert stored==('completed',1,checkpoint['project']['policyVersion'],checkpoint['project']['sourceSetVersion'])
            identities.append({'id':build['id'],'status':stored[0],'published':stored[1],'policyVersion':stored[2],'sourceSetVersion':stored[3]})
        report.append({'copy':row['copy'],'identities':identities})
    finally:db.close()
assert len(report)==10
with (root/'build-identities.json').open('x') as file:file.write(json.dumps(report,indent=2)+'\n')
print(json.dumps({'copiedCatalogs':len(report),'completedPublishedIdentities':sum(len(row['identities']) for row in report),'modelCalls':0,'reservedFamilyReads':0},indent=2))
