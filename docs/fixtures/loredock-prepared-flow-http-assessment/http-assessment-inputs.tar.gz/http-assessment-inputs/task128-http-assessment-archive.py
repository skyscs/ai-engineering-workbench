from pathlib import Path
import json
import re

base=Path('/home/toshiba/aew'); helper=base/'task128-kernel-archive.py'
exec(helper.read_text().split("for name in ['core', 'browser', 'crash', 'interruption']:")[0])
repo=base/'worktrees/task128-http-assessment'; out=repo/'docs/fixtures/loredock-prepared-flow-http-assessment'
records={'schemaVersion':'prepared-flow-http-assessment-development/1','resourceQualification':False,
         'modelCalls':0,'reservedFamilyReads':0,'newCandidateReads':0,'tests':979,'trees':[],'logs':[],
         'acceptedColdWarm':{'pr':141,'head':'a7a64277d85073bf8b34821cfc4555171ac41cf8',
           'merge':'141416deb098c79c2d2fa9d087c2077e307b0a8d','push':42015747164,'pull_request':42015756110,'testsPerEvent':973}}
for row in json.loads((base/'task128-http-assessment-manifest.json').read_text()):
    tree('http-input-'+row['id'],Path(row['directory']))
    tree('process-input-'+row['id'],Path(row['processDirectory']))
tree('http-assessment-first',base/'task128-http-assessment-first')
tree('http-assessment-retention',base/'task128-http-assessment-retention')
for name in ['http-assessment-install','http-assessment-build','http-assessment-focused-first','http-assessment-focused-final',
             'http-assessment-focused-exit','http-assessment-check-first','http-assessment-first','http-assessment-retention',
             'http-assessment-seal-check','cold-warm-ci-push','cold-warm-ci-pr']:
    raw=log(name,base/('task128-'+name+'.log'))
    if not name.startswith(('http-assessment-focused-','http-assessment-check-')): continue
    for kind,pattern in [('http',r'Retained HTTP-assessor test: (/tmp/loredock-http-assess-[A-Za-z0-9]+)'),
                         ('sequence',r'Retained flow-coordinator test: (/tmp/loredock-flow-coordinator-[A-Za-z0-9]+)'),
                         ('lifetime',r'Retained browser-lifetime test: (/tmp/loredock-browser-lifetime-[A-Za-z0-9]+)'),
                         ('owner',r'Retained kernel-owner test: (/tmp/loredock-kernel-(?:adoption|owner)-[A-Za-z0-9]+)'),
                         ('checkpoint',r'Retained history-checkpoint test: (/tmp/loredock-history-checkpoint-[A-Za-z0-9]+)')]:
        for index,location in enumerate(re.findall(pattern,raw)):
            tree(name+'-'+kind+'-'+str(index+1),Path(location))
inputs=base/'task128-http-assessment-inputs';inputs.mkdir()
for source in [repo/'scripts/loredock-prepared-flow/http-assess.mjs',repo/'scripts/loredock-prepared-flow/reassess-retained-http.mjs',
               repo/'scripts/tests/loredock-http-assess.test.mjs',helper,base/'task128-http-assessment-manifest.json',
               base/'task128-http-assessment-retention.py',Path(__file__)]:
    (inputs/source.name).write_bytes(source.read_bytes())
tree('http-assessment-inputs',inputs)
records['retention']=json.loads((base/'task128-http-assessment-retention/result.json').read_text())
(out/'records.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps({'trees':len(records['trees']),'logs':len(records['logs']),'tests':records['tests']},indent=2))
