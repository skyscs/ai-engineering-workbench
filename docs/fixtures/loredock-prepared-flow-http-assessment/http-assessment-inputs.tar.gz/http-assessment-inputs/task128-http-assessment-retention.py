from pathlib import Path
import hashlib
import json

base=Path('/home/toshiba/aew'); source=base/'task128-http-assessment-first'; output=base/'task128-http-assessment-retention'; output.mkdir()
sha=lambda value: hashlib.sha256(value).hexdigest()
def inventory(root):
    return {str(file.relative_to(root)): {'bytes': len(raw), 'sha256': sha(raw)}
            for file in sorted(root.rglob('*')) if file.is_file() for raw in [file.read_bytes()]}
before=inventory(source); data=json.loads((source/'result.json').read_text())
thresholds=json.loads((base/'worktrees/task128-http-assessment/fixtures/loredock-prepared-flow/protocol.json').read_text())['thresholds']
expected={'cold-240':('incomplete',30,0),'cold-12':('passed',16,8),'warm-12':('passed',32,45),
          'browser-20':('passed',2,2),'browser-64':('passed',2,2),'accounting-20':('observed',2,2),'accounting-64':('observed',2,2)}
report={'resourceQualification':False,'newCandidateReads':0,'modelCalls':0,'datasets':[], 'responses':0,'exactBodies':0,'checks':0}
for row in data['cases']:
    assert row['errors']==[] and row['rawInputsUnchanged'] is True
    given=row['input']; assessment=row['assessment']; http=Path(given['directory']); process=Path(given['processDirectory'])
    original=json.loads((source/(row['id']+'-input-inventory.json')).read_text())
    assert inventory(http)==original['http'] and inventory(process)==original['process']
    assert assessment['journalSha256']==sha((http/'requests.jsonl').read_bytes())
    assert assessment['processRecordSha256']==sha((process/'process.json').read_bytes())
    assert assessment['exitSha256']==sha((process/'exit.json').read_bytes())
    status,responses,checks=expected[row['id']]
    assert assessment['status']==status and len(assessment['observations'])==responses
    assert assessment['timingQualified']==(given['lane']=='resource')
    assert assessment['resourceQualification'] is False and assessment['modelEligibility'] is False
    assert assessment['failures']==[]
    assert len(assessment['incomplete'])==(1 if row['id']=='cold-240' else 0)
    actual_checks=0
    for observed in assessment['observations']:
        raw=(http/(observed['id']+'.json')).read_bytes()
        assert len(raw)==observed['retainedBytes'] and sha(raw)==observed['rawSha256']
        if observed['redacted']:
            assert json.loads(raw)['token']=='[removed-session-token]'
        else:
            assert len(raw)==observed['bytes'];report['exactBodies']+=1
        for check in observed['checks']:
            assert thresholds[check['name']]==check['limit']
            field='elapsedMs' if check['name'].endswith('Ms') else 'bytes'
            assert observed[field]==check['value']
            assert check['withinLimit']==(check['value']<=check['limit'])
            actual_checks+=1
        report['responses']+=1
    assert actual_checks==checks;report['checks']+=actual_checks
    report['datasets'].append({'id':row['id'],'status':status,'responses':responses,'checks':checks,'rawInputsUnchanged':True})
assert inventory(source)==before
assert report['responses']==86 and report['exactBodies']==79 and report['checks']==61
(output/'result.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
