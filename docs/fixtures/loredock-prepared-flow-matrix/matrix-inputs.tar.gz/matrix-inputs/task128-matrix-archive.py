from pathlib import Path
import json
import re

base = Path('/home/toshiba/aew')
helper = base / 'task128-kernel-archive.py'
exec(helper.read_text().split("for name in ['core', 'browser', 'crash', 'interruption']:")[0])
repo = base / 'worktrees/task128-matrix-assembly'
out = repo / 'docs/fixtures/loredock-prepared-flow-matrix'
records = {'schemaVersion': 'prepared-flow-matrix-development/1', 'resourceQualification': False,
           'modelCalls': 0, 'reservedFamilyReads': 0, 'tests': 956, 'trees': [], 'logs': [],
           'acceptedPreflight': {'pr': 135, 'head': 'a78887afc5a06163df15a0851e298185aaeb00b5',
                                'merge': '20c86d35dea722362ebf80dc90e816fd4b11fe0e',
                                'push': 42001496141, 'pull_request': 42001504264, 'testsPerEvent': 955}}
for name in ['source-only-first', 'source-only-second', 'browser-thread-tree-first']:
    tree(name, base / ('task128-' + name),
         'The incorrect expected ordinary quote fails this original run; the corrected reference is a separate retained run.' if name == 'source-only-first' else
         'Functional browser observation overlapped ordinary repository checks; not a resource qualification run.' if name.startswith('browser') else None)
    log(name, base / ('task128-' + name + '.log'))
tree('matrix-retention', base / 'task128-matrix-retention')
for name in ['matrix-install', 'matrix-build', 'matrix-process-tree-focused', 'matrix-retention', 'matrix-check-first', 'matrix-seal-check', 'preflight-ci-push-final', 'preflight-ci-pr-final']:
    raw = log(name, base / ('task128-' + name + '.log'))
    if name == 'matrix-check-first':
        for i, location in enumerate(re.findall(r'Retained kernel-owner test: (/tmp/loredock-kernel-(?:adoption|owner)-[A-Za-z0-9]+)', raw)):
            tree('matrix-check-owner-' + str(i+1), Path(location))
inputs = base / 'task128-matrix-inputs'
inputs.mkdir()
for source in [repo/'scripts/loredock-prepared-flow/source-only-development.mjs',
               repo/'scripts/loredock-prepared-flow/browser.mjs', repo/'scripts/loredock-prepared-flow/process-tree.mjs',
               repo/'scripts/tests/loredock-process-tree.test.mjs', base/'task128-source-only-first.driver.mjs', helper,
               base/'task128-matrix-retention.py', Path(__file__)]:
    (inputs / source.name).write_bytes(source.read_bytes())
tree('matrix-inputs', inputs)
records['retention'] = json.loads((base / 'task128-matrix-retention/result.json').read_text())
(out/'records.json').write_text(json.dumps(records, indent=2) + '\n')
print(json.dumps({'trees': len(records['trees']), 'logs': len(records['logs']), 'tests': records['tests']}, indent=2))
