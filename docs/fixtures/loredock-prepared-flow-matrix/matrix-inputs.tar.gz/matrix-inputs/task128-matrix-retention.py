from pathlib import Path
import hashlib
import json
import os
import shutil
import sqlite3
import stat

base = Path('/home/toshiba/aew')
output = base / 'task128-matrix-retention'
output.mkdir()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
def tree(root):
    result = {}
    for directory, dirs, files in os.walk(root, followlinks=False):
        for name in dirs + files:
            file = Path(directory) / name
            mode = file.lstat().st_mode
            if stat.S_ISREG(mode):
                result[str(file.relative_to(root))] = sha(file.read_bytes())
            elif stat.S_ISLNK(mode):
                result[str(file.relative_to(root))] = {'symlink': os.readlink(file)}
    return result

results = []
for name in ['source-only-first', 'source-only-second', 'browser-thread-tree-first']:
    root = base / ('task128-' + name)
    before = tree(root)
    owner = json.loads((root / 'result.json').read_text())
    run = json.loads((root / 'run/result.json').read_text())
    assert not owner['errors'] and not owner['survivors']
    if name == 'source-only-first':
        assert owner['reason'] == 'driver-failure' and owner['driverExit']['exit'] == 1
        assert len(run['errors']) == 1 and run['errors'][0]['message'] == 'Missing required original: action'
    else:
        assert owner['reason'] == 'completed' and owner['driverExit']['exit'] == 0 and not run['errors']
    if name == 'source-only-second':
        assert run['analysis'] == {'inventories': [], 'pendingBuildId': None, 'automaticError': None}
        assert run['assessment']['omission'] == 'INVENTORY_UNAVAILABLE'
        assert not run['assessment']['native'] and run['assessment']['issuedOriginals'] == 12
        assert run['review']['context']['buildId'] == run['build']['id']
    source = json.loads((root / 'run/sources.json').read_text())
    for row in source['originals']:
        raw = (root / 'run/sources' / row['source'] / row['path']).read_bytes()
        assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
    data = root / 'run/data'
    copy = output / name / 'data'
    shutil.copytree(data, copy)
    connection = sqlite3.connect((copy / 'loredock.db').as_uri() + '?mode=ro', uri=True)
    assert connection.execute('PRAGMA integrity_check').fetchall() == [('ok',)]
    assert connection.execute('PRAGMA foreign_key_check').fetchall() == []
    answers = connection.execute('SELECT status FROM answer_attempts').fetchall()
    analyses = connection.execute('SELECT count(*) FROM code_analyses').fetchone()[0]
    if name.startswith('source-only'):
        assert answers == [] and analyses == 0
    else:
        assert answers == [('succeeded',)] and analyses == 1
    connection.close()
    entry = {'case': name, 'sourceHashesUnchanged': True, 'rawTreeUnchangedByInspection': True,
             'catalogIntegrity': 'ok', 'foreignKeys': [], 'answers': answers, 'analyses': analyses,
             'ownerErrors': [], 'ownedSurvivors': []}
    if name.startswith('browser'):
        samples = [json.loads(line) for line in (root / 'run/browser/process-tree.jsonl').read_text().splitlines()]
        assert len(samples) == run['browser']['memorySamples']
        assert sum(not sample['complete'] for sample in samples) == run['browser']['incompleteMemorySamples']
        assert all(sample['rssBytes'] == sum(row.get('rssBytes', 0) for row in sample['rows']) for sample in samples)
        nonleader = sum(row['discoveredFrom']['tid'] != row['discoveredFrom']['pid']
                        for sample in samples for row in sample['rows'] if row.get('discoveredFrom'))
        assert nonleader > 0
        entry['browser'] = {'samples': len(samples), 'incompleteSamples': run['browser']['incompleteMemorySamples'],
                            'nonleaderEdges': nonleader, 'maximumSampledRssBytes': run['browser']['maxRssBytes'],
                            'clockTicksPerSecond': os.sysconf('SC_CLK_TCK'), 'resourceQualification': False}
    assert tree(root) == before
    results.append(entry)
(output / 'result.json').write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps(results, indent=2))
