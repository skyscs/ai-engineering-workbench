import {mkdir,writeFile,readFile,symlink} from 'node:fs/promises';
import {spawn} from 'node:child_process';
const root=process.argv[2];await mkdir(root);await writeFile(root+'/retained-original.txt','Owned source bytes survive.');
await writeFile(root+'/forged-process.json',JSON.stringify({pid:1}));
const child=spawn(process.execPath,['-e',"const {spawn}=require('node:child_process');const child=spawn(process.execPath,['-e',\"const fs=require('node:fs');process.on('SIGTERM',()=>{});fs.writeFileSync(\\\"/tmp/loredock-kernel-owner-Gg25eN/output/run/leaf-ready.json\\\",JSON.stringify({pid:process.pid}));setInterval(()=>{},1000);\"],{stdio:'ignore',detached:true});child.unref();"],{stdio:'ignore',detached:true});child.unref();
while(true){try{await readFile(root+'/leaf-ready.json');break;}catch(error){if(error.code!=='ENOENT')throw error;await new Promise(r=>setTimeout(r,10));}}
await writeFile(root+'/ready','ready');
setInterval(()=>{},1000);
