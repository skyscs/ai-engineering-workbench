from pathlib import Path
import hashlib
import json
import os
import shutil
import sqlite3
import stat

base = Path('/home/toshiba/aew')
output = base / 'task128-ordered-retention'
output.mkdir()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
def tree(root):
    result = {}
    for directory, dirs, files in os.walk(root, followlinks=False):
        for name in dirs + files:
            file = Path(directory) / name
            mode = file.lstat().st_mode
            if stat.S_ISREG(mode):
                result[str(file.relative_to(root))] = sha(file.read_bytes())
            elif stat.S_ISLNK(mode):
                result[str(file.relative_to(root))] = {'symlink': os.readlink(file)}
    return result

results = []
for name in ['ordered-history-first', 'ordered-history-second']:
    root = base / ('task128-' + name)
    before = tree(root)
    owner = json.loads((root / 'result.json').read_text())
    run = json.loads((root / 'run/result.json').read_text())
    capacity = json.loads((root / 'run/capacity/result.json').read_text())
    assert not owner['errors'] and not owner['survivors'] and not capacity['errors']
    assert len(capacity['admissions']) == 64 and sum(row['calls'] for row in capacity['runtimeSegments']) == 64
    assert capacity['refusal']['readyStillUsable'] and capacity['refusal']['noAdditionalRuntimeCall']
    if name.endswith('first'):
        assert owner['reason'] == 'driver-failure' and owner['driverExit']['exit'] == 1
        assert len(run['errors']) == 1 and 'The stopped checkpoint changed.' in run['errors'][0]['message']
        assert [row['name'] for row in run['cases']] == ['capacity']
        for checkpoint in capacity['checkpoints']:
            current = tree(Path(checkpoint['data']))
            recorded = {file: value['sha256'] for file, value in checkpoint['files'].items()}
            assert set(current) - set(recorded) == {'loredock.db-shm', 'loredock.db-wal'}
            assert all(current[file] == digest for file, digest in recorded.items())
    else:
        assert owner['reason'] == 'completed' and owner['driverExit']['exit'] == 0 and not run['errors']
        sequence = ['capacity', 'browser-20', 'browser-64', 'restart-20', 'restart-64', 'revocation-64', 'accounting-20', 'accounting-64']
        assert [row['name'] for row in run['cases']] == sequence
        events = [json.loads(line) for line in (root/'run/sequence.jsonl').read_text().splitlines()]
        assert [(row['event'], row['name']) for row in events] == [(event, name) for name in sequence for event in ['started', 'finished']]
        for checkpoint in capacity['checkpoints']:
            assert tree(Path(checkpoint['data'])) == {file: value['sha256'] for file, value in checkpoint['files'].items()}
        for row in run['cases'][1:]:
            assert not row['value']['errors']
            if row['name'].startswith('restart'):
                assert len(row['value']['observation']['answers']) == row['value']['rows']
                assert row['value']['observation']['transientLost']
            if row['name'].startswith('accounting'):
                assert row['value']['observation']['rawByteParity'] and row['value']['observation']['budgets'] == 20
                assert row['value']['runtime'] == {'prepares': 0, 'calls': 0, 'closed': 0}
    source = json.loads((root / 'run/sources.json').read_text())
    for row in source['originals']:
        raw = (root / 'run/sources' / row['source'] / row['path']).read_bytes()
        assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
    responses = []
    for journal in sorted((root / 'run').rglob('requests.jsonl')):
        requests = {}
        for line in journal.read_text().splitlines():
            row = json.loads(line)
            if row['event'] == 'request': requests[row['id']] = row
            if row['event'] != 'response' or requests[row['id']]['route'] == '/session': continue
            raw = (journal.parent / (row['id'] + '.json')).read_bytes()
            assert len(raw) == row['bytes']
            responses.append({'method': requests[row['id']]['method'], 'route': requests[row['id']]['route'],
                              'sha256': sha(raw), 'bytes': len(raw)})
    for admission in capacity['admissions']:
        assert any(row['method'] == 'GET' and row['route'] == '/answers/' + admission['id']
                   and row['sha256'] == admission['rawSha256'] for row in responses)
    databases = []
    for database in sorted((root / 'run').rglob('loredock.db')):
        relative = database.parent.relative_to(root / 'run')
        copy = output / name / relative
        shutil.copytree(database.parent, copy)
        connection = sqlite3.connect((copy / database.name).as_uri() + '?mode=ro', uri=True)
        assert connection.execute('PRAGMA integrity_check').fetchall() == [('ok',)]
        assert connection.execute('PRAGMA foreign_key_check').fetchall() == []
        count, purged, size = connection.execute('SELECT count(*),sum(purged),coalesce(sum(length(CAST(witness AS BLOB))),0) FROM answer_witnesses').fetchone()
        assert count in [20,64]
        assert purged == (64 if str(relative).startswith('revocation-64/') else 0)
        assert (size == 0) == bool(purged)
        assert connection.execute('SELECT count(*) FROM answer_attempts').fetchone()[0] == count
        connection.close()
        databases.append({'directory': str(relative), 'integrity': 'ok', 'foreignKeys': [], 'witnesses': count, 'purged': purged, 'witnessBytes': size})
    assert tree(root) == before
    results.append({'case': name, 'sourceHashesUnchanged': True, 'rawTreeUnchangedByInspection': True,
                    'databases': databases, 'httpResponsesVerified': len(responses), 'ownedSurvivors': []})
(output / 'result.json').write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps(results, indent=2))
