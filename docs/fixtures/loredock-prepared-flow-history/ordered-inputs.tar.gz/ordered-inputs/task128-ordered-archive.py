from pathlib import Path
import json
import re

base = Path('/home/toshiba/aew')
helper = base / 'task128-kernel-archive.py'
exec(helper.read_text().split("for name in ['core', 'browser', 'crash', 'interruption']:")[0])
repo = base / 'worktrees/task128-ordered-capacity'
out = repo / 'docs/fixtures/loredock-prepared-flow-history'
records = {'schemaVersion': 'prepared-flow-ordered-history-development/1', 'resourceQualification': False,
           'modelCalls': 0, 'reservedFamilyReads': 0, 'tests': 957, 'trees': [], 'logs': [],
           'acceptedMatrixControls': {'pr': 136, 'head': 'cbff65f6d55320c5473974f073cb840aec5a4acb',
                                      'merge': 'f78e2419f8125b07f227723465a508e3d14862d8',
                                      'push': 42004546086, 'pull_request': 42004565275, 'testsPerEvent': 956}}
for name in ['ordered-history-first', 'ordered-history-second']:
    tree(name, base / ('task128-' + name),
         'The first run remains failed because read-only SQLite inspection created WAL/SHM files after checkpoint hashing.' if name.endswith('first') else
         'Functional ordinary control only. Both list-work totals and browser RSS exceed prospective ceilings; one browser startup sample is incomplete.')
    log(name, base / ('task128-' + name + '.log'))
tree('ordered-retention', base / 'task128-ordered-retention')
tree('ordered-first-inputs', base / 'task128-ordered-first-inputs')
for name in ['ordered-install', 'ordered-build', 'ordered-checkpoint-focused', 'ordered-retention', 'ordered-check-first', 'ordered-seal-check', 'matrix-ci-push', 'matrix-ci-pr']:
    raw = log(name, base / ('task128-' + name + '.log'))
    if name in ['ordered-check-first', 'ordered-checkpoint-focused']:
        for i, location in enumerate(re.findall(r'Retained kernel-owner test: (/tmp/loredock-kernel-(?:adoption|owner)-[A-Za-z0-9]+)', raw)):
            tree(name + '-owner-' + str(i+1), Path(location))
        for i, location in enumerate(re.findall(r'Retained history-checkpoint test: (/tmp/loredock-history-checkpoint-[A-Za-z0-9]+)', raw)):
            tree(name + '-checkpoint-' + str(i+1), Path(location))
inputs = base / 'task128-ordered-inputs'
inputs.mkdir()
for source in [repo/'scripts/loredock-prepared-flow/history-cases.mjs',
               repo/'scripts/loredock-prepared-flow/ordered-history-development.mjs', repo/'scripts/loredock-prepared-flow/io.mjs',
               repo/'scripts/tests/loredock-history-checkpoint.test.mjs', helper,
               base/'task128-ordered-retention.py', Path(__file__)]:
    (inputs / source.name).write_bytes(source.read_bytes())
tree('ordered-inputs', inputs)
records['retention'] = json.loads((base / 'task128-ordered-retention/result.json').read_text())
(out/'records.json').write_text(json.dumps(records, indent=2) + '\n')
print(json.dumps({'trees': len(records['trees']), 'logs': len(records['logs']), 'tests': records['tests']}, indent=2))
