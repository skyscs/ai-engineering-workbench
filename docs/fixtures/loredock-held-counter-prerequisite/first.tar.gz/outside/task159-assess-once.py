"""Consume the separately pinned outside assessment after the sole service attempt."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import selectors
import subprocess
import time

root = Path('/home/toshiba/aew')
seal = json.loads((root / 'task159-launch-seal.json').read_text())
manifest_path = Path(seal['manifest'])
spec = importlib.util.spec_from_file_location('sealed_counter_probe', manifest_path.parent / 'probe.py')
probe = importlib.util.module_from_spec(spec)
spec.loader.exec_module(probe)
acquisition, manifest = probe.bootstrap(manifest_path, seal['sha256'])
offline_path = root / 'task159-offline-assessment-seal.json'
assert acquisition.digest(offline_path) == manifest['offlineAssessmentSealSha256']
offline = json.loads(offline_path.read_text())
output = Path(offline['output'])
assert not output.exists()
assert (root / 'task159-held-counter-launch-first.json').exists()
assert offline['candidateHead'] == manifest['candidateHead'] == seal['candidateHead']
assert offline['wallSeconds'] == 10 and offline['maxOutputBytes'] == 1048576
def check_inputs():
    node = Path(offline['node']['path'])
    assert str(node.resolve()) == offline['node']['resolved']
    assert hashlib.sha256(node.read_bytes()).hexdigest() == offline['node']['sha256']
    assert node.stat().st_size == offline['node']['bytes']
    assert node.stat().st_uid == offline['node']['uid']
    assert oct(node.stat().st_mode & 0o7777) == offline['node']['mode']
    for row in offline['sources']:
        assert acquisition.digest(row['path']) == row['sha256']
check_inputs()
command = [seal['sha256'] if part == 'MANIFEST_SHA256' else part for part in offline['commandTemplate']]
started = time.monotonic_ns()
acquisition.retain(root / 'task159-offline-assessment-intent.json', {
    'manifestSha256': seal['sha256'], 'offlineSealSha256': acquisition.digest(offline_path),
    'command': command, 'startedAtNs': str(started), 'wallSeconds': 10, 'maxOutputBytes': 1048576})
process = subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                           env=offline['environment'], close_fds=True, start_new_session=True)
streams = {'stdout': bytearray(), 'stderr': bytearray()}
failure = None
try:
    with selectors.DefaultSelector() as selector:
        for name in streams:
            selector.register(getattr(process, name), selectors.EVENT_READ, name)
        while selector.get_map() or process.poll() is None:
            if time.monotonic_ns() - started > 10000000000:
                failure = failure or 'TIMEOUT'
                process.kill()
            for key, _ in selector.select(0.025):
                chunk = os.read(key.fileobj.fileno(), 8192)
                if not chunk:
                    selector.unregister(key.fileobj)
                    key.fileobj.close()
                    continue
                remaining = 1048576 - sum(map(len, streams.values()))
                streams[key.data].extend(chunk[:remaining])
                if len(chunk) > remaining:
                    failure = failure or 'OUTPUT_BOUND'
                    process.kill()
            if failure and time.monotonic_ns() - started > 12000000000:
                break
except (Exception, KeyboardInterrupt) as error:
    failure = failure or type(error).__name__
finally:
    if process.poll() is None:
        process.kill()
    code = process.wait(timeout=2)
    process.stdout.close()
    process.stderr.close()
ended = time.monotonic_ns()
for name, raw in streams.items():
    path = root / ('task159-offline-assessment-' + name + '.log')
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_CLOEXEC | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
record = {'manifestSha256': seal['sha256'], 'offlineSealSha256': acquisition.digest(offline_path),
          'command': command, 'exitCode': code, 'failure': failure,
          'startedAtNs': str(started), 'endedAtNs': str(ended), 'durationNs': str(ended - started),
          'streams': {name: {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()} for name, raw in streams.items()}}
try:
    parsed = json.loads(streams['stdout'])
    if parsed['manifestSha256'] != seal['sha256']:
        raise ValueError('Outside report binding mismatch')
    record['report'] = parsed
except (ValueError, KeyError, TypeError) as error:
    record.update(report=None, reportError=str(error)[:4096])
try:
    check_inputs()
    record['inputsUnchanged'] = True
except (Exception, KeyboardInterrupt) as error:
    record.update(inputsUnchanged=False, inputError=type(error).__name__)
acquisition.retain(output, record)
print(json.dumps({'exitCode': code, 'failure': failure, 'durationNs': record['durationNs'],
                  'status': record.get('report', {}).get('assessment', {}).get('status') if record.get('report') else None,
                  'inputsUnchanged': record['inputsUnchanged']}))
raise SystemExit(0 if code == 0 and failure is None and record['inputsUnchanged'] else 1)
