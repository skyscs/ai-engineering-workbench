"""Seal the reviewed Task 159 candidate without starting the prerequisite."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import uuid

root = Path("/home/toshiba/aew")
checkout = root / "worktrees/task159-held-counter-prerequisite"
def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module
probe = load(checkout / "scripts/loredock-held-counter-prerequisite/probe.py", "sealing_probe")
acquisition = load(checkout / "scripts/loredock-user-namespace-prerequisite/probe.py", "sealing_acquisition")
support = load(checkout / "scripts/loredock-namespace-prerequisite/probe.py", "sealing_support")
assert not subprocess.check_output(["git", "status", "--porcelain"], cwd=checkout).strip()
head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=checkout, text=True).strip()
review = json.loads((root / "task159-local-check-review.json").read_text())
assert review["fullTests"] == 1221 and review["failures"] == review["cancelled"] == 0
for row in review["sources"]:
    assert acquisition.digest(checkout / row["path"]) == row["sha256"]
inputs = root / "task159-held-counter-inputs"
inputs.mkdir(mode=0o700)
originals = {"acquisition": checkout / "scripts/loredock-user-namespace-prerequisite/probe.py",
             "support": checkout / "scripts/loredock-namespace-prerequisite/probe.py",
             "validator": checkout / "scripts/loredock-user-service-ownership/assess.py",
             "payload": checkout / "scripts/loredock-namespace-prerequisite/payload.py",
             **{name: checkout / "scripts/loredock-direct-birth-prerequisite" / filename
                for name, filename in (("capture", "capture.py"), ("protocol", "protocol.py"))},
             "nativeSource": checkout / "scripts/loredock-native-capability-prerequisite/native.c",
             "leaf": checkout / "scripts/loredock-empty-controller-prerequisite/leaf.py",
             "counterReader": checkout / "scripts/loredock-held-counters/reader.py",
             "counters": checkout / "scripts/loredock-held-counter-prerequisite/counters.py"}
for name, filename in probe.LOCAL.items():
    if name == "native":
        continue
    target = inputs / filename
    if name == "canary":
        target.write_bytes(b"Task 159 immutable read-only sandbox canary.\n")
    else:
        shutil.copyfile(originals.get(name, checkout / "scripts/loredock-held-counter-prerequisite" / filename), target)
command = ["/usr/bin/cc", *probe.BUILD_FLAGS, str(inputs / "native.c"), "-o", str(inputs / "native")]
compiled = subprocess.run(command, capture_output=True, timeout=30, env={"PATH": "/usr/bin:/bin", "LANG": "C.UTF-8"})
with (root / "task159-native-sealed-build.log").open("xb") as stream:
    stream.write(compiled.stdout + compiled.stderr)
assert compiled.returncode == 0
previous = json.loads((root / "task157-direct-birth-inputs/manifest.json").read_text())
assert acquisition.digest(inputs / "native") == previous["files"]["native"]["sha256"]
dependencies = subprocess.check_output(["/usr/bin/cc", *probe.BUILD_FLAGS, "-M", str(inputs / "native.c")], text=True, env={"PATH": "/usr/bin:/bin", "LANG": "C.UTF-8"})
headers = shlex.split(dependencies.replace("\\\n", "").split(":", 1)[1])
build_inputs = []
for name in ("cc1", "as", "ld"):
    value = subprocess.check_output(["/usr/bin/cc", "-print-prog-name=" + name], text=True).strip()
    headers.append(value if Path(value).is_absolute() else shutil.which(value))
for filename in sorted(set(headers)):
    path = Path(filename).resolve(strict=True)
    build_inputs.append({"path": filename, "resolved": str(path), "bytes": path.stat().st_size,
                         "sha256": hashlib.sha256(path.read_bytes()).hexdigest()})
build = {"candidateHead": head, "command": command, "exitCode": 0, "nativeExecuted": False,
         "compilerVersion": subprocess.check_output(["/usr/bin/cc", "--version"], text=True),
         "inputs": build_inputs, "binarySha256": acquisition.digest(inputs / "native"),
         "limits": "Observed compiler/header/linker inputs and final executable are pinned; the complete operating system is not sealed."}
acquisition.retain(root / "task159-native-build-record.json", build)
offline = root / "task159-counter-assessment-inputs"
offline.mkdir(mode=0o700)
for relative in ("loredock-held-counter-prerequisite/assess.mjs", "loredock-held-counter-prerequisite/postprocess.mjs",
                 "loredock-memory-receipts/assess.mjs"):
    target = offline / relative
    target.parent.mkdir(exist_ok=True)
    shutil.copyfile(checkout / "scripts" / relative, target)
node = root / "toolchain/node-v22.23.2-linux-x64/bin/node"
node_hash = hashlib.sha256(node.read_bytes()).hexdigest()
assert node_hash == "3517c2df0b2f8cd7f422b4b8450ef81c6889f08eb03e281d6de9079b15e6a327"
assert acquisition.digest(offline / "loredock-memory-receipts/assess.mjs") == "905fa440ccb4336b9f96948d2f08901b7ea1c8177bf9a31fac06b415099f2382"
offline_seal = {"candidateHead": head, "manifestPath": str(inputs / "manifest.json"),
    "node": {"path": str(node), "resolved": str(node.resolve()), "sha256": node_hash,
             "bytes": node.stat().st_size, "uid": node.stat().st_uid, "mode": oct(node.stat().st_mode & 0o7777),
             "version": subprocess.check_output([str(node), "--version"], text=True).strip()},
    "sources": [{"path": str(path), "sha256": acquisition.digest(path), "bytes": path.stat().st_size}
                for path in sorted(offline.rglob("*.mjs"))],
    "commandTemplate": [str(node), str(offline / "loredock-held-counter-prerequisite/postprocess.mjs"),
                        str(inputs / "manifest.json"), "MANIFEST_SHA256"],
    "environment": {"PATH": "/usr/bin:/bin", "LANG": "C.UTF-8"}, "wallSeconds": 10,
    "maxOutputBytes": 1048576, "output": str(root / "task159-offline-assessment-first.json"),
    "placement": "Separate outside postprocessing after service closure; not in fixed service or sandbox.",
    "executorQualified": False, "resourceQualification": False}
acquisition.retain(root / "task159-offline-assessment-seal.json", offline_seal)
for path in offline.rglob("*.mjs"):
    path.chmod(0o444)
for path in sorted(offline.rglob("*"), reverse=True):
    if path.is_dir(): path.chmod(0o500)
offline.chmod(0o500)
run_id = str(uuid.uuid4())
manifest = {"schemaVersion": "loredock-held-counter-prerequisite/1", "contractSha256": acquisition.CONTRACT,
            "runId": run_id, "unit": "loredock-task159-" + run_id + ".service",
            "uid": os.getuid(), "gid": os.getgid(), "output": str(root / "task159-held-counter-first"),
            "bounds": dict(acquisition.BOUNDS, clone3Attempts=1, nativeWallSeconds=4, nativeCaptureSeconds=5,
                           counterBatches=2, counterScopes=3, interfacesPerScope=8),
            "candidateHead": head, "buildCommand": command,
            "offlineAssessmentSealSha256": acquisition.digest(root / "task159-offline-assessment-seal.json"),
            "buildRecordSha256": acquisition.digest(root / "task159-native-build-record.json"), "files": {}}
for name in set(probe.FIXED) | set(probe.LOCAL):
    path = Path(probe.FIXED[name]) if name in probe.FIXED else inputs / probe.LOCAL[name]
    resolved = path.resolve(strict=True)
    manifest["files"][name] = {"path": str(path), "resolved": str(resolved), "sha256": acquisition.digest(resolved)}
path = inputs / "manifest.json"
manifest["serviceCommandTemplate"] = support.service_command(manifest, path, "MANIFEST_SHA256")
manifest["sandboxCommand"] = support.sandbox_command(manifest)
acquisition.retain(path, manifest)
sha = acquisition.digest(path)
assert probe.load_manifest(path, sha, acquisition) == manifest
acquisition.retain(root / "task159-first-expectations.json", {
    "candidateHead": head, "manifestSha256": sha, "attempt": 1,
    "expected": ["Fresh exact service ownership", "All initial held counters complete, zero and durably retained before native creation",
                 "Unchanged native self-only zero capability reduction and readback before clone3",
                 "No-new-privileges remains one", "One real clone3 with requested flags",
                 "Direct child placement and identity independently retained before payload permit",
                 "All unchanged namespace/payload predicates", "Actual direct-child normal wait",
                 "Terminal owned target and service empty without forced cleanup", "Pinned inputs unchanged", "Final empty roles before positive root peak through the same descriptors",
                 "Actual normal wait before final windows and raw/receipt fsync before service return",
                 "Separately pinned outside assessment; no complete executor or application qualification"],
    "missingCapability": "Ends candidate path; no fallback or environment changes.",
    "executorQualified": False, "resourceQualification": False, "liveAttemptStarted": False})
acquisition.retain(root / "task159-launch-seal.json", {"manifest": str(path), "sha256": sha,
    "candidateHead": head, "firstOutput": manifest["output"], "unit": manifest["unit"], "runId": run_id,
    "status": "Prepared and verified; not launched.", "consumedTask152And154And155And156And157Unchanged": True})
for item in inputs.iterdir():
    item.chmod(0o555 if item.name == "native" else 0o600 if item.name == "canary" else 0o444)
inputs.chmod(0o500)
print(json.dumps({"manifestSha256": sha, "candidateHead": head, "unit": manifest["unit"], "buildInputs": len(build_inputs)}))
