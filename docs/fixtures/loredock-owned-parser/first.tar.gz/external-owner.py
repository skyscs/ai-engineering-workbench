from pathlib import Path
import subprocess,json,hashlib,tarfile,time,os,signal
repo=Path('/home/toshiba/aew/worktrees/task140-owned-parser')
root=Path('/home/toshiba/aew/task140-owned-first'); root.mkdir()
node=Path('/home/toshiba/aew/toolchain/node-v22.23.2-linux-x64/bin/node')
def digest(raw):return hashlib.sha256(raw).hexdigest()
def save(name,data):
 with (root/name).open('x') as f:json.dump(data,f,indent=2);f.write('\n')
def inventory(folder):
 return [{'path':str(p.relative_to(folder)),'bytes':p.stat().st_size,'sha256':digest(p.read_bytes())} for p in sorted(folder.rglob('*')) if p.is_file()]
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True),'Commit all candidate inputs before the exclusive first observation.'
inputs=root/'inputs';inputs.mkdir(); files=[]
for name in subprocess.check_output(['git','ls-files'],cwd=repo,text=True).splitlines():
 if name.startswith(('apps/loredock/src/','apps/loredock/tests/fixtures/owned-parser-reference/','scripts/loredock-owned-parser/','docs/fixtures/loredock-async-legacy/baseline/')) or name in ['package.json','pnpm-lock.yaml','.node-version','apps/loredock/package.json','apps/loredock/tsconfig.json','apps/loredock/tests/fixtures/parser-transport-reference/manifest.json']:
  files.append(name)
for pattern in ['apps/loredock/dist/*.js','packages/*/dist/*.js']:
 files.extend(str(p.relative_to(repo)) for p in repo.glob(pattern))
for name in sorted(set(files)):
 p=inputs/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((repo/name).read_bytes())
archive=repo/'docs/fixtures/loredock-parser-transport/first.tar.gz'
assert digest(archive.read_bytes())=='77c99c02c04923ec66cbcd50d5964792c79626a010ed4412f7d466f5489089a0'
original=root/'original-transport';original.mkdir()
with tarfile.open(archive) as tar:
 for member in tar.getmembers():
  assert member.isfile() or member.isdir(); assert not Path(member.name).is_absolute(); assert '..' not in Path(member.name).parts
 tar.extractall(original,filter='data')
original_inventory=inventory(original); input_inventory=inventory(inputs)
assert len(original_inventory)==254
save('inputs.json',{'candidate':head,'node':str(node),'nodeSha256':digest(node.read_bytes()),'transportArchiveSha256':digest(archive.read_bytes()),'candidateFiles':input_inventory,'transportFiles':original_inventory})
args=[str(node),'scripts/loredock-owned-parser/observe.mjs',str(root/'run'),str(original)]
environment={'PATH':str(node.parent)+':/usr/bin:/bin','LC_ALL':'C','OWNED_PARSER_CANDIDATE':head}
save('launch.json',{'args':args,'cwd':str(repo),'environment':environment,'wholeChildMs':120000,'cleanupMs':10000,'resourceQualification':False})
began=time.monotonic(); timedout=False
with (root/'stdout.log').open('xb') as out,(root/'stderr.log').open('xb') as err:
 child=subprocess.Popen(args,cwd=repo,env=environment,stdout=out,stderr=err,start_new_session=True)
 try:code=child.wait(timeout=120)
 except subprocess.TimeoutExpired:
  timedout=True;os.killpg(child.pid,signal.SIGTERM)
  try:code=child.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);code=child.wait(timeout=10)
record={'pid':child.pid,'exit':code,'timedOut':timedout,'wallMs':(time.monotonic()-began)*1000,'actualExit':True,'resourceQualification':False}
save('exit.json',record)
assert inventory(original)==original_inventory;assert inventory(inputs)==input_inventory
save('retention.json',{'originalTransportEntries':len(original_inventory),'candidateEntries':len(input_inventory),'unchanged':True})
print(json.dumps(record));raise SystemExit(code if code>=0 else 1)
