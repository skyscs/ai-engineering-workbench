from pathlib import Path
import hashlib
import json
import shutil
import sqlite3
import subprocess

base = Path('/home/toshiba/aew')
root = base / 'task128-cancel-reopen-first'; run = root / 'run'
output = base / 'task128-cancel-reopen-retention'; output.mkdir()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
def inventory(directory):
    return {str(p.relative_to(directory)): {'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())}
            for p in sorted(directory.rglob('*')) if p.is_file()}
def read(file): return json.loads(file.read_text())
before = inventory(root)
owner = read(root/'result.json'); driver = read(run/'result.json')
assert owner['reason'] == 'driver-failure' and owner['driverExit']['exit'] == 1
assert owner['errors'] == [] and owner['survivors'] == [] and driver['errors'] == []
assert [x['id'] for x in driver['cases']] == ['cold-base','preparation-cancel','provider-cancel','held-shutdown','interrupted-reopen']
assert [x['metric'] for x in driver['baseMetricFailures']] == ['rawIntervalGapMs']
report = {'resourceQualification':False, 'modelCalls':0, 'reservedFamilyReads':0,
          'catalogs':[], 'httpBodies':0, 'redactedSessions':0, 'sourceRepositories':0}
sources = read(run/'sources.json')
for row in sources['originals']:
    raw = (run/'sources'/row['source']/row['path']).read_bytes()
    assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
for source, identity in sources['revisions'].items():
    actual = subprocess.check_output(['git','-c','core.hooksPath=/dev/null','rev-parse','HEAD','HEAD^{tree}'],
        cwd=run/'sources'/source, text=True,
        env={'PATH':'/usr/bin:/bin','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null'}).splitlines()
    assert actual == [identity['revision'],identity['tree']]; report['sourceRepositories'] += 1
for requests in run.rglob('requests.jsonl'):
    pending = {}; responses = set()
    for line in requests.read_text().splitlines():
        event = json.loads(line); key = event['id']
        assert event['event'] != 'failure'
        if event['event'] == 'request': assert key not in pending; pending[key] = event
        elif event['event'] == 'response':
            assert key in pending and key not in responses; responses.add(key)
            raw = (requests.parent/(key+'.json')).read_bytes()
            if pending[key]['route'] == '/session':
                assert json.loads(raw)['token'] == '[removed-session-token]'; report['redactedSessions'] += 1
            else: assert len(raw) == event['bytes']; report['httpBodies'] += 1
    assert set(pending) == responses
cancel = read(run/'preparation-cancel/result.json')
budget, = cancel['cancelled']['budgets']
assert budget['errors'] == {'check:CANCELLED':1} and budget['closes'] == 1
assert budget['final']['totalWork'] == cancel['cancelled']['totalWork'] == 6438
assert cancel['cancelled']['responses'][-1]['openBudgets'] == [budget['id']]
assert cancel['readyControl']['responses'][-1]['openBudgets'] == []
assert cancel['runtime'] == {'prepares':0,'calls':0,'closed':0}
for key in ['lateActivities','unscopedBudgets','unclosedBudgets']: assert cancel['audit'][key] == []
shutdown = read(run/'held-shutdown/result.json'); interrupted = shutdown['checkpoint']
base_checkpoint = read(run/'base/result.json')['checkpoint']
for checkpoint in [base_checkpoint, interrupted]: assert inventory(Path(checkpoint['data'])) == checkpoint['files']
shutdown_events = [json.loads(line) for line in (run/'held-shutdown/journal.jsonl').read_text().splitlines()]
assert [row['name'] for row in shutdown_events if row['event']=='launch-started'] == ['controlled']
assert any(row['event']=='stopped-checkpoint-retained' and row['productionReopen'] is False for row in shutdown_events)
for name, process, controlled, accounting in [('preparation-cancel','diagnostic',True,True),
    ('provider-cancel','controlled',True,False),('held-shutdown','controlled',True,False),
    ('interrupted-reopen','production-reopen',False,False)]:
    value = read(run/name/'result.json'); metadata = read(run/name/process/'process.json')
    assert value['errors']==[] and value['inputCheckpointUnchanged'] is True and value['timingQualified'] is False
    assert metadata['controlled'] is controlled and metadata['accounting'] is accounting
    assert metadata['fault'] is (not accounting)
    if not controlled: assert metadata['args'][-1].endswith('/apps/loredock/dist/index.js')
    assert len(value['exits'])==1 and value['exits'][0]['code']==0 and value['exits'][0]['signal'] is None
    if name in ['provider-cancel','interrupted-reopen']:
        assert value['saved']['rawSha256']==value['replay']['rawSha256']
        assert value['saved']['value']['usage']=={'inputTokens':80,'outputTokens':20,'cachedInputTokens':0}
for original in sorted(run.rglob('loredock.db')):
    relative = original.parent.relative_to(run); copied = output/relative
    copied.parent.mkdir(parents=True,exist_ok=True); shutil.copytree(original.parent,copied)
    assert inventory(original.parent)==inventory(copied)
    db=sqlite3.connect('file:'+str(copied/'loredock.db')+'?mode=ro',uri=True)
    try:
        assert db.execute('PRAGMA integrity_check').fetchall()==[('ok',)]
        assert db.execute('PRAGMA foreign_key_check').fetchall()==[]
        assert db.execute('SELECT status,candidates FROM code_analyses').fetchall()==[('completed',5)]
        db.row_factory=sqlite3.Row
        rows=[dict(x) for x in db.execute('SELECT a.id,a.status,a.context,a.usage,a.result,a.inputKind,w.witness,w.witnessBytes,w.purged,w.reviewedHash FROM answer_attempts a JOIN answer_witnesses w ON a.id=w.answerId')]
        assert db.execute('SELECT count(*) FROM answer_attempts').fetchone()[0]==len(rows)
        assert db.execute('SELECT count(*) FROM answer_witnesses').fetchone()[0]==len(rows)
        populated=relative.parts[0] in ['provider-cancel','held-shutdown','interrupted-reopen']
        assert len(rows)==int(populated)
        if populated:
            held=relative.parts[0]!='provider-cancel'
            attempt=interrupted['attempt'] if held else read(run/'provider-cancel/result.json')['attempt']
            request=read(run/('held-shutdown' if held else 'provider-cancel')/'controlled/request-1.json')
            row,=rows; witness=json.loads(row['witness']); review=attempt['review']
            assert row['id']==attempt['answer']['id'] and row['status']==('interrupted' if held else 'cancelled')
            assert row['inputKind']=='prepared-question/1' and row['result'] is None and row['purged']==0
            assert json.loads(row['usage'])=={'inputTokens':80,'outputTokens':20,'cachedInputTokens':0}
            assert json.loads(row['context'])==review['context'] and row['reviewedHash']==review['reviewedHash']
            assert witness['prompt']==request['prompt'] and witness['compact']==review['compact']
            assert row['witnessBytes']==len(row['witness'].encode())
            assert request['schema']['properties']['claims']['items']['properties']['evidenceIds']['items']['enum']==[x['id'] for x in review['context']['spans']]
        report['catalogs'].append({'source':str(original.parent),'copy':str(copied),'integrity':'ok',
            'foreignKeyErrors':[],'answerStates':[row['status'] for row in rows]})
    finally: db.close()
assert len(report['catalogs'])==7 and report['sourceRepositories']==4
assert inventory(root)==before
report.update(rawInputsUnchanged=True,entries=len(before),baseMetricFailures=driver['baseMetricFailures'],
              cancellationWork=6438,separateProductionReopen=True)
(output/'result.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
