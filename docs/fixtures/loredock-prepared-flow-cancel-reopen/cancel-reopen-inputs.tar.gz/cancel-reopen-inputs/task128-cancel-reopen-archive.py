from pathlib import Path
import json
import re

base=Path('/home/toshiba/aew');helper=base/'task128-kernel-archive.py'
exec(helper.read_text().split("for name in ['core', 'browser', 'crash', 'interruption']:")[0])
repo=base/'worktrees/task128-cancel-reopen';out=repo/'docs/fixtures/loredock-prepared-flow-cancel-reopen'
out.mkdir(exist_ok=True)
records={'schemaVersion':'prepared-flow-cancel-reopen-development/1','resourceQualification':False,
         'modelCalls':0,'reservedFamilyReads':0,'focusedTests':1,'trees':[],'logs':[],
         'acceptedExpiry':{'pr':143,'head':'9cb7ea07e4e1b8de8c8479e362698f2af5818425',
           'merge':'9acd1f3d3cd038a6f160d8c392c5e7916271c13d','push':42021909024,'pull_request':42021916122,'testsPerEvent':981}}
tree('cancel-reopen-first',base/'task128-cancel-reopen-first')
tree('cancel-reopen-retention',base/'task128-cancel-reopen-retention')
for name in ['cancel-reopen-first','cancel-reopen-install','cancel-reopen-build','cancel-reopen-focused',
             'cancel-reopen-retention','cancel-reopen-seal-check','expiry-case-ci-push','expiry-case-ci-pr']:
    raw=log(name,base/('task128-'+name+'.log'))
    for index,location in enumerate(re.findall(r'Retained cancellation-checkpoint test: (/tmp/loredock-cancellation-checkpoint-[A-Za-z0-9]+)',raw)):
        tree(name+'-'+str(index+1),Path(location))
inputs=base/'task128-cancel-reopen-inputs';inputs.mkdir()
for source in [repo/'scripts/loredock-prepared-flow/cancellation-cases.mjs',
               repo/'scripts/loredock-prepared-flow/cancel-reopen-development.mjs',
               repo/'scripts/tests/loredock-cancellation-checkpoint.test.mjs',
               helper,base/'task128-cancel-reopen-retention.py',Path(__file__)]:
    (inputs/source.name).write_bytes(source.read_bytes())
tree('cancel-reopen-inputs',inputs)
records['retention']=json.loads((base/'task128-cancel-reopen-retention/result.json').read_text())
(out/'records.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps({'trees':len(records['trees']),'logs':len(records['logs']),'focusedTests':1},indent=2))
