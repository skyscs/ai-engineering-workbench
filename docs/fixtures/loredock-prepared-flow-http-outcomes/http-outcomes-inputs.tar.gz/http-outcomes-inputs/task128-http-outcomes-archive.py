from pathlib import Path
import json
import re

base=Path('/home/toshiba/aew');helper=base/'task128-kernel-archive.py'
exec(helper.read_text().split("for name in ['core', 'browser', 'crash', 'interruption']:")[0])
repo=base/'worktrees/task128-http-outcomes';out=repo/'docs/fixtures/loredock-prepared-flow-http-outcomes';out.mkdir(exist_ok=True)
accepted=json.loads((base/'task128-integration-handoff.json').read_text())['latestAccepted'];assert accepted['pr']==154 and accepted['testsPerEvent']==1001
records={'schemaVersion':'prepared-flow-http-outcomes-development/1','resourceQualification':False,'modelCalls':0,'reservedFamilyReads':0,'trees':[],'logs':[],'acceptedContentAssessment':accepted}
for name in ['http-outcomes-first','http-outcomes-retention','http-outcomes-first-inputs']:tree(name,base/('task128-'+name))
history=base/'task128-ordered-history-second/run'
for name,source in [('sources',history/'sources'),('checkpoint-20',history/'capacity/checkpoint-20'),('checkpoint-64',history/'capacity/checkpoint-64'),
                    ('quota-http',history/'capacity/http-controlled-continuation'),('quota-process',history/'capacity/controlled-continuation')]:tree('http-outcomes-reused-'+name,source)
for name in ['http-outcomes-first','http-outcomes-install','http-outcomes-build','http-outcomes-tests-first','http-outcomes-tests-second','http-outcomes-browser-tests','http-outcomes-retention','http-outcomes-seal-check','http-outcomes-seal-second','content-assessment-ci-push','content-assessment-ci-pr']:log(name,base/('task128-'+name+'.log'))
for kind in ['tests-first','tests-second','browser-tests']:
    content=(base/('task128-http-outcomes-'+kind+'.log')).read_text()
    for i,location in enumerate(re.findall(r'Retained (?:HTTP-assessor|browser-evidence) test: (/tmp/[A-Za-z0-9-]+)',content)):
        tree('http-outcomes-'+kind+'-'+str(i+1),Path(location))
inputs=base/'task128-http-outcomes-inputs';inputs.mkdir()
for source in [repo/'scripts/loredock-prepared-flow'/name for name in ['http-assess.mjs','http-outcomes-development.mjs','io.mjs','history-cases.mjs']]+[
    repo/'scripts/tests/loredock-http-assess.test.mjs',repo/'scripts/tests/loredock-browser-evidence.test.mjs',helper,base/'task128-http-outcomes-retention.py',Path(__file__),
    repo/'docs/fixtures/loredock-prepared-flow-history/ordered-history-second.inventory.json.gz']:
    (inputs/source.name).write_bytes(source.read_bytes())
(inputs/'quota-reference-result.json').write_bytes((history/'capacity/result.json').read_bytes())
tree('http-outcomes-inputs',inputs)
records['retention']=json.loads((base/'task128-http-outcomes-retention/result.json').read_text())
(out/'records.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps({'trees':len(records['trees']),'logs':len(records['logs'])},indent=2))
