from pathlib import Path
import gzip
import hashlib
import json
import shutil
import sqlite3

base=Path('/home/toshiba/aew');root=base/'task128-http-outcomes-first';run=root/'run';repo=base/'worktrees/task128-http-outcomes'
output=base/'task128-http-outcomes-retention';output.mkdir()
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def read(file):return json.loads(file.read_text())
def inventory(directory):return {str(p.relative_to(directory)):{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(directory.rglob('*')) if p.is_file()}
before=inventory(root);owner=read(root/'result.json');driver=read(run/'result.json')
assert owner['reason']=='completed' and owner['driverExit']['exit']==0 and owner['errors']==[] and owner['survivors']==[] and driver['errors']==[]
report={'resourceQualification':False,'modelCalls':0,'reservedFamilyReads':0,'catalogs':[],'httpBodies':0,'redactedSessions':0,'expectedMissingTransients':0,'reusedInputFiles':0,'exactReopenedAnswers':0,'quotaOutcomes':0}
history=base/'task128-ordered-history-second';manifest=json.loads(gzip.decompress((repo/'docs/fixtures/loredock-prepared-flow-history/ordered-history-second.inventory.json.gz').read_bytes()))
for name,info in manifest.items():
    if any(name.startswith(prefix) for prefix in ['run/sources/','run/capacity/checkpoint-20/','run/capacity/checkpoint-64/','run/capacity/http-controlled-continuation/','run/capacity/controlled-continuation/','run/capacity/result.json']):
        raw=(history/name).read_bytes();assert len(raw)==info['bytes'] and sha(raw)==info['sha256'];report['reusedInputFiles']+=1
samples=[json.loads(line) for line in (root/'storage.jsonl').read_text().splitlines()]
assert len(samples)>=2 and all(row['complete'] and row['racedEntries']==0 for row in samples)
assert max(row['bytes'] for row in samples)==owner['peakSampledStorageBytes']
for row in driver['cases'][:2]:
    count=row['value']['rows'];case=run/('restart-'+str(count));checkpoint=read(case/'input.json');assert inventory(Path(checkpoint['data']))==checkpoint['files']
    value=row['value'];assert value['errors']==[] and value['observation']['transientLost'] is True
    assert value['observation']['list']['rawSha256']==checkpoint['list']['rawSha256']
    assert value['observation']['replaySha256']==checkpoint['admissions'][0]['rawSha256']
    for admission,response in zip(checkpoint['admissions'],value['observation']['answers']):
        assert response['id']==admission['id'] and response['rawSha256']==admission['rawSha256'];report['exactReopenedAnswers']+=1
    process=read(case/'daemon/process.json');assert all(process[k] is False for k in ['controlled','fault','accounting'])
    relative=str((case/'data').relative_to(root));assert relative in owner['catalogRoots'] and process['env']['LOREDOCK_DATA_DIR']==str(case/'data')
    assert max(sample['catalogs'][relative]['bytes'] for sample in samples)==owner['peakSampledCatalogBytes'][relative]
    assert sum(r['bytes'] for r in inventory(case/'data').values())==samples[-1]['catalogs'][relative]['bytes']
    copied=output/('restart-'+str(count))/'data';copied.parent.mkdir(parents=True);shutil.copytree(case/'data',copied);assert inventory(case/'data')==inventory(copied)
    db=sqlite3.connect('file:'+str(copied/'loredock.db')+'?mode=ro',uri=True)
    try:
        assert db.execute('PRAGMA integrity_check').fetchall()==[('ok',)] and db.execute('PRAGMA foreign_key_check').fetchall()==[]
        assert db.execute('SELECT status,count(*) FROM answer_attempts GROUP BY status').fetchall()==[('succeeded',count)]
        assert sorted(x['id'] for x in checkpoint['admissions'])==[x[0] for x in db.execute('SELECT id FROM answer_attempts ORDER BY id')]
        storage=db.execute('SELECT count(*),sum(purged),sum(witnessBytes) FROM answer_witnesses').fetchone();assert storage==(count,0,count*66336)
        report['catalogs'].append({'source':str(case/'data'),'copy':str(copied),'integrity':'ok','foreignKeyErrors':[],'successfulAttempts':count,'witnessStorage':storage})
    finally:db.close()
for file in [*run.rglob('requests.jsonl'),history/'run/capacity/http-controlled-continuation/requests.jsonl']:
    pending={};responses=set()
    for line in file.read_text().splitlines():
        row=json.loads(line);key=row['id'];assert row['event']!='failure'
        if row['event']=='request':assert key not in pending;pending[key]=row
        if row['event']=='response':
            assert key in pending and key not in responses;responses.add(key);raw=(file.parent/(key+'.json')).read_bytes()
            if row['status']>=400:
                assert row['status']==409
                if file.is_relative_to(run):
                    assert key=='00003' and pending[key]['route'].startswith('/question-preparations/') and json.loads(raw)['error']['code']=='QUESTION_NOT_FOUND';report['expectedMissingTransients']+=1
                else:
                    assert key=='00404' and pending[key]['route']=='/prepared-answers' and pending[key]['method']=='POST' and pending[key]['body']['requestId']=='owned-history-over-capacity' and json.loads(raw)['error']['code']=='ANSWER_WITNESS_LIMIT';report['quotaOutcomes']+=1
            if pending[key]['route']=='/session':assert json.loads(raw)['token']=='[removed-session-token]';report['redactedSessions']+=1
            else:assert len(raw)==row['bytes'];report['httpBodies']+=1
    assert set(pending)==responses
assert report['quotaOutcomes']==1
for case in driver['cases']:
    assessment=case['assessment'];assert assessment['status']=='passed' and assessment['failures']==[] and assessment['incomplete']==[] and assessment['resourceQualification'] is False
    expected=assessment['expectedNonSuccess'];assert len(expected)==1 and assessment['matchedExpectedOutcomes']==[expected[0]['id']]
    matched=[r for r in assessment['observations'] if r['expectedOutcome']];assert len(matched)==1 and matched[0]['status']==409
    assert all(check['withinLimit'] for row in assessment['observations'] for check in row['checks'])
assert report['exactReopenedAnswers']==84 and report['expectedMissingTransients']==2 and len(report['catalogs'])==2 and inventory(root)==before
report.update(rawInputsUnchanged=True,entries=len(before),httpOutcomeAssessment='passed-subset')
(output/'result.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
