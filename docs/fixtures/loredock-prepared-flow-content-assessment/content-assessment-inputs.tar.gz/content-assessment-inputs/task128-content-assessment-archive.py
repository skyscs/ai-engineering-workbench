from pathlib import Path
import json

base=Path('/home/toshiba/aew');helper=base/'task128-kernel-archive.py'
exec(helper.read_text().split("for name in ['core', 'browser', 'crash', 'interruption']:")[0])
repo=base/'worktrees/task128-content-assessment';out=repo/'docs/fixtures/loredock-prepared-flow-content-assessment';out.mkdir(exist_ok=True)
accepted=json.loads((base/'task128-integration-handoff.json').read_text())['latestAccepted'];assert accepted['pr']==153 and accepted['testsPerEvent']==996
records={'schemaVersion':'prepared-flow-content-assessment-development/1','resourceQualification':False,'modelCalls':0,'reservedFamilyReads':0,'trees':[],'logs':[],'acceptedResourceAssessment':accepted}
for name in ['content-assessment-first','content-assessment-retention']:tree(name,base/('task128-'+name))
for name,source in [
    ('warm',base/'task128-worker-accounting-case-first/run/warm/data'),
    ('history-20',base/'task128-ordered-history-second/run/capacity/checkpoint-20'),
    ('history-64',base/'task128-ordered-history-second/run/capacity/checkpoint-64'),
    ('purged-64',base/'task128-catalog-faults-first/run/pending-purge/data')]:tree('content-assessment-reused-'+name,source)
for name in ['content-assessment-first','content-assessment-install','content-assessment-build','content-assessment-tests-first','content-assessment-retention','content-assessment-seal-check','resource-assessment-ci-push','resource-assessment-ci-pr']:log(name,base/('task128-'+name+'.log'))
inputs=base/'task128-content-assessment-inputs';inputs.mkdir()
for source in [repo/'scripts/loredock-prepared-flow'/name for name in ['content-assess.mjs','content-assessment-development.mjs']]+[
    repo/'scripts/tests/loredock-content-assessment.test.mjs',helper,base/'task128-content-assessment-retention.py',Path(__file__),
    repo/'docs/fixtures/loredock-prepared-flow-worker-accounting-case/worker-accounting-case-first.inventory.json.gz',
    repo/'docs/fixtures/loredock-prepared-flow-history/ordered-history-second.inventory.json.gz',
    repo/'docs/fixtures/loredock-prepared-flow-catalog-faults/catalog-faults-first.inventory.json.gz']:
    (inputs/source.name).write_bytes(source.read_bytes())
tree('content-assessment-inputs',inputs)
records['retention']=json.loads((base/'task128-content-assessment-retention/result.json').read_text())
(out/'records.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps({'trees':len(records['trees']),'logs':len(records['logs'])},indent=2))
