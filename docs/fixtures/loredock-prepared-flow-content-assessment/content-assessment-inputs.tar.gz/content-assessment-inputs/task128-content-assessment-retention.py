from pathlib import Path
import gzip
import hashlib
import json
import shutil
import sqlite3

base=Path('/home/toshiba/aew');root=base/'task128-content-assessment-first';run=root/'run';repo=base/'worktrees/task128-content-assessment'
output=base/'task128-content-assessment-retention';output.mkdir()
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def read(file):return json.loads(file.read_text())
def inventory(directory):return {str(p.relative_to(directory)):{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(directory.rglob('*')) if p.is_file()}
before=inventory(root);owner=read(root/'result.json');driver=read(run/'result.json')
assert owner['reason']=='completed' and owner['driverExit']['exit']==0 and owner['errors']==[] and owner['survivors']==[] and driver['errors']==[]
assert all(driver[key]==0 for key in ['candidatePreparations','controlledCalls','modelCalls','reservedFamilyReads'])
report={'resourceQualification':False,'modelCalls':0,'reservedFamilyReads':0,'candidatePreparations':0,'catalogs':[],'boundInputFiles':0,'checkedWitnesses':0,'purgedTombstones':0,'boundReviews':0}
for raw_root,manifest_file,prefixes in [
    (base/'task128-worker-accounting-case-first',repo/'docs/fixtures/loredock-prepared-flow-worker-accounting-case/worker-accounting-case-first.inventory.json.gz',['run/warm/data/','run/cold/result.json','run/warm/result.json']),
    (base/'task128-ordered-history-second',repo/'docs/fixtures/loredock-prepared-flow-history/ordered-history-second.inventory.json.gz',['run/capacity/checkpoint-20/','run/capacity/checkpoint-64/']),
    (base/'task128-catalog-faults-first',repo/'docs/fixtures/loredock-prepared-flow-catalog-faults/catalog-faults-first.inventory.json.gz',['run/pending-purge/data/'])]:
    manifest=json.loads(gzip.decompress(manifest_file.read_bytes()))
    for name,info in manifest.items():
        if any(name.startswith(prefix) for prefix in prefixes):
            raw=(raw_root/name).read_bytes();assert len(raw)==info['bytes'] and sha(raw)==info['sha256'];report['boundInputFiles']+=1
for row in driver['cases']:
    case=run/row['id'];value=row['value'];inputs=read(case/'inputs.json');checkpoint=inputs['checkpoint'];assert inventory(Path(checkpoint['data']))==checkpoint['files']
    assert value['errors']==[] and value['inputUnchanged'] is True and value['assessment']['status']=='passed'
    copied=output/row['id']/'data';copied.parent.mkdir(parents=True);shutil.copytree(case/'data',copied);assert inventory(case/'data')==inventory(copied)
    db=sqlite3.connect('file:'+str(copied/'loredock.db')+'?mode=ro',uri=True)
    try:
        assert db.execute('PRAGMA integrity_check').fetchall()==[('ok',)] and db.execute('PRAGMA foreign_key_check').fetchall()==[]
        rows=db.execute('SELECT w.answerId,w.purged,w.contextHash,w.reviewedHash,w.witness,w.witnessBytes,a.context FROM answer_witnesses w JOIN answer_attempts a ON a.id=w.answerId ORDER BY w.answerId').fetchall()
        assert len(rows)==inputs['expectedRows']==value['assessment']['rows']
        for stored,observation in zip(rows,value['assessment']['observations']):
            answer,purged,context_hash,reviewed,witness_raw,witness_bytes,context_raw=stored
            assert observation['answerId']==answer and observation['purged']==bool(purged)
            if purged:
                assert witness_raw is None and context_raw is None and witness_bytes==0;report['purgedTombstones']+=1;continue
            assert sha(context_raw.encode())==context_hash and len(witness_raw.encode())==witness_bytes
            context=json.loads(context_raw);witness=json.loads(witness_raw);content=observation['content']
            assert content['contextSha256']==context_hash and content['witnessSha256']==sha(witness_raw.encode())
            assert content['reviewedHash']==reviewed and content['nativePresent'] is True and content['status']=='passed'
            measured=content['measured'];assert measured=={'witnessRowBytes':66336,'retainedPreparationBytes':91335,'promptBytes':23232,'nativeAndLegacyDerivedBytes':7519,'sourceEvidenceBytes':2259,'sourceEvidenceSpans':11}
            assert measured['promptBytes']==len(witness['prompt'].encode()) and measured['sourceEvidenceBytes']==sum(len(span['text'].encode()) for span in context['spans'])
            assert all(check['passed'] and check['value']<=check['limit'] for check in content['checks']);report['checkedWitnesses']+=1
        assert sum(s[5] for s in rows)==value['assessment']['totalBytes']
        for reference,bound in zip(inputs['reviews'],value['boundReviews']):
            assert reference['name']==bound['name'] and reference['review']['reviewedHash']==bound['reviewedHash']
            matched=next(s for s in rows if s[0]==bound['retainedAnswerId']);assert matched[3]==bound['reviewedHash']
            assert json.loads(matched[6])==reference['review']['context'] and json.loads(matched[4])['compact']==reference['review']['compact'];report['boundReviews']+=1
        report['catalogs'].append({'source':str(case/'data'),'copy':str(copied),'integrity':'ok','foreignKeyErrors':[],'rows':len(rows),'purged':sum(s[1] for s in rows),'witnessBytes':sum(s[5] for s in rows)})
    finally:db.close()
assert len(report['catalogs'])==4 and report['checkedWitnesses']==87 and report['purgedTombstones']==64 and report['boundReviews']==4 and inventory(root)==before
report.update(rawInputsUnchanged=True,entries=len(before))
(output/'result.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
