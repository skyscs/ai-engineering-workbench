from pathlib import Path
import gzip
import hashlib
import io
import json
import os
import re
import stat
import tarfile

base = Path('/home/toshiba/aew')
repo = base / 'worktrees/task128-process-ownership'
out = repo / 'docs/fixtures/loredock-prepared-flow-owner'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
records = {'schemaVersion': 'prepared-flow-kernel-owner-development/1', 'resourceQualification': False,
           'modelCalls': 0, 'reservedFamilyReads': 0, 'base': 'f59530782fd63c289c0daa50ae850cd19eed33f4',
           'tests': {'focused': 6, 'full': 954, 'fullCheckPassed': True}, 'trees': [], 'logs': []}

def tree(name, source, limitation=None):
    manifest, excluded = {}, set()
    destination = out / (name + '.tar.gz')
    assert not destination.exists()
    with tarfile.open(destination, 'w:gz') as archive:
        for directory, dirs, files in os.walk(source, followlinks=False):
            for child in sorted(dirs + files):
                p = Path(directory) / child
                rel = p.relative_to(source)
                parts = rel.parts
                profile = next((i for i, part in enumerate(parts) if part == 'profile' and i and parts[i-1] == 'browser'), None)
                if profile is not None:
                    excluded.add(str(Path(*parts[:profile+1])))
                    continue
                value = p.lstat()
                if stat.S_ISDIR(value.st_mode):
                    continue
                info = tarfile.TarInfo(name + '/' + str(rel))
                info.mode, info.mtime = 0o600, 0
                if stat.S_ISLNK(value.st_mode):
                    target = os.readlink(p)
                    manifest[str(rel)] = {'kind': 'symlink', 'target': target}
                    info.type, info.linkname = tarfile.SYMTYPE, target
                    archive.addfile(info)
                else:
                    assert stat.S_ISREG(value.st_mode), str(p)
                    raw = p.read_bytes()
                    manifest[str(rel)] = {'kind': 'file', 'bytes': len(raw), 'sha256': sha(raw)}
                    info.size = len(raw)
                    archive.addfile(info, io.BytesIO(raw))
    inventory = out / (name + '.inventory.json.gz')
    inventory.write_bytes(gzip.compress((json.dumps(manifest, indent=2) + '\n').encode(), mtime=0))
    row = {'path': destination.name, 'sha256': sha(destination.read_bytes()), 'inventory': inventory.name,
           'inventorySha256': sha(inventory.read_bytes()), 'entries': len(manifest), 'source': str(source)}
    if excluded:
        row['excludedFromArchive'] = [p + ' (temporary Chrome profile/cache; original retained locally)' for p in sorted(excluded)]
    if limitation:
        row['limitation'] = limitation
    records['trees'].append(row)

def log(name, source):
    destination = out / (name + '.log.gz')
    assert not destination.exists()
    raw = source.read_bytes()
    destination.write_bytes(gzip.compress(raw, mtime=0))
    records['logs'].append({'path': destination.name, 'archiveSha256': sha(destination.read_bytes()),
                            'rawBytes': len(raw), 'rawSha256': sha(raw)})
    return raw.decode()

for name in ['core', 'browser', 'crash', 'interruption']:
    limitation = ('Earlier owner revision before descriptor-based no-follow storage traversal; executable bytes '
                  'were not sealed for this ordinary observation.') if name == 'core' else None
    tree('kernel-' + name + '-first', base / ('task128-kernel-' + name + '-first'), limitation)
    log('kernel-' + name + '-first', base / ('task128-kernel-' + name + '-first.log'))
for name in ['tests-first', 'tests-second', 'check-first']:
    raw = log('kernel-' + name, base / ('task128-kernel-' + name + '.log'))
    for i, location in enumerate(re.findall(r'Retained kernel-owner test: (/tmp/loredock-kernel-(?:adoption|owner)-[A-Za-z0-9]+)', raw)):
        tree('kernel-' + name + '-case-' + str(i+1), Path(location),
             'Earlier owner/test revision before no-follow traversal and symlink-storage assertion.' if name == 'tests-first' else None)
tree('kernel-retention-check', base / 'task128-kernel-retention-check')
for name in ['retention-check', 'interruption-injector', 'seal-check']:
    log('kernel-' + name, base / ('task128-kernel-' + name + '.log'))
for name in ['owner-install', 'owner-build']:
    log(name, base / ('task128-' + name + '.log'))
inputs = base / 'task128-kernel-execution-inputs'
inputs.mkdir()
for source in [repo/'scripts/loredock-prepared-flow/kernel-owner.py',
               repo/'scripts/loredock-prepared-flow/owner-failure-development.mjs',
               repo/'scripts/tests/loredock-kernel-owner.test.mjs',
               base/'task128-kernel-interruption-driver.py', base/'task128-kernel-interruption-first.injector.json',
               base/'task128-kernel-retention-check.py', Path(__file__)]:
    (inputs / source.name).write_bytes(source.read_bytes())
tree('kernel-execution-inputs', inputs)
records['stoppedRetention'] = json.loads((base/'task128-kernel-retention-check/result.json').read_text())
(out/'execution-records.json').write_text(json.dumps(records, indent=2) + '\n')
print(json.dumps({'trees': len(records['trees']), 'logs': len(records['logs']), 'tests': records['tests']}, indent=2))
