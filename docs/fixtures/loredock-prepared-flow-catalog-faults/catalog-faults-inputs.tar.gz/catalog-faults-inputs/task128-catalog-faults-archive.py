from pathlib import Path
import json

base=Path('/home/toshiba/aew');helper=base/'task128-kernel-archive.py'
exec(helper.read_text().split("for name in ['core', 'browser', 'crash', 'interruption']:")[0])
repo=base/'worktrees/task128-catalog-faults';out=repo/'docs/fixtures/loredock-prepared-flow-catalog-faults';out.mkdir(exist_ok=True)
accepted=json.loads((base/'task128-integration-handoff.json').read_text())['latestAccepted']
assert accepted['pr']==148 and accepted['testsPerEvent']==983
records={'schemaVersion':'prepared-flow-catalog-faults-development/1','resourceQualification':False,
         'modelCalls':0,'reservedFamilyReads':0,'trees':[],'logs':[],'acceptedValidators':accepted}
tree('catalog-faults-first',base/'task128-catalog-faults-first');tree('catalog-faults-retention',base/'task128-catalog-faults-retention')
cold=base/'task128-inventory-eviction-first/run';history=base/'task128-ordered-history-second/run'
for name,source in [('cold-sources',cold/'sources'),('cold-checkpoint',cold/'base/checkpoint'),
                    ('history-sources',history/'sources'),('history-checkpoint',history/'capacity/checkpoint-64')]:
    tree('catalog-faults-reused-'+name,source)
for name in ['catalog-faults-first','catalog-faults-install','catalog-faults-build','catalog-faults-retention',
             'catalog-faults-seal-check','validator-cases-ci-push','validator-cases-ci-pr']:
    log(name,base/('task128-'+name+'.log'))
inputs=base/'task128-catalog-faults-inputs';inputs.mkdir()
for source in [repo/'scripts/loredock-prepared-flow/validator-cases.mjs',repo/'scripts/loredock-prepared-flow/catalog-fault-cases.mjs',
               repo/'scripts/loredock-prepared-flow/catalog-faults-development.mjs',helper,base/'task128-catalog-faults-retention.py',
               repo/'docs/fixtures/loredock-prepared-flow-history/ordered-history-second.inventory.json.gz',
               repo/'docs/fixtures/loredock-prepared-flow-inventory-eviction/inventory-eviction-first.inventory.json.gz',Path(__file__)]:
    (inputs/source.name).write_bytes(source.read_bytes())
for name,source in [('cold-sources.json',cold/'sources.json'),('history-sources.json',history/'sources.json')]:
    (inputs/name).write_bytes(source.read_bytes())
tree('catalog-faults-inputs',inputs)
records['retention']=json.loads((base/'task128-catalog-faults-retention/result.json').read_text())
(out/'records.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps({'trees':len(records['trees']),'logs':len(records['logs'])},indent=2))
