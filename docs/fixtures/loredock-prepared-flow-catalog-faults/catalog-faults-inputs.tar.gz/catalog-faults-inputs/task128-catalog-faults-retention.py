from pathlib import Path
import gzip
import hashlib
import json
import shutil
import sqlite3

base=Path('/home/toshiba/aew');root=base/'task128-catalog-faults-first';run=root/'run';repo=base/'worktrees/task128-catalog-faults'
output=base/'task128-catalog-faults-retention';output.mkdir()
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def read(file):return json.loads(file.read_text())
def inventory(directory):return {str(p.relative_to(directory)):{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(directory.rglob('*')) if p.is_file()}
before=inventory(root);owner=read(root/'result.json');driver=read(run/'result.json');inputs=read(run/'inputs.json')
assert owner['reason']=='completed' and owner['driverExit']['exit']==0 and owner['errors']==[] and owner['survivors']==[] and driver['errors']==[]
report={'resourceQualification':False,'modelCalls':0,'reservedFamilyReads':0,'catalogs':[],'httpBodies':0,'redactedSessions':0,'expectedFailureResponses':0,'reusedInputFiles':0}
for raw_root,manifest_file,prefixes in [
    (base/'task128-inventory-eviction-first',repo/'docs/fixtures/loredock-prepared-flow-inventory-eviction/inventory-eviction-first.inventory.json.gz',['run/sources/','run/base/checkpoint/']),
    (base/'task128-ordered-history-second',repo/'docs/fixtures/loredock-prepared-flow-history/ordered-history-second.inventory.json.gz',['run/sources/','run/capacity/checkpoint-64/'])]:
    manifest=json.loads(gzip.decompress(manifest_file.read_bytes()))
    for name,info in manifest.items():
        if any(name.startswith(prefix) for prefix in prefixes):
            raw=(raw_root/name).read_bytes();assert len(raw)==info['bytes'] and sha(raw)==info['sha256'];report['reusedInputFiles']+=1
for checkpoint in [inputs['base'],inputs['history']]:assert inventory(Path(checkpoint['data']))==checkpoint['files']
for file in run.rglob('requests.jsonl'):
    pending={};responses=set()
    for line in file.read_text().splitlines():
        row=json.loads(line);key=row['id'];assert row['event']!='failure'
        if row['event']=='request':assert key not in pending;pending[key]=row
        if row['event']=='response':
            assert key in pending and key not in responses;responses.add(key)
            raw=(file.parent/(key+'.json')).read_bytes()
            if row['status']>=400:
                assert row['status']==500 and pending[key]['route'].endswith('/revoke');report['expectedFailureResponses']+=1
            if pending[key]['route']=='/session':assert json.loads(raw)['token']=='[removed-session-token]';report['redactedSessions']+=1
            else:assert len(raw)==row['bytes'];report['httpBodies']+=1
    assert set(pending)==responses
assert report['expectedFailureResponses']==1
purge=read(run/'pending-purge/result.json')
assert len(purge['pendingAnswers'])==len(purge['recoveredAnswers'])==64 and purge['pendingCheckpointUnchanged'] is True
assert inventory(Path(purge['pendingCheckpoint']['data']))==purge['pendingCheckpoint']['files']
assert purge['replayed']['rawSha256']==purge['recoveredAnswers'][0]['rawSha256']
for case in driver['cases']:
    value=case['value'];assert value['errors']==[] and value['inputCheckpointUnchanged'] is True and value['timingQualified'] is False
    for process in (run/case['id']).glob('*/process.json'):assert read(process)['fault'] is True
    if case['id'].startswith('original-'):
        assert value['runtime']=={'prepares':1,'calls':0,'closed':1}
        assert value['terminal']['value']['status']=='failed' and value['terminal']['rawSha256']==value['replayed']['rawSha256']
        for key in ['answer','usage','dispatchedAt']:assert value['terminal']['value'][key] is None
        assert not (run/case['id']/'controlled/request-1.json').exists()
for original in sorted(run.rglob('loredock.db')):
    relative=original.parent.relative_to(run);copied=output/relative;copied.parent.mkdir(parents=True,exist_ok=True)
    shutil.copytree(original.parent,copied);assert inventory(original.parent)==inventory(copied)
    db=sqlite3.connect('file:'+str(copied/'loredock.db')+'?mode=ro',uri=True)
    try:
        assert db.execute('PRAGMA integrity_check').fetchall()==[('ok',)] and db.execute('PRAGMA foreign_key_check').fetchall()==[]
        states=db.execute('SELECT status,count(*) FROM answer_attempts GROUP BY status').fetchall()
        storage=db.execute('SELECT count(*),sum(purged),sum(witnessBytes) FROM answer_witnesses').fetchone()
        if relative.parts[0]=='pending-purge':
            ids=[row[0] for row in db.execute('SELECT id FROM answer_attempts ORDER BY id')]
            assert ids==sorted(x['id'] for x in inputs['history']['admissions'])
            source=db.execute('SELECT status,purge FROM sources WHERE id=?',(purge['sourceId'],)).fetchone()
            trigger=db.execute("SELECT count(*) FROM sqlite_master WHERE name='owned_purge_failure'").fetchone()[0]
            if relative.parts[-1]=='pending-checkpoint':
                assert source==('revoked','pending') and trigger==1 and storage==(64,0,4245504)
                contexts=db.execute('SELECT context FROM answer_attempts').fetchall();assert len(contexts)==64
                for context, in contexts:assert not any(span['sourceName']==inputs['sourceName'] for span in json.loads(context)['spans'])
            else:
                assert source==('revoked','completed') and trigger==0 and storage==(64,64,0) and states==[('fenced',64)]
                assert db.execute('SELECT count(*) FROM answer_attempts WHERE context IS NOT NULL OR result IS NOT NULL').fetchone()==(0,)
        else:
            value=read(run/relative.parts[0]/'result.json');review=value['prepared']['review']
            assert states==[('failed',1)] and storage[0:2]==(1,0) and storage[2]>0
            stored=db.execute('SELECT context,result,usage,dispatchedAt FROM answer_attempts').fetchone()
            assert json.loads(stored[0])==review['context'] and stored[1:]==(None,None,None)
            witness,reviewed=db.execute('SELECT witness,reviewedHash FROM answer_witnesses').fetchone()
            assert reviewed==review['reviewedHash'] and json.loads(witness)['compact']==review['compact']
            original_row=db.execute('SELECT text FROM spans WHERE id=?',(value['original'],)).fetchone()
            assert original_row==(None if value['kind']=='missing' else ('Owned corrupted original.',))
        report['catalogs'].append({'source':str(original.parent),'copy':str(copied),'integrity':'ok','foreignKeyErrors':[],'answerStates':states,'witnessStorage':storage})
    finally:db.close()
assert len(report['catalogs'])==4 and inventory(root)==before
for checkpoint in [inputs['base'],inputs['history'],purge['pendingCheckpoint']]:assert inventory(Path(checkpoint['data']))==checkpoint['files']
report.update(rawInputsUnchanged=True,entries=len(before))
(output/'result.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
