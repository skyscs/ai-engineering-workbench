record PermitGranted(String tenant, String permit) {}
interface EventPublisher { void publish(String topic, String key, PermitGranted event); }
final class Grants {
  private final EventPublisher publisher;
  Grants(EventPublisher publisher) { this.publisher = publisher; }
  void issue(String tenant, String permit) {
    var event = new PermitGranted(tenant, permit);
    publisher.publish(configuredTopic(), tenant, event);
  }
}
