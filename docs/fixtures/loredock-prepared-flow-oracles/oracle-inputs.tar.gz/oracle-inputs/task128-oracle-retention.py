from pathlib import Path
import hashlib
import json
import shutil
import sqlite3

base = Path('/home/toshiba/aew')
output = base / 'task128-oracle-retention'
output.mkdir()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
def tree(root):
    return {str(file.relative_to(root)): sha(file.read_bytes()) for file in sorted(root.rglob('*')) if file.is_file()}

root = base/'task128-oracle-setup-first'
reassessment = base/'task128-oracle-reassessment-first'
before = {str(directory): tree(directory) for directory in [root, reassessment]}
for directory in [root, reassessment]:
    owner = json.loads((directory/'result.json').read_text())
    assert owner['reason'] == 'driver-failure' and owner['driverExit']['exit'] == 1
    assert not owner['errors'] and not owner['survivors']
original = json.loads((root/'run/result.json').read_text())
corrected = json.loads((reassessment/'run/result.json').read_text())
assert not original['errors'] and not corrected['errors'] and corrected['rawInputTreeUnchanged']
assert len(original['cases']) == len(corrected['cases']) == 10
assert [row['id'] for row in original['cases'] if row['errors']] == ['D01-complete-path','D03-consumer-gap','D04-dynamic-topic']
assert [row['id'] for row in corrected['cases'] if row['errors']] == ['D01-complete-path']
assert corrected['candidatePreparations'] == 0
results = []
for row, checked in zip(original['cases'], corrected['cases']):
    assert row['id'] == checked['id'] and row['preparations'] == 1
    directory = root/'run'/row['id']
    sources = json.loads((directory/'sources.json').read_text())
    oracle = json.loads((directory/'oracle.json').read_text())
    for reference in sources['originals']:
        raw = (directory/'sources'/reference['source']/reference['path']).read_bytes()
        assert len(raw) == reference['bytes'] and sha(raw) == reference['sha256']
    spans = row['review']['context']['spans']
    for name in oracle['expected']['requiredOriginals']:
        reference = oracle['references'][name]
        assert any(span['sourceName'] == reference['source'] and span['path'] == reference['path']
                   and reference['quote'] in span['text'] for span in spans)
    if row['id'] == 'D01-complete-path':
        assert row['review']['compact']['reason'] == 'derived-size'
        assert row['review']['compact']['derivedBytes'] == 8368 and row['review']['compact']['item'] is None
    if row['id'] in ['D03-consumer-gap', 'D04-dynamic-topic']:
        item = row['review']['compact']['item']
        assert item['omissions'][oracle['expected']['native']['requiredGap']] == 1
        assert not {'event-delivery','dispatch-candidate'} & {edge[0] for edge in item['edges']}
    if row['id'] == 'D09-human-note':
        note = row['note']
        assert note['provenance'] == 'human' and note['verification'] == 'unverified'
        assert any(note['statement'] == n['statement'] and n['provenance'] == 'human' and n['verification'] == 'unverified'
                   for n in row['review']['context']['review']['notes'])
    copy = output/row['id']/'data'
    shutil.copytree(directory/'data', copy)
    connection = sqlite3.connect((copy/'loredock.db').as_uri()+'?mode=ro',uri=True)
    assert connection.execute('PRAGMA integrity_check').fetchall() == [('ok',)]
    assert connection.execute('PRAGMA foreign_key_check').fetchall() == []
    assert connection.execute('SELECT count(*) FROM answer_attempts').fetchone()[0] == 0
    analysis = connection.execute('SELECT count(*) FROM code_analyses').fetchone()[0]
    assert analysis == (0 if row['id'] == 'D07-no-analysis' else 1)
    connection.close()
    results.append({'id':row['id'], 'integrity':'ok', 'foreignKeys':[], 'answers':0, 'analyses':analysis,
                    'requiredOriginalsPresent':len(oracle['expected']['requiredOriginals']),
                    'originalFailed':bool(row['errors']), 'correctedAssessmentFailed':bool(checked['errors'])})
for directory in [root,reassessment]: assert tree(directory) == before[str(directory)]
report = {'cases':results, 'originalCandidatePreparations':10, 'newCandidatePreparationsForReassessment':0,
          'sourceHashesUnchanged':True,'rawTreesUnchangedByInspection':True,'modelCalls':0,'reservedFamilyReads':0}
(output/'result.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
