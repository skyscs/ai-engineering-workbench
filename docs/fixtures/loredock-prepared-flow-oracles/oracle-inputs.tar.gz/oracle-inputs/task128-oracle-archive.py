from pathlib import Path
import json
import re

base = Path('/home/toshiba/aew')
helper = base/'task128-kernel-archive.py'
exec(helper.read_text().split("for name in ['core', 'browser', 'crash', 'interruption']:")[0])
repo = base/'worktrees/task128-oracle-setup'
out = repo/'docs/fixtures/loredock-prepared-flow-oracles'
records = {'schemaVersion':'prepared-flow-oracle-development/1', 'resourceQualification':False,
           'modelCalls':0, 'reservedFamilyReads':0, 'tests':958, 'trees':[], 'logs':[],
           'acceptedHistory': {'pr':137,'head':'3498a0333844970a51ded597dc5a2cb8a32880eb',
                               'merge':'4ccf622847e3c3d8905d14270c41fb234088cf25',
                               'push':42006715733,'pull_request':42006778571,'testsPerEvent':957}}
for name in ['oracle-setup-first','oracle-reassessment-first']:
    tree(name, base/('task128-'+name),
         'The first run retains three assessment failures and exit 1.' if name == 'oracle-setup-first' else
         'Offline reassessment changes no original bytes and performs zero candidate preparations. The genuine complete-path positive still fails and exits 1.')
    log(name,base/('task128-'+name+'.log'))
tree('oracle-retention',base/'task128-oracle-retention')
tree('oracle-first-inputs',base/'task128-oracle-first-inputs')
for name in ['oracle-install','oracle-build','oracle-focused','oracle-focused-corrected','oracle-check-first','oracle-check-corrected','oracle-retention','oracle-seal-check','ordered-ci-push','ordered-ci-pr']:
    raw=log(name,base/('task128-'+name+'.log'))
    if name.startswith('oracle-check-'):
        for i,location in enumerate(re.findall(r'Retained kernel-owner test: (/tmp/loredock-kernel-(?:adoption|owner)-[A-Za-z0-9]+)',raw)):
            tree(name+'-owner-'+str(i+1),Path(location))
        for i,location in enumerate(re.findall(r'Retained history-checkpoint test: (/tmp/loredock-history-checkpoint-[A-Za-z0-9]+)',raw)):
            tree(name+'-checkpoint-'+str(i+1),Path(location))
inputs=base/'task128-oracle-inputs'; inputs.mkdir()
for source in [repo/'scripts/loredock-prepared-flow/ordinary-oracles.mjs',
               repo/'scripts/loredock-prepared-flow/oracle-setup-development.mjs',
               repo/'scripts/loredock-prepared-flow/reassess-oracle-development.mjs',
               repo/'scripts/loredock-prepared-flow/assess.mjs',
               repo/'scripts/tests/loredock-prepared-flow-driver.test.mjs',helper,
               base/'task128-oracle-retention.py',Path(__file__)]:
    (inputs/source.name).write_bytes(source.read_bytes())
tree('oracle-inputs',inputs)
records['retention']=json.loads((base/'task128-oracle-retention/result.json').read_text())
(out/'records.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps({'trees':len(records['trees']),'logs':len(records['logs']),'tests':records['tests']},indent=2))
