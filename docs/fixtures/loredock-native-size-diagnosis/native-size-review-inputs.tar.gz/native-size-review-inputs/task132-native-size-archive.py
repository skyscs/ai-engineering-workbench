from pathlib import Path
import json

base = Path('/home/toshiba/aew')
helper = base / 'task128-kernel-archive.py'
exec(helper.read_text().split("for name in ['core', 'browser', 'crash', 'interruption']:")[0])
repo = base / 'worktrees/task132-native-size'
out = repo / 'docs/fixtures/loredock-native-size-diagnosis'
assert not (out / 'records.json').exists()
records = {'schemaVersion': 'retained-native-size-diagnosis/1', 'base': '4d856e4543822bcc2ba10622301b72f033ec411d',
    'firstCode': 'a688a03e10808c37f63a6fe9c178e0c513f1081f', 'applicationRuns': 0, 'modelCalls': 0,
    'reservedFamilyReads': 0, 'resourceQualification': False, 'trees': [], 'logs': []}
tree('native-size-first', base / 'task132-native-size-first')
for name in ['native-size-first', 'native-size-syntax']:
    log(name, base / ('task132-' + name + '.log'))
for event in ['push', 'pr']:
    log('accepted-history-ci-' + event, base / ('task131-history-ci-' + event + '.log'))
inputs = base / 'task132-native-size-review-inputs'
inputs.mkdir()
for file in [helper, Path(__file__), base / 'task132-native-size-static.py', base / 'task131-integration-handoff.json']:
    (inputs / file.name).write_bytes(file.read_bytes())
tree('native-size-review-inputs', inputs)
for name in ['retention', 'diagnosis']:
    records[name] = json.loads((base / 'task132-native-size-first' / (name + '.json')).read_bytes())
(out / 'records.json').write_text(json.dumps(records, indent=2) + '\n')
print(json.dumps({'trees': len(records['trees']), 'entries': sum(row['entries'] for row in records['trees']),
    'logs': len(records['logs']), 'resourceQualification': False}, indent=2))
