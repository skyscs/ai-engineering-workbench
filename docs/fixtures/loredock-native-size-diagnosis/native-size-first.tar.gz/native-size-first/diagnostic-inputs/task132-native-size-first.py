"""Attribute one retained ordinary result without application execution or input mutation."""
from pathlib import Path
import gzip
import hashlib
import json
import os
import shutil
import sqlite3
import subprocess

base = Path('/home/toshiba/aew')
repo = base / 'worktrees/task132-native-size'
original = base / 'task128-matrix-first/run/matrix/R14-oracle-preconditions/D01-complete-path'
out = base / 'task132-native-size-first'
out.mkdir()
copied = out / 'retained-ordinary'
sha = lambda value: hashlib.sha256(value).hexdigest()

def inventory(root):
    result = {}
    for parent, dirs, files in os.walk(root, followlinks=False):
        for name in sorted(dirs + files):
            file = Path(parent) / name
            key = str(file.relative_to(root))
            if file.is_symlink():
                result[key] = {'kind': 'symlink', 'target': os.readlink(file)}
            elif file.is_file():
                raw = file.read_bytes()
                result[key] = {'kind': 'file', 'bytes': len(raw), 'sha256': sha(raw)}
    return result

manifest = repo / 'docs/fixtures/loredock-prepared-flow-matrix-integration/matrix-first.inventory.json.gz'
prefix = 'run/matrix/R14-oracle-preconditions/D01-complete-path/'
expected = {key[len(prefix):]: value for key, value in json.loads(gzip.decompress(manifest.read_bytes())).items() if key.startswith(prefix)}
assert len(expected) == 152
before = inventory(original)
assert before == expected
shutil.copytree(original, copied)
assert inventory(copied) == before
input_data = json.loads((copied / 'case/inputs.json').read_bytes())
result = json.loads((copied / 'case/result.json').read_bytes())
review = result['review']
source_files = 0
env = {'PATH': '/usr/bin:/bin', 'LC_ALL': 'C', 'GIT_CONFIG_NOSYSTEM': '1', 'GIT_CONFIG_GLOBAL': '/dev/null', 'GIT_OPTIONAL_LOCKS': '0'}
for name, identity in input_data['sources']['revisions'].items():
    for key, ref in [('revision', 'HEAD'), ('tree', 'HEAD^{tree}')]:
        assert subprocess.check_output(['/usr/bin/git', 'rev-parse', ref], cwd=copied / 'sources' / name, env=env, text=True).strip() == identity[key]
for row in input_data['sources']['originals']:
    raw = (copied / 'sources' / row['source'] / row['path']).read_bytes()
    assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
    source_files += 1
for span in review['context']['spans']:
    text = (copied / 'sources' / span['sourceName'] / span['path']).read_text()
    assert span['text'] == '\n'.join(text.splitlines()[span['startLine'] - 1:span['endLine']])
    assert span['revision'] == input_data['sources']['revisions'][span['sourceName']]['revision']
for key in input_data['expected']['requiredOriginals']:
    row = input_data['references'][key]
    assert any(span['sourceName'] == row['source'] and span['path'] == row['path'] and row['quote'] in span['text'] for span in review['context']['spans'])
db = sqlite3.connect('file:' + str(copied / 'case/data/loredock.db') + '?mode=ro', uri=True)
try:
    assert db.execute('PRAGMA integrity_check').fetchall() == [('ok',)]
    assert db.execute('PRAGMA foreign_key_check').fetchall() == []
    assert db.execute('SELECT count(*) FROM answer_attempts').fetchone()[0] == 0
    assert db.execute('SELECT count(*) FROM answer_witnesses').fetchone()[0] == 0
finally:
    db.close()
source = repo / 'apps/loredock/src/question-context.ts'
assert subprocess.check_output(['git', 'show', '848cf97:apps/loredock/src/question-context.ts'], cwd=repo) == source.read_bytes()
inputs = out / 'diagnostic-inputs'
inputs.mkdir()
for file in [Path(__file__), repo / 'scripts/loredock-native-size/retained.mjs', source,
             repo / 'apps/loredock/src/question-preparation-types.ts', repo / 'apps/loredock/src/question-witness.ts',
             repo / 'apps/loredock/src/answer-witness-store.ts', repo / 'apps/loredock/src/answer-history.ts']:
    (inputs / file.name).write_bytes(file.read_bytes())
node = base / 'toolchain/node-v22.23.2-linux-x64/bin/node'
command = [str(node), str(repo / 'scripts/loredock-native-size/retained.mjs'), str(copied / 'case/result.json'), str(out / 'diagnosis.json')]
with (out / 'diagnostic.log').open('x') as log:
    process = subprocess.run(command, cwd=repo, env=env, text=True, stdout=log, stderr=subprocess.STDOUT, timeout=10)
assert process.returncode == 0
assert inventory(original) == before
report = {'originalEntries': len(before), 'copiedEntriesBeforeSqlite': len(before), 'originalUnchanged': True,
          'acceptedInventory': str(manifest.relative_to(repo)), 'acceptedInventorySha256': sha(manifest.read_bytes()),
          'gitSources': len(input_data['sources']['revisions']), 'sourceFiles': source_files,
          'originalSpans': len(review['context']['spans']), 'requiredOriginals': len(input_data['expected']['requiredOriginals']),
          'copiedCatalogIntegrity': 'ok', 'answers': 0, 'witnesses': 0,
          'serializerUnchangedSince': '848cf97', 'serializerSha256': sha(source.read_bytes()),
          'codeCommit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip(),
          'command': command, 'exit': process.returncode, 'applicationRuns': 0, 'modelCalls': 0, 'reservedFamilyReads': 0,
          'resourceQualification': False}
(out / 'retention.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'retention': report, 'diagnosis': json.loads((out / 'diagnosis.json').read_bytes())}, indent=2))
