"""Independently review stopped history copies and retain exact first-run identities."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import sqlite3
import subprocess

base = Path('/home/toshiba/aew')
root = base / 'task131-history-first'
out = base / 'task131-history-retention'
out.mkdir()
read = lambda path: json.loads(path.read_bytes())
sha = lambda value: hashlib.sha256(value).hexdigest()
encode = lambda value: json.dumps(value, ensure_ascii=False, separators=(',', ':')).encode()

def inventory(directory):
    result = {}
    for parent, dirs, files in os.walk(directory, followlinks=False):
        for name in sorted(dirs + files):
            file = Path(parent) / name
            key = str(file.relative_to(directory))
            if file.is_symlink():
                result[key] = {'target': os.readlink(file)}
            elif file.is_file():
                raw = file.read_bytes()
                result[key] = {'bytes': len(raw), 'sha256': sha(raw)}
    return result

before = inventory(root)
owner, run = read(root / 'result.json'), read(root / 'run/result.json')
snapshot = read(base / 'task131-history-first-inputs/execution.json')
assert owner['reason'] == 'completed' and owner['driverExit']['exit'] == 0
assert owner['errors'] == owner['survivors'] == run['errors'] == []
assert set(owner['observedCatalogRoots']) == set(owner['catalogRoots']) == set(snapshot['catalogRoots'])
report = {'catalogs': [], 'sourceFiles': 0, 'gitIdentities': 0, 'originalChecks': 0,
          'httpResponses': 0, 'sessionRedactions': 0, 'listControls': [], 'controlledCalls': 64,
          'modelCalls': 0, 'reservedFamilyReads': 0, 'resourceQualification': False}
sources = read(root / 'run/sources.json')
env = {'PATH': '/usr/bin:/bin', 'LC_ALL': 'C', 'GIT_CONFIG_NOSYSTEM': '1',
       'GIT_CONFIG_GLOBAL': '/dev/null', 'GIT_OPTIONAL_LOCKS': '0'}
for source, files in snapshot['corpus'].items():
    directory = root / 'run/sources' / source
    for key, ref in [('revision', 'HEAD'), ('tree', 'HEAD^{tree}')]:
        assert subprocess.check_output(['/usr/bin/git', 'rev-parse', ref], cwd=directory, env=env, text=True).strip() == sources['revisions'][source][key]
    assert not subprocess.check_output(['/usr/bin/git', 'status', '--porcelain'], cwd=directory, env=env)
    report['gitIdentities'] += 1
    for name, text in files.items():
        raw = (directory / name).read_bytes()
        assert raw == text.encode()
        original = next(row for row in sources['originals'] if row['source'] == source and row['path'] == name)
        assert len(raw) == original['bytes'] and sha(raw) == original['sha256']
        report['sourceFiles'] += 1

for relative in owner['catalogRoots']:
    original, copied = root / relative, out / relative
    copied.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(original, copied)
    assert inventory(original) == inventory(copied)
    db = sqlite3.connect('file:' + str(copied / 'loredock.db') + '?mode=ro', uri=True)
    db.row_factory = sqlite3.Row
    try:
        assert [tuple(row) for row in db.execute('PRAGMA integrity_check')] == [('ok',)]
        assert list(db.execute('PRAGMA foreign_key_check')) == []
        rows = list(db.execute('SELECT a.*,w.preparationId,w.contextHash,w.reviewedHash,w.witness,w.witnessBytes,w.purged FROM answer_attempts a JOIN answer_witnesses w ON w.answerId=a.id'))
        expected = 20 if relative.endswith(('checkpoint-20', 'restart-20/data', 'accounting-20/data')) else 64
        assert len(rows) == expected
        assert db.execute('SELECT count(*) FROM answer_attempts').fetchone()[0] == expected
        purged = 0
        for row in rows:
            assert row['inputKind'] == 'prepared-question/1'
            if row['purged']:
                purged += 1
                assert row['context'] is None and row['witness'] is None and row['result'] is None and row['witnessBytes'] == 0
                continue
            assert row['status'] == 'succeeded'
            assert sha(row['context'].encode()) == row['contextHash']
            witness, context = json.loads(row['witness']), json.loads(row['context'])
            assert len(row['witness'].encode()) == row['witnessBytes']
            assert sha(encode([witness['compositionVersion'], row['context'], row['witness']])) == row['reviewedHash']
            assert sha(encode({'preparationId': row['preparationId'], 'reviewedHash': row['reviewedHash']})) == row['payloadHash']
            content = {key: value for key, value in context.items() if key != 'inputHash'}
            assert sha(encode(content)) == context['inputHash'] == row['inputHash']
            assert witness['compact']['item'] is not None
            assert [item[0] for item in db.execute('SELECT sourceId FROM answer_sources WHERE answerId=? ORDER BY sourceId', (row['id'],))] == witness['sourceIds']
            for span in context['spans']:
                text = snapshot['corpus'][span['sourceName']][span['path']]
                assert span['text'] == '\n'.join(text.splitlines()[span['startLine'] - 1:span['endLine']])
                assert span['revision'] == sources['revisions'][span['sourceName']]['revision']
                report['originalChecks'] += 1
        assert purged == (64 if relative == 'run/revocation-64/data' else 0)
        report['catalogs'].append({'relative': relative, 'rows': len(rows), 'purged': purged, 'integrity': 'ok'})
    finally:
        db.close()

for events in root.rglob('requests.jsonl'):
    requests, responses = {}, set()
    for row in map(json.loads, events.read_text().splitlines()):
        key = row['id']
        if row['event'] == 'request':
            assert key not in requests
            requests[key] = row
        else:
            assert row['event'] == 'response' and key in requests and key not in responses
            responses.add(key)
            raw = (events.parent / (key + '.json')).read_bytes()
            if requests[key]['route'] == '/session':
                assert json.loads(raw)['token'] == '[removed-session-token]'
                report['sessionRedactions'] += 1
            else:
                assert len(raw) == row['bytes']
            report['httpResponses'] += 1
    assert set(requests) == responses

cases = {row['name']: row['value'] for row in run['cases']}
assert sum(row['calls'] for row in cases['capacity']['runtimeSegments']) == 64
assert len(cases['capacity']['admissions']) == 64
for count in [20, 64]:
    reopened = cases['restart-' + str(count)]['observation']
    accounted = cases['accounting-' + str(count)]
    assert reopened['list']['rawSha256'] == accounted['list']['rawSha256']
    assert len(reopened['list']['value']['attempts']) == 20
    assert all(row['status'] == 'succeeded' and row['inputValidation'] == 'metadata-only' for row in reopened['list']['value']['attempts'])
    assert len(reopened['answers']) == count
    assert len(accounted['accounting']['budgets']) == 1
    assert accounted['accounting']['totalWork'] == 257241
    report['listControls'].append({'storedRows': count, 'returnedRows': 20, 'fullDetails': count,
        'productionWallMs': reopened['list']['elapsedMs'], 'aggregateWork': accounted['accounting']['totalWork'],
        'closedBudgets': 1})
assert len(report['catalogs']) == 8
assert inventory(root) == before
report.update(rawEntries=len(before), rawUnchanged=True)
(out / 'raw-inventory.json').write_text(json.dumps(before, indent=2) + '\n')
(out / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
