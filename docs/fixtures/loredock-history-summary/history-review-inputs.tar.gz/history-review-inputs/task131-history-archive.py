from pathlib import Path
import json

base = Path('/home/toshiba/aew')
helper = base / 'task128-kernel-archive.py'
exec(helper.read_text().split("for name in ['core', 'browser', 'crash', 'interruption']:")[0])
repo = base / 'worktrees/task131-history-summary'
out = repo / 'docs/fixtures/loredock-history-summary'
assert not (out / 'records.json').exists()
records = {'schemaVersion': 'ordinary-history-summary/1', 'base': '12b1392870b7aa30a30e4f58c22030270b48de1a',
    'firstCode': '7765ba2', 'resourceQualification': False, 'modelCalls': 0, 'reservedFamilyReads': 0,
    'trees': [], 'logs': []}
for name in ['history-first', 'history-first-inputs', 'history-retention']:
    tree(name, base / ('task131-' + name))
for name in ['history-build-first', 'history-tests-first', 'history-typecheck-first', 'history-legacy-tests-first',
             'history-first', 'history-script-tests-first', 'history-retention']:
    log(name, base / ('task131-' + name + '.log'))
for event in ['push', 'pr']:
    log('accepted-cold-start-ci-' + event, base / ('task130-cold-ci-final-' + event + '.log'))
inputs = base / 'task131-history-review-inputs'
inputs.mkdir()
for file in [helper, Path(__file__), base / 'task131-history-static.py', base / 'task131-history-retain.py',
             base / 'task131-history-first-launch.py', base / 'task130-integration-handoff.json']:
    (inputs / file.name).write_bytes(file.read_bytes())
for name in ['apps/loredock/src/answer-history.ts', 'apps/loredock/src/answers.ts',
             'scripts/tests/loredock-prepared-answers.test.mjs']:
    target = inputs / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes((repo / name).read_bytes())
tree('history-review-inputs', inputs)
records['retention'] = json.loads((base / 'task131-history-retention/result.json').read_bytes())
(out / 'records.json').write_text(json.dumps(records, indent=2) + '\n')
print(json.dumps({'trees': len(records['trees']), 'entries': sum(row['entries'] for row in records['trees']),
    'logs': len(records['logs']), 'resourceQualification': False}, indent=2))
