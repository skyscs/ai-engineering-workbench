from pathlib import Path
import hashlib
import json
import shutil
import sqlite3
import subprocess

base=Path('/home/toshiba/aew');root=base/'task128-inventory-eviction-first';run=root/'run'
output=base/'task128-inventory-eviction-retention';output.mkdir()
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def read(file):return json.loads(file.read_text())
def inventory(directory):return {str(p.relative_to(directory)):{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(directory.rglob('*')) if p.is_file()}
before=inventory(root);owner=read(root/'result.json');driver=read(run/'result.json');result=read(run/'eviction/result.json')
assert owner['reason']=='driver-failure' and owner['driverExit']['exit']==1 and owner['errors']==[] and owner['survivors']==[]
assert driver['errors']==[] and result['errors']==[] and result['resourceSubsetPassed'] is False
report={'resourceQualification':False,'modelCalls':0,'reservedFamilyReads':0,'catalogs':[],'httpBodies':0,'redactedSessions':0,'sourceRepositories':0,'segments':[]}
sources=read(run/'sources.json')
for row in sources['originals']:
    raw=(run/'sources'/row['source']/row['path']).read_bytes();assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
for source,identity in sources['revisions'].items():
    actual=subprocess.check_output(['git','-c','core.hooksPath=/dev/null','rev-parse','HEAD','HEAD^{tree}'],cwd=run/'sources'/source,
      text=True,env={'PATH':'/usr/bin:/bin','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null'}).splitlines()
    assert actual==[identity['revision'],identity['tree']];report['sourceRepositories']+=1
for file in run.rglob('requests.jsonl'):
    pending={};responses=set()
    for line in file.read_text().splitlines():
        row=json.loads(line);key=row['id'];assert row['event']!='failure'
        if row['event']=='request':assert key not in pending;pending[key]=row
        if row['event']=='response':
            assert key in pending and key not in responses;responses.add(key)
            raw=(file.parent/(key+'.json')).read_bytes()
            if pending[key]['route']=='/session':assert json.loads(raw)['token']=='[removed-session-token]';report['redactedSessions']+=1
            else:assert len(raw)==row['bytes'];report['httpBodies']+=1
    assert set(pending)==responses
assert len(result['replacements'])==5 and len({x['id'] for x in result['replacements']})==5
assert all(x['buildId']==result['buildId'] and x['status']=='completed' and x['published'] and x['currentParser'] for x in result['replacements'])
assert result['prepared']['review']==result['reviewAfterEviction']['value']
assert result['runtime']=={'prepares':1,'calls':1,'closed':1}
assert result['saved']['rawSha256']==result['reopened']['rawSha256']==result['replayed']['rawSha256']
for checkpoint in [read(run/'base/result.json')['checkpoint'],result['beforeReopen']]:
    assert checkpoint['lane']=='resource' and inventory(Path(checkpoint['data']))==checkpoint['files']
for segment in result['segments']:
    name=segment['name'];process=read(run/'eviction'/name/'process.json')
    assert process['fault'] is False and process['accounting'] is False
    assert process['controlled'] is (name=='controlled')
    samples=[json.loads(line) for line in (run/'eviction'/name/'memory-timer.jsonl').read_text().splitlines()]
    assert samples[0]['event']=='start' and samples[-1]['event']=='exit-0'
    assert segment['metrics']['measured']['rawIntervalGapMs']==max(x['gapMs'] for x in samples)
    assert [x['metric'] for x in segment['metrics']['checks'] if not x['passed']]==['rawIntervalGapMs']
    assert segment['http']['status']=='passed' and segment['http']['timingQualified'] is True
    report['segments'].append({'name':name,'httpResponses':len(segment['http']['observations']),
        'httpChecks':sum(len(x['checks']) for x in segment['http']['observations']),'rawIntervalGapMs':segment['metrics']['measured']['rawIntervalGapMs']})
for original in sorted(run.rglob('loredock.db')):
    relative=original.parent.relative_to(run);copied=output/relative;copied.parent.mkdir(parents=True,exist_ok=True)
    shutil.copytree(original.parent,copied);assert inventory(original.parent)==inventory(copied)
    db=sqlite3.connect('file:'+str(copied/'loredock.db')+'?mode=ro',uri=True)
    try:
        assert db.execute('PRAGMA integrity_check').fetchall()==[('ok',)] and db.execute('PRAGMA foreign_key_check').fetchall()==[]
        states=db.execute('SELECT status,count(*) FROM answer_attempts GROUP BY status').fetchall()
        rows=db.execute('SELECT id,buildId,status FROM code_analyses').fetchall()
        populated=relative.parts[0]=='eviction'
        assert states==([('succeeded',1)] if populated else [])
        assert db.execute('SELECT count(*) FROM answer_witnesses').fetchone()==(int(populated),)
        if populated:
            assert result['initialInventory'] not in [x[0] for x in rows]
            assert result['replacements'][-1]['id'] in [x[0] for x in rows]
            assert all(x[0] in [y['id'] for y in result['replacements']] and x[1]==result['buildId'] and x[2]=='completed' for x in rows)
            context,witness,reviewed,purged=db.execute('SELECT a.context,w.witness,w.reviewedHash,w.purged FROM answer_attempts a JOIN answer_witnesses w ON a.id=w.answerId').fetchone()
            review=result['prepared']['review'];request=read(run/'eviction/controlled/request-1.json')
            assert json.loads(context)==review['context'] and reviewed==review['reviewedHash'] and purged==0
            assert json.loads(witness)['compact']==review['compact'] and json.loads(witness)['prompt']==request['prompt']
            assert request['schema']['properties']['claims']['items']['properties']['evidenceIds']['items']['enum']==[x['id'] for x in review['context']['spans']]
        else:assert len(rows)==1 and rows[0][0]==result['initialInventory']
        report['catalogs'].append({'source':str(original.parent),'copy':str(copied),'integrity':'ok','foreignKeyErrors':[],
          'answerStates':states,'retainedInventories':len(rows),'initialInventoryPresent':result['initialInventory'] in [x[0] for x in rows]})
    finally:db.close()
assert len(report['catalogs'])==4 and report['sourceRepositories']==4
assert inventory(root)==before
report.update(rawInputsUnchanged=True,entries=len(before),replacements=5,baseMetricFailures=driver['baseMetricFailures'])
(output/'result.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
