from pathlib import Path
import json
import re

base=Path('/home/toshiba/aew');helper=base/'task128-kernel-archive.py'
exec(helper.read_text().split("for name in ['core', 'browser', 'crash', 'interruption']:")[0])
repo=base/'worktrees/task128-inventory-eviction';out=repo/'docs/fixtures/loredock-prepared-flow-inventory-eviction';out.mkdir(exist_ok=True)
accepted=json.loads((base/'task128-integration-handoff.json').read_text())['latestAccepted']
assert accepted['pr']==146 and accepted['testsPerEvent']==982
records={'schemaVersion':'prepared-flow-inventory-eviction-development/1','resourceQualification':False,
         'modelCalls':0,'reservedFamilyReads':0,'focusedTests':1,'trees':[],'logs':[],'acceptedBrowserFences':accepted}
tree('inventory-eviction-first',base/'task128-inventory-eviction-first')
tree('inventory-eviction-retention',base/'task128-inventory-eviction-retention')
for name in ['inventory-eviction-first','inventory-eviction-install','inventory-eviction-build','inventory-eviction-focused',
             'inventory-eviction-retention','inventory-eviction-seal-check','browser-fences-ci-push','browser-fences-ci-pr']:
    raw=log(name,base/('task128-'+name+'.log'))
    for index,location in enumerate(re.findall(r'Retained eviction-checkpoint test: (/tmp/loredock-eviction-checkpoint-[A-Za-z0-9]+)',raw)):
        tree(name+'-'+str(index+1),Path(location))
inputs=base/'task128-inventory-eviction-inputs';inputs.mkdir()
for source in [repo/'scripts/loredock-prepared-flow/cold-warm-cases.mjs',repo/'scripts/loredock-prepared-flow/inventory-eviction-case.mjs',
               repo/'scripts/loredock-prepared-flow/inventory-eviction-development.mjs',repo/'scripts/tests/loredock-eviction-checkpoint.test.mjs',
               helper,base/'task128-inventory-eviction-retention.py',Path(__file__)]:
    (inputs/source.name).write_bytes(source.read_bytes())
tree('inventory-eviction-inputs',inputs)
records['retention']=json.loads((base/'task128-inventory-eviction-retention/result.json').read_text())
(out/'records.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps({'trees':len(records['trees']),'logs':len(records['logs']),'focusedTests':1},indent=2))
