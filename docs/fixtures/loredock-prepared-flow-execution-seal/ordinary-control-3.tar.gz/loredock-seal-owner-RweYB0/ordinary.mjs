import assert from 'node:assert/strict';
import {readFile,realpath,writeFile} from 'node:fs/promises';
import {assertLaunchBoundary} from "file:///home/toshiba/aew/worktrees/task128-execution-seal/scripts/loredock-prepared-flow/execution-verify.mjs";
const output="/tmp/loredock-seal-owner-RweYB0/output", command=["/usr/bin/python3.14","-I","-S","-B","/home/toshiba/aew/worktrees/task128-execution-seal/scripts/loredock-prepared-flow/kernel-owner.py","--node","/home/toshiba/aew/toolchain/node-v22.23.2-linux-x64/bin/node","--script","/tmp/loredock-seal-owner-RweYB0/ordinary.mjs","--output","/tmp/loredock-seal-owner-RweYB0/output","--cwd","/home/toshiba/aew/worktrees/task128-execution-seal"], env={"PATH":"/home/toshiba/aew/toolchain/node-v22.23.2-linux-x64/bin:/usr/bin:/bin","LC_ALL":"C","HOME":"/tmp/loredock-seal-owner-RweYB0/home"};
const driver=JSON.parse(await readFile(output+'/command.json'));
const events=(await readFile(output+'/owner.jsonl','utf8')).trimEnd().split('\n').map(JSON.parse);
const parent={pid:process.ppid,executable:await realpath('/proc/'+process.ppid+'/exe'),args:(await readFile('/proc/'+process.ppid+'/cmdline','utf8')).split('\0').filter(Boolean)};
const family='kiln-prepared-flow-127';
const manifest={schemaVersion:'prepared-flow-execution-seal/1',repository:process.cwd(),driver,command,
 limits:{wallMs:2400000,storageBytes:2147483648,catalogBytes:536870912,graceMs:10000,forcedExitWaitMs:5000},
 plan:{family,ownerOutput:output,claimPath:output+'.claim'}};
assert.deepEqual(driver.env,env);
assertLaunchBoundary({manifest,family,directory:output+'/run/matrix',claimPath:output+'.claim',argv:process.argv,
 env:{...process.env},cwd:process.cwd(),executable:process.execPath,parent,command:driver,events,pid:process.pid});
await writeFile(output+'/boundary.json',JSON.stringify({verified:true,candidateReads:0,familyClaimed:false}),{flag:'wx'});
