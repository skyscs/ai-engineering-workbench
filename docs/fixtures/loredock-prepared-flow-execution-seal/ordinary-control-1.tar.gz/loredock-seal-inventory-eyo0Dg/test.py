import importlib.util,json,pathlib,sys
p=pathlib.Path(sys.argv[1]); spec=importlib.util.spec_from_file_location('seal',sys.argv[2]); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
m.REPOSITORY=p
a=p/'one'; a.write_text('same-size-a'); b=p/'two'; b.write_text('same-size-b'); link=p/'link'; link.symlink_to(a)
first=m.inventory([p]); a.write_text('same-size-c'); second=m.inventory([p]); assert first[str(a)]['sha256']!=second[str(a)]['sha256']
(p/'extra').write_text('extra'); third=m.inventory([p]); assert second[str(p)]['names']!=third[str(p)]['names']
link.unlink(); link.symlink_to(b); fourth=m.inventory([p]); assert third[str(link)]!=fourth[str(link)]
try: m.file_record(link)
except OSError: pass
else: raise AssertionError('No-follow file hashing accepted a symlink')
print(json.dumps({'changedBytes':True,'extraFile':True,'changedLink':True,'noFollow':True}))
