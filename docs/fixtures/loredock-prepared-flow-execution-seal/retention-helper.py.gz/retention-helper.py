from pathlib import Path
import gzip
import hashlib
import json
import re
import tarfile

workspace = Path('/home/toshiba/aew')
repository = workspace / 'worktrees/task128-execution-seal'
output = repository / 'docs/fixtures/loredock-prepared-flow-execution-seal'
records_path = output / 'records.json'
records = json.loads(records_path.read_text())
sha = lambda raw: hashlib.sha256(raw).hexdigest()
names = ['install', 'build', 'input-seal', 'tests-first', 'tests-second', 'matrix-plan-tests',
         'create-first', 'create-second', 'verify-first']
for name in names:
    source = workspace / ('task128-execution-seal-' + name + '.log')
    raw = source.read_bytes()
    packed = gzip.compress(raw, mtime=0)
    destination = output / ('execution-seal-' + name + '.log.gz')
    with destination.open('xb') as file:
        file.write(packed)
    records['logs'].append({'path': destination.name, 'bytes': len(packed), 'sha256': sha(packed),
                           'uncompressedBytes': len(raw), 'uncompressedSha256': sha(raw)})

controls = []
for name in ['tests-first', 'tests-second']:
    text = (workspace / ('task128-execution-seal-' + name + '.log')).read_text()
    controls.extend(Path(value) for value in re.findall(r'Retained (?:seal-inventory test|actual seal-owner control): ([^\n]+)', text))
assert len(controls) == 3
records['controls'] = []
for index, source in enumerate(controls, 1):
    inventory = {}
    destination = output / ('ordinary-control-' + str(index) + '.tar.gz')
    assert not destination.exists()
    with tarfile.open(destination, 'w:gz') as archive:
        for file in sorted(source.rglob('*')):
            relative = str(file.relative_to(source))
            if file.is_symlink():
                target = str(file.readlink())
                inventory[relative] = {'kind': 'symlink', 'target': target}
            elif file.is_file():
                raw = file.read_bytes()
                inventory[relative] = {'kind': 'file', 'bytes': len(raw), 'sha256': sha(raw)}
            else:
                continue
            archive.add(file, arcname=source.name + '/' + relative, recursive=False)
    raw = destination.read_bytes()
    records['controls'].append({'path': destination.name, 'source': str(source), 'prefix': source.name,
                                'bytes': len(raw), 'sha256': sha(raw), 'inventory': inventory})

manifest_raw = (output / 'manifest.json').read_bytes()
manifest = json.loads(manifest_raw)
index_raw = (output / 'manifest.inventory.json.gz').read_bytes()
index = json.loads(gzip.decompress(index_raw))
assert sha(index_raw) == manifest['index']['sha256']
records['seal'] = {'path': 'manifest.json', 'sha256': sha(manifest_raw), 'sourceCommit': manifest['sourceCommit'],
                   'inventoryPath': 'manifest.inventory.json.gz', 'inventorySha256': sha(index_raw), 'entries': len(index),
                   'files': sum(value['kind'] == 'file' for value in index.values()),
                   'links': sum(value['kind'] == 'symlink' for value in index.values()),
                   'directories': sum(value['kind'] == 'directory' for value in index.values()),
                   'fileBytes': sum(value.get('bytes', 0) for value in index.values()),
                   'workspaceGraphModules': len(manifest['importAudit']['modules']),
                   'externalEntries': len(manifest['importAudit']['externalEntries']),
                   'priorRoots': len(manifest['priorObservationAudit']['roots']),
                   'priorSourceRecords': len(manifest['priorObservationAudit']['sourceRecords'])}
records['validation'] = {'newTests': 6, 'existingCoordinatorTests': 9, 'existingAdapterTests': 7, 'existingMatrixTests': 3,
                         'firstManifestCreation': 'Failed before writing either artifact on the distro sitecustomize link; first code commit and log retained.',
                         'firstCodeCommit': '58d5ccbad-placeholder', 'successfulCreation': 'create-second',
                         'committedManifestVerification': 'verify-first', 'candidateReads': 0, 'modelCalls': 0}
# Resolve the retained first code identity from its unambiguous repository prefix outside the manifest.
import subprocess
records['validation']['firstCodeCommit'] = subprocess.check_output(['git', 'rev-parse', '58d5ccb'], cwd=repository, text=True).strip()
helper = Path(__file__)
raw = helper.read_bytes()
packed = gzip.compress(raw, mtime=0)
destination = output / 'retention-helper.py.gz'
with destination.open('xb') as file:
    file.write(packed)
records['helper'] = {'path': destination.name, 'sha256': sha(packed), 'uncompressedSha256': sha(raw)}
records_path.write_text(json.dumps(records, indent=2) + '\n')
print(json.dumps({'logs': len(records['logs']), 'controls': len(controls), 'controlEntries': sum(len(row['inventory']) for row in records['controls']),
                  'sealEntries': len(index), 'candidateReads': 0, 'modelCalls': 0}))
