from pathlib import Path
from urllib.parse import unquote
import ast
import gzip
import hashlib
import json
import re
import subprocess
import tarfile

root = Path('/home/toshiba/aew/worktrees/task128-execution-seal')
out = root / 'docs/fixtures/loredock-prepared-flow-execution-seal'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
records = json.loads((out / 'records.json').read_bytes())
for row in records['logs']:
    raw = (out / row['path']).read_bytes()
    assert sha(raw) == row['sha256'] and len(raw) == row['bytes']
    content = gzip.decompress(raw)
    assert sha(content) == row['uncompressedSha256'] and len(content) == row['uncompressedBytes']
entries = 0
for row in records['controls']:
    raw = (out / row['path']).read_bytes()
    assert sha(raw) == row['sha256'] and len(raw) == row['bytes']
    with tarfile.open(out / row['path'], 'r:gz') as archive:
        prefix = row['prefix'] + '/'
        assert {member.name.removeprefix(prefix) for member in archive.getmembers()} == set(row['inventory'])
        for relative, expected in row['inventory'].items():
            member = archive.getmember(prefix + relative)
            if expected['kind'] == 'symlink':
                assert member.issym() and member.linkname == expected['target']
            else:
                assert member.isfile()
                content = archive.extractfile(member).read()
                assert sha(content) == expected['sha256'] and len(content) == expected['bytes']
            entries += 1
manifest_raw = (out / 'manifest.json').read_bytes()
assert sha(manifest_raw) == records['seal']['sha256']
manifest = json.loads(manifest_raw)
raw = (out / 'manifest.inventory.json.gz').read_bytes()
assert sha(raw) == manifest['index']['sha256'] == records['seal']['inventorySha256']
inventory = json.loads(gzip.decompress(raw))
assert len(inventory) == records['seal']['entries'] == 17254
for file in manifest['sourcePaths']:
    assert sha((root / file).read_bytes()) == inventory[str(root / file)]['sha256'], file
for file in manifest['importAudit']['modules']:
    assert sha(Path(file).read_bytes()) == inventory[file]['sha256'], file
for file in manifest['importAudit']['externalEntries']:
    assert sha(Path(file).read_bytes()) == inventory[file]['sha256'], file
base = '3fc1b46335370014b2edc22921e3750e5b080010'
assert not subprocess.check_output(['git', 'diff', '--name-only', base, '--', 'apps', 'packages', 'fixtures', '.github',
    'pnpm-lock.yaml', 'package.json', 'tasks/128-loredock-prepared-flow-resource-qualification.md',
    'docs/loredock/PREPARED_FLOW_QUALIFICATION.md'], cwd=root).strip()
changed = set(subprocess.check_output(['git', 'diff', '--name-only', base], cwd=root, text=True).splitlines() +
              subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=root, text=True).splitlines())
links = 0
for name in changed:
    file = root / name
    if file.suffix not in ['.md', '.json', '.mjs', '.py']:
        continue
    text = file.read_text()
    assert not re.search('[А-Яа-яЁё]', text), name
    if file.suffix == '.py':
        ast.parse(text)
    if file.suffix == '.json':
        json.loads(text)
    if file.suffix != '.md':
        continue
    text = re.sub(r'```[^\n]*\n.*?```', '', text, flags=re.S)
    text = re.sub(r'`[^`\n]*`', '', text)
    for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)', text):
        if re.match(r'^(https?://|mailto:|#)', target):
            continue
        target = unquote(target.split('#')[0].split(' "')[0].strip('<>'))
        if target:
            assert (file.parent / target).exists(), (name, target)
            links += 1
assert not Path(manifest['plan']['ownerOutput']).exists()
assert not Path(manifest['plan']['claimPath']).exists()
print(json.dumps({'logs': len(records['logs']), 'controls': len(records['controls']), 'controlEntries': entries,
                  'sealEntries': len(inventory), 'localLinks': links, 'applicationAndFrozenInputsUnchanged': True,
                  'reservedOutputAndClaimAbsent': True, 'candidateReads': 0, 'modelCalls': 0}, indent=2))
