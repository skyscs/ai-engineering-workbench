from pathlib import Path
import json
import re

base = Path('/home/toshiba/aew')
# Reuse the retained no-follow archive helpers; retain this exact dependency too.
helper = base / 'task128-kernel-archive.py'
exec(helper.read_text().split("for name in ['core', 'browser', 'crash', 'interruption']:")[0])
repo = base / 'worktrees/task128-boundary-observation'
out = repo / 'docs/fixtures/loredock-prepared-flow-boundaries'
records = {'schemaVersion': 'prepared-flow-cancellation-observation-development/1', 'resourceQualification': False,
           'modelCalls': 0, 'reservedFamilyReads': 0, 'tests': 955, 'trees': [], 'logs': [],
           'acceptedOwner': {'pr': 133, 'head': '59e3f277cde1c49a6328829ed57a785373bb7920',
                             'merge': '8da3df9759b1852a0b4a3faeb504eb6f4ff0c253',
                             'push': 41994419744, 'pull_request': 41994481613, 'testsPerEvent': 954}}
for name in ['cancellation-observation-first', 'cancellation-observation-second', 'boundary-accounting-parity']:
    tree(name, base / ('task128-' + name), 'Earlier driver before the additional Ready-cancellation negative control.' if name.endswith('first') else None)
    log(name, base / ('task128-' + name + '.log'))
tree('boundary-retention', base / 'task128-boundary-retention')
for name in ['boundary-focused-first', 'boundary-check-first', 'boundary-install', 'boundary-build', 'boundary-seal-check', 'boundary-retention', 'kernel-ci-push', 'kernel-ci-pr']:
    raw = log(name, base / ('task128-' + name + '.log'))
    if name == 'boundary-check-first':
        for i, location in enumerate(re.findall(r'Retained kernel-owner test: (/tmp/loredock-kernel-(?:adoption|owner)-[A-Za-z0-9]+)', raw)):
            tree('boundary-check-owner-' + str(i+1), Path(location))
inputs = base / 'task128-boundary-inputs'
for source in [repo/'scripts/loredock-prepared-flow/accounting.mjs', repo/'scripts/loredock-prepared-flow/launcher.mjs',
               repo/'scripts/loredock-prepared-flow/cancellation-observation-development.mjs',
               repo/'scripts/tests/loredock-prepared-flow-driver.test.mjs', helper,
               base/'task128-boundary-retention.py', Path(__file__)]:
    (inputs / source.name).write_bytes(source.read_bytes())
tree('boundary-inputs', inputs)
records['retention'] = json.loads((base / 'task128-boundary-retention/result.json').read_text())
(out/'records.json').write_text(json.dumps(records, indent=2) + '\n')
print(json.dumps({'trees': len(records['trees']), 'logs': len(records['logs']), 'tests': records['tests']}, indent=2))
