from pathlib import Path
import hashlib
import json
import shutil
import sqlite3

base = Path('/home/toshiba/aew')
output = base / 'task128-boundary-retention'
output.mkdir()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
def tree(root):
    return {str(p.relative_to(root)): sha(p.read_bytes()) for p in sorted(root.rglob('*')) if p.is_file()}
results = []
for name in ['cancellation-observation-first', 'cancellation-observation-second', 'boundary-accounting-parity']:
    root = base / ('task128-' + name)
    before = tree(root)
    owner = json.loads((root / 'result.json').read_text())
    assert owner['reason'] == 'completed' and not owner['errors'] and not owner['survivors']
    source = json.loads((root / 'run/sources.json').read_text())
    for row in source['originals']:
        raw = (root / 'run/sources' / row['source'] / row['path']).read_bytes()
        assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
    databases = []
    for db in sorted((root / 'run').glob('*/loredock.db')):
        destination = output / name / db.parent.name
        shutil.copytree(db.parent, destination)
        copy = destination / db.name
        connection = sqlite3.connect(copy.as_uri() + '?mode=ro', uri=True)
        assert connection.execute('PRAGMA integrity_check').fetchall() == [('ok',)]
        assert connection.execute('PRAGMA foreign_key_check').fetchall() == []
        databases.append({'directory': db.parent.name, 'integrity': 'ok', 'foreignKeys': [],
                          'answers': connection.execute('SELECT status FROM answer_attempts').fetchall()})
        connection.close()
    assert tree(root) == before
    results.append({'case': name, 'sourceHashesUnchanged': True, 'rawTreeUnchangedByInspection': True,
                    'databases': databases, 'ownerErrors': [], 'ownedSurvivors': []})
(output / 'result.json').write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps(results, indent=2))
