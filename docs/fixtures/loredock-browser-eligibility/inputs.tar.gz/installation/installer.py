from pathlib import Path, PurePosixPath
import base64
import hashlib
import json
import os
import shutil
import stat
import subprocess
import time
import zipfile

root = Path('/home/toshiba/aew/toolchain/task143-chrome-for-testing-157.0.8103.38')
root.mkdir()
version = '157.0.8103.38'
catalog_url = 'https://googlechromelabs.github.io/chrome-for-testing/last-known-good-versions-with-downloads.json'
archive_url = 'https://storage.googleapis.com/chrome-for-testing-public/157.0.8103.38/linux64/chrome-linux64.zip'

def digest(file, algorithm='sha256'):
    with file.open('rb') as handle:
        return hashlib.file_digest(handle, algorithm).hexdigest()

def save(name, value):
    with (root / name).open('x') as handle:
        json.dump(value, handle, indent=2)
        handle.write('\n')

save('retrieval-plan.json', {'version': version, 'catalogURL': catalog_url, 'archiveURL': archive_url,
    'archiveBytes': 203502190, 'vendorMd5': '8c9645617dfd6854d0a8752c4794d92d', 'prospectiveCommit': '4addac2',
    'browserLifetimeStarted': False})
for name, url, seconds in [('catalog.json', catalog_url, 30), ('chrome-linux64.zip', archive_url, 300)]:
    with (root / (name + '.stderr.log')).open('xb') as errors:
        result = subprocess.run(['/usr/bin/curl', '--fail', '--silent', '--show-error', '--location', '--max-time', str(seconds),
            '--dump-header', str(root / (name + '.headers')), '--output', str(root / name), url], stderr=errors)
    save(name + '.retrieval.json', {'url': url, 'exit': result.returncode})
    result.check_returncode()
    if name == 'catalog.json':
        catalog = json.loads((root / name).read_text())
        stable = catalog['channels']['Stable']
        assert stable['version'] == version
        assert any(row['platform'] == 'linux64' and row['url'] == archive_url for row in stable['downloads']['chrome'])
archive = root / 'chrome-linux64.zip'
assert archive.stat().st_size == 203502190
assert digest(archive, 'md5') == '8c9645617dfd6854d0a8752c4794d92d'
with zipfile.ZipFile(archive) as zipped:
    members = zipped.infolist()
    assert len(members) < 2000 and sum(member.file_size for member in members) <= 1073741824
    assert len({member.filename for member in members}) == len(members)
    for member in members:
        relative = PurePosixPath(member.filename)
        assert not relative.is_absolute() and '..' not in relative.parts and relative.parts[0] == 'chrome-linux64'
        assert not stat.S_ISLNK(member.external_attr >> 16)
        target = root.joinpath(*relative.parts)
        if member.is_dir():
            target.mkdir(parents=True, exist_ok=True)
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
            with zipped.open(member) as source, target.open('xb') as output:
                shutil.copyfileobj(source, output, 1024 * 1024)
            mode = (member.external_attr >> 16) & 0o777
            target.chmod(0o755 if mode & 0o111 else 0o644)
inventory = [{'path': str(file.relative_to(root / 'chrome-linux64')), 'bytes': file.stat().st_size,
    'mode': stat.S_IMODE(file.stat().st_mode), 'sha256': digest(file)}
    for file in sorted((root / 'chrome-linux64').rglob('*')) if file.is_file()]
save('installed-files.json', inventory)
binary = root / 'chrome-linux64/chrome'
with (root / 'version.stdout.log').open('xb') as output, (root / 'version.stderr.log').open('xb') as errors:
    result = subprocess.run([str(binary), '--version'], stdout=output, stderr=errors, timeout=15,
        env={'PATH': '/usr/bin:/bin', 'LC_ALL': 'C'})
reported = (root / 'version.stdout.log').read_text().strip()
save('version-result.json', {'exit': result.returncode, 'reported': reported, 'purpose': 'Installation identity only; no browser control lifetime.'})
result.check_returncode()
assert reported == 'Google Chrome for Testing ' + version
save('identity.json', {'version': version, 'reportedVersion': reported, 'executable': str(binary),
    'executableSha256': digest(binary), 'archive': str(archive), 'archiveSha256': digest(archive),
    'archiveBytes': archive.stat().st_size, 'vendorMd5': digest(archive, 'md5'),
    'catalogURL': catalog_url, 'archiveURL': archive_url, 'catalogSha256': digest(root / 'catalog.json'),
    'installedInventorySha256': digest(root / 'installed-files.json'), 'installedFiles': len(inventory),
    'installedBytes': sum(row['bytes'] for row in inventory), 'browserLifetimeStarted': False})
print((root / 'identity.json').read_text())
