from pathlib import Path
import json
import re

base = Path('/home/toshiba/aew')
helper = base / 'task128-kernel-archive.py'
exec(helper.read_text().split("for name in ['core', 'browser', 'crash', 'interruption']:")[0])
repo = base / 'worktrees/task130-cold-start'
out = repo / 'docs/fixtures/loredock-cold-start'
records = json.loads((out / 'records.json').read_bytes())
for name in ['cold-ci-initial-push-job', 'cold-ci-initial-pr-job', 'cold-reference-first',
             'cold-reference-second', 'cold-reference-typecheck', 'cold-script-tests-first', 'cold-script-tests-second']:
    log(name, base / ('task130-' + name + '.log'))
source = base / 'task130-cold-reference-inputs'
source.mkdir()
for name in ['apps/loredock/tests/compiler-loading-reference.test.ts', 'apps/loredock/tests/analysis-write-reference.test.ts',
             'apps/loredock/tests/code-inventory.test.ts', 'apps/loredock/tests/fixtures/integration-reference/index.ts',
             'apps/loredock/tests/fixtures/prepared-question-api-reference/verify.mjs',
             'scripts/loredock-native-qualification/runtime.mjs', 'scripts/tests/loredock-execution-seal.test.mjs',
             'scripts/loredock-cold-start/compiler-import.mjs']:
    destination = source / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes((repo / name).read_bytes())
for file in sorted((repo / 'apps/loredock/tests/fixtures/compiler-loading-reference').glob('*')):
    destination = source / 'apps/loredock/tests/fixtures/compiler-loading-reference' / file.name
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(file.read_bytes())
for file in [Path(__file__), base / 'task130-cold-final-static.py']:
    (source / file.name).write_bytes(file.read_bytes())
tree('cold-reference-inputs', source)
locations = sorted(set(re.findall(r'Retained native driver regression: (/tmp/native-driver-[A-Za-z0-9]+)',
                                (base / 'task130-cold-script-tests-first.log').read_text())))
for index, directory in enumerate(locations):
    assert Path(directory).is_dir()
    tree('cold-script-first-native-' + str(index + 1), Path(directory),
         'First ordinary regression failure; retained without rerunning or replacing this directory.')
records['initialCI'] = {'head': 'c60b8142a2a57e5e42a4ca705c89e6741a84c555',
    'push': 42104317222, 'pull_request': 42104365030, 'conclusion': 'failure',
    'applicationTestsPerEvent': 664, 'applicationPassPerEvent': 660, 'applicationFailuresPerEvent': 4,
    'laterSuitesRun': False, 'completeJobLogsRetained': True,
    'initialLogDownloadError': 'gh run --log could not connect to results-receiver.actions.githubusercontent.com; job-log API downloads completed.'}
records['correctedChecks'] = {'focusedHistorical': 11, 'focusedScripts': 71, 'expectedFullCI': 1034,
                             'applicationChangedAfterCorrectedProductionObservation': False}
(out / 'records.json').write_text(json.dumps(records, indent=2) + '\n')
print(json.dumps({'trees': len(records['trees']), 'entries': sum(row['entries'] for row in records['trees']),
                  'logs': len(records['logs']), 'retainedFailedNativeRuns': len(locations)}, indent=2))
