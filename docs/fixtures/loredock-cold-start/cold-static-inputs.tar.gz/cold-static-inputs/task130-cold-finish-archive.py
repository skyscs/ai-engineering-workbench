from pathlib import Path
import json

base = Path('/home/toshiba/aew')
helper = base / 'task128-kernel-archive.py'
exec(helper.read_text().split("for name in ['core', 'browser', 'crash', 'interruption']:")[0])
repo = base / 'worktrees/task130-cold-start'
out = repo / 'docs/fixtures/loredock-cold-start'
records = json.loads((out / 'records.json').read_bytes())
for name in ['cold-static-first', 'cold-static-second', 'cold-archive-first']:
    log(name, base / ('task130-' + name + '.log'))
source = base / 'task130-cold-static-inputs'
source.mkdir()
for file in [base / 'task130-cold-static.py', Path(__file__)]:
    (source / file.name).write_bytes(file.read_bytes())
tree('cold-static-inputs', source)
(out / 'records.json').write_text(json.dumps(records, indent=2) + '\n')
print(json.dumps({'trees': len(records['trees']), 'entries': sum(row['entries'] for row in records['trees']),
                  'logs': len(records['logs'])}, indent=2))
