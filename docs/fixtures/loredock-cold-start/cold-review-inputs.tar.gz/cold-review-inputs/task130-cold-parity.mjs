import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';

const base = '/home/toshiba/aew';
const before = await import(base + '/worktrees/task129-partial-inventory/apps/loredock/dist/code-typescript.js');
const after = await import(base + '/worktrees/task130-cold-start/apps/loredock/dist/code-typescript.js');
assert.equal(before.typescriptFacts.toString(), after.typescriptFacts.toString(), 'The compiled parser function body changed.');
const inputs = JSON.parse(await readFile(base + '/task130-cold-explicit-first-inputs/execution.json', 'utf8'));
const rows = [];
for (const input of inputs.inputs) for (const [source, files] of Object.entries(input.corpus)) {
  for (const [file, text] of Object.entries(files)) if (/\.(ts|js|vue)$/.test(file)) {
    const expected = before.typescriptFacts(text, file), actual = after.typescriptFacts(text, file);
    assert.deepEqual(actual, expected);
    rows.push({ control: input.id, source, file, factsSha256: createHash('sha256').update(JSON.stringify(actual)).digest('hex') });
  }
}
const report = { compiledParserFunctionIdentical: true, comparisons: rows, resourceQualification: false,
  limitation: 'Ordinary parser parity and unchanged compiled dependency bytes; not semantic or resource qualification.' };
await writeFile(base + '/task130-cold-parity.json', JSON.stringify(report, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ compiledParserFunctionIdentical: true, ordinaryFileComparisons: rows.length }));
