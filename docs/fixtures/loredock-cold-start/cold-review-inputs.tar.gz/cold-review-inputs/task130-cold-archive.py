from pathlib import Path
import json

base = Path('/home/toshiba/aew')
helper = base / 'task128-kernel-archive.py'
exec(helper.read_text().split("for name in ['core', 'browser', 'crash', 'interruption']:")[0])
repo = base / 'worktrees/task130-cold-start'
out = repo / 'docs/fixtures/loredock-cold-start'
assert not (out / 'records.json').exists()
records = {'schemaVersion': 'ordinary-cold-start-attribution/1',
           'base': 'aaec8fd329e3c01b9cb97c1171c4681af1fe3c88',
           'resourceQualification': False, 'modelEligibility': False,
           'modelCalls': 0, 'reservedFamilyReads': 0, 'trees': [], 'logs': []}
for name in ['cold-first', 'cold-comparison-first', 'cold-explicit-first']:
    tree(name, base / ('task130-' + name))
    tree(name + '-inputs', base / ('task130-' + name + '-inputs'))
tree('cold-retention', base / 'task130-cold-retention')
for name in ['cold-install', 'cold-build', 'cold-input-seal', 'cold-first', 'cold-comparison-first',
             'cold-explicit-first', 'cold-typecheck-first', 'cold-typecheck-second', 'cold-typecheck-third',
             'cold-repair-build', 'cold-explicit-build', 'cold-explicit-build-final', 'cold-explicit-build-ordered',
             'cold-tests-first', 'cold-tests-second', 'cold-tests-third', 'cold-retain-first', 'cold-parity-first']:
    log(name, base / ('task130-' + name + '.log'))
inputs = base / 'task130-cold-review-inputs'
inputs.mkdir()
for file in [helper, Path(__file__), base / 'task130-cold-first-launch.py',
             base / 'task130-cold-comparison-first-launch.py', base / 'task130-cold-explicit-first-launch.py',
             base / 'task130-cold-retain.py', base / 'task130-cold-parity.mjs', base / 'task130-cold-parity.json']:
    (inputs / file.name).write_bytes(file.read_bytes())
tree('cold-review-inputs', inputs)
records['retention'] = json.loads((base / 'task130-cold-retention/result.json').read_bytes())
records['parity'] = json.loads((base / 'task130-cold-parity.json').read_bytes())
(out / 'records.json').write_text(json.dumps(records, indent=2) + '\n')
print(json.dumps({'trees': len(records['trees']), 'entries': sum(row['entries'] for row in records['trees']),
                  'logs': len(records['logs']), 'resourceQualification': False}, indent=2))
