"""Check first ordinary observations through stopped copies and exact original bytes."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import sqlite3
import subprocess

base = Path('/home/toshiba/aew')
out = base / 'task130-cold-retention'
out.mkdir()
read = lambda p: json.loads(p.read_bytes())
sha = lambda raw: hashlib.sha256(raw).hexdigest()

def inventory(root):
    result = {}
    for parent, dirs, files in os.walk(root, followlinks=False):
        for name in sorted(dirs + files):
            p = Path(parent) / name
            key = str(p.relative_to(root))
            if p.is_symlink():
                result[key] = {'target': os.readlink(p)}
            elif p.is_file():
                raw = p.read_bytes()
                result[key] = {'bytes': len(raw), 'sha256': sha(raw)}
    return result

report = {'catalogs': [], 'runs': [], 'gitIdentities': 0, 'sourceFiles': 0, 'originalChecks': 0,
          'httpResponses': 0, 'sessionRedactions': 0, 'preparations': 0, 'admissions': 0,
          'stableRepeatedReviews': 0, 'componentChecks': 0, 'modelCalls': 0,
          'reservedFamilyReads': 0, 'resourceQualification': False}
env = {'PATH': '/usr/bin:/bin', 'LC_ALL': 'C', 'GIT_CONFIG_NOSYSTEM': '1',
       'GIT_CONFIG_GLOBAL': '/dev/null', 'GIT_OPTIONAL_LOCKS': '0'}
snapshots = []
for label in ['cold-first', 'cold-comparison-first', 'cold-explicit-first']:
    root = base / ('task130-' + label)
    before = inventory(root)
    owner, run = read(root / 'result.json'), read(root / 'run/result.json')
    assert owner['reason'] == 'completed' and owner['driverExit']['exit'] == 0
    assert owner['errors'] == owner['survivors'] == run['errors'] == []
    snapshot = read(base / ('task130-' + label + '-inputs/execution.json'))
    snapshots.append(snapshot)
    cases = [{'id': 'production', 'value': run['production']}] if label == 'cold-first' else run['cases']
    inputs = [{'id': 'production', **snapshot['input']}] if label == 'cold-first' else snapshot['inputs']
    assert len(owner['catalogRoots']) == len(cases) == len(owner['observedCatalogRoots'])
    for case in cases:
        name, value = case['id'], case['value']
        assert value['functionalPassed'] and value['errors'] == value['assessmentErrors'] == []
        corpus = next(row['corpus'] for row in inputs if row['id'] == name)
        sources = read(root / 'run' / name / 'sources.json')
        review = value['prepared']['review']
        for source, files in corpus.items():
            directory = root / 'run' / name / 'sources' / source
            args = ['/usr/bin/git', '-c', 'core.hooksPath=/dev/null', '-c', 'core.fsmonitor=false']
            for key, ref in [('revision', 'HEAD'), ('tree', 'HEAD^{tree}')]:
                assert subprocess.check_output([*args, 'rev-parse', ref], cwd=directory, env=env, text=True).strip() == sources['revisions'][source][key]
            assert not subprocess.check_output([*args, 'status', '--porcelain'], cwd=directory, env=env)
            report['gitIdentities'] += 1
            for relative, text in files.items():
                raw = (directory / relative).read_bytes()
                assert raw == text.encode()
                original = next(row for row in sources['originals'] if row['source'] == source and row['path'] == relative)
                assert len(raw) == original['bytes'] and sha(raw) == original['sha256']
                report['sourceFiles'] += 1
        for reference in snapshot['references'].values():
            spans = [s for s in review['context']['spans'] if s['sourceName'] == reference['source'] and s['path'] == reference['path'] and reference['quote'] in s['text']]
            assert spans
            for span in spans:
                assert span['text'] == '\n'.join(corpus[reference['source']][reference['path']].splitlines()[span['startLine'] - 1:span['endLine']])
                assert span['revision'] == sources['revisions'][reference['source']]['revision']
            report['originalChecks'] += 1
        http = root / 'run' / name / 'case/http'
        requests, responses, reviews = {}, set(), []
        for row in map(json.loads, (http / 'requests.jsonl').read_text().splitlines()):
            key = row['id']
            if row['event'] == 'request':
                assert key not in requests
                requests[key] = row
                report['preparations'] += row['method'] == 'POST' and row['route'] == '/question-preparations'
                report['admissions'] += row['method'] == 'POST' and row['route'] == '/prepared-answers'
            else:
                assert row['event'] == 'response' and key in requests and key not in responses and row['status'] < 400
                responses.add(key)
                raw = (http / (key + '.json')).read_bytes()
                if requests[key]['route'] == '/session':
                    assert json.loads(raw)['token'] == '[removed-session-token]'
                    report['sessionRedactions'] += 1
                else:
                    assert len(raw) == row['bytes']
                if requests[key]['route'].endswith('/review'):
                    assert json.loads(raw) == review
                    reviews.append(raw)
                report['httpResponses'] += 1
        assert set(requests) == responses and len(reviews) == 2 and reviews[0] == reviews[1]
        report['stableRepeatedReviews'] += 1
    for original in sorted(root.rglob('loredock.db')):
        relative = str(original.parent.relative_to(root))
        assert relative in owner['catalogRoots']
        copied = out / label / relative
        copied.parent.mkdir(parents=True, exist_ok=True)
        shutil.copytree(original.parent, copied)
        assert inventory(original.parent) == inventory(copied)
        db = sqlite3.connect('file:' + str(copied / 'loredock.db') + '?mode=ro', uri=True)
        try:
            assert db.execute('PRAGMA integrity_check').fetchall() == [('ok',)]
            assert db.execute('PRAGMA foreign_key_check').fetchall() == []
            assert db.execute('SELECT count(*) FROM answer_attempts').fetchone()[0] == 0
            assert db.execute('SELECT count(*) FROM answer_witnesses').fetchone()[0] == 0
        finally:
            db.close()
        report['catalogs'].append({'copy': str(copied), 'integrity': 'ok', 'attempts': 0, 'witnesses': 0})
    for component in run.get('components', []):
        directory = root / 'run' / component['id']
        assert read(directory / 'exit.json') == {'code': 0, 'signal': None, 'spawnError': None, 'timedOut': False}
        assert read(directory / 'import.json') == component['timing']
        samples = [json.loads(line) for line in (directory / 'memory-timer.jsonl').read_text().splitlines()]
        assert samples[0]['event'] == 'start' and samples[-1]['event'] == 'exit-0'
        assert max(row['gapMs'] for row in samples) == component['metrics']['measured']['rawIntervalGapMs']
        report['componentChecks'] += 1
    assert inventory(root) == before
    (out / (label + '-raw-inventory.json')).write_text(json.dumps(before, indent=2) + '\n')
    report['runs'].append({'label': label, 'rawEntries': len(before), 'rawInputsUnchanged': True})
assert len({s['nodeSha256'] for s in snapshots}) == len({s['compiler']['sha256'] for s in snapshots}) == 1
module_deltas = []
for snapshot in snapshots[1:]:
    assert set(snapshot['workspaceModules']) == set(snapshots[0]['workspaceModules'])
    changed = [name for name, row in snapshot['workspaceModules'].items() if row != snapshots[0]['workspaceModules'][name]]
    assert changed == ['apps/loredock/dist/code-typescript.js']
    module_deltas.append(changed)
report['workspaceModuleDeltas'] = module_deltas
assert len(report['catalogs']) == report['preparations'] == report['stableRepeatedReviews'] == report['componentChecks'] == 5
assert report['gitIdentities'] == 20 and report['sourceFiles'] == 62 and report['originalChecks'] == 40 and report['admissions'] == 0
(out / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({**report, 'catalogs': len(report['catalogs'])}, indent=2))
