import {mkdir,writeFile,readFile,symlink} from 'node:fs/promises';
import {spawn} from 'node:child_process';
const root=process.argv[2];await mkdir(root);await writeFile(root+'/retained-original.txt','Owned source bytes survive.');
await writeFile(root+'/forged-process.json',JSON.stringify({pid:1}));
await symlink("/tmp/loredock-kernel-owner-BaIm1d/outside",root+'/outside-link');
await writeFile(root+'/ready','ready');

