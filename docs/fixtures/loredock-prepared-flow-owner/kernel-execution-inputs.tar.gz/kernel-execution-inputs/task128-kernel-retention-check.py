from pathlib import Path
import hashlib
import json
import os
import shutil
import sqlite3
import stat

base = Path('/home/toshiba/aew')
out = base / 'task128-kernel-retention-check'
out.mkdir()
sha = lambda raw: hashlib.sha256(raw).hexdigest()

def inventory(root):
    rows = {}
    for directory, dirs, files in os.walk(root, followlinks=False):
        for name in dirs + files:
            p = Path(directory) / name
            rel = str(p.relative_to(root))
            value = p.lstat()
            if stat.S_ISLNK(value.st_mode):
                rows[rel] = {'kind': 'symlink', 'target': os.readlink(p), 'bytes': value.st_size}
            elif stat.S_ISREG(value.st_mode):
                raw = p.read_bytes()
                rows[rel] = {'kind': 'file', 'bytes': len(raw), 'sha256': sha(raw)}
            else:
                assert stat.S_ISDIR(value.st_mode), rel
    return rows

results = []
for name in ['core', 'browser', 'crash', 'interruption']:
    root = base / ('task128-kernel-' + name + '-first')
    before = inventory(root)
    owner = json.loads((root / 'result.json').read_text())
    assert owner['errors'] == [] and owner['survivors'] == []
    expected = {'core': 'completed', 'browser': 'completed', 'crash': 'driver-left-owned-process',
                'interruption': 'owner-SIGTERM'}[name]
    assert owner['reason'] == expected
    source = json.loads((root / 'run/sources.json').read_text())
    for row in source['originals']:
        raw = (root / 'run/sources' / row['source'] / row['path']).read_bytes()
        assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
    inspected = []
    # Inspect a complete stopped copy, keeping even SQLite's read-side files away from originals.
    copy = out / name
    shutil.copytree(root / 'run/data', copy)
    for database in sorted(copy.rglob('*.db')):
        connection = sqlite3.connect(database.as_uri() + '?mode=ro', uri=True)
        assert connection.execute('PRAGMA integrity_check').fetchall() == [('ok',)]
        assert connection.execute('PRAGMA foreign_key_check').fetchall() == []
        row = {'path': str(database.relative_to(copy)), 'integrity': 'ok', 'foreignKeys': []}
        if database.name == 'loredock.db':
            row['answers'] = connection.execute('SELECT status FROM answer_attempts').fetchall()
            row['witnesses'] = connection.execute('SELECT count(*) FROM answer_witnesses').fetchone()[0]
            assert row['answers'] == [('succeeded',)] and row['witnesses'] == 1
        inspected.append(row)
        connection.close()
    assert inventory(root) == before
    (out / (name + '-inventory.json')).write_text(json.dumps(before, indent=2) + '\n')
    results.append({'case': name, 'reason': owner['reason'], 'survivors': [], 'errors': [],
                    'originals': len(source['originals']), 'sourceBytesUnchanged': True,
                    'fullStoppedStorageBytes': sum(row['bytes'] for row in before.values()),
                    'inspectedStoppedCopies': inspected, 'rawTreeUnchangedByInspection': True})
(out / 'result.json').write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps(results, indent=2))
