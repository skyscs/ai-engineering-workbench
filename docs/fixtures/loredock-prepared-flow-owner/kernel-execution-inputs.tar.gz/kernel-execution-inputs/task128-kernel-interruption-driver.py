import json
import os
from pathlib import Path
import signal
import subprocess
import time

root = Path('/home/toshiba/aew')
repo = root / 'worktrees/task128-process-ownership'
output = root / 'task128-kernel-interruption-first'
command = ['python3', '-I', '-S', str(repo / 'scripts/loredock-prepared-flow/kernel-owner.py'),
           '--node', str(root / 'toolchain/node-v22.23.2-linux-x64/bin/node'),
           '--script', str(repo / 'scripts/loredock-prepared-flow/owner-failure-development.mjs'),
           '--output', str(output), '--', 'external-interruption']
report = {'command': command, 'trigger': 'actual ready browser and persisted controlled answer'}
with (root / 'task128-kernel-interruption-first.log').open('xb') as log:
    child = subprocess.Popen(command, cwd=repo, stdout=log, stderr=log, start_new_session=True)
    report['ownerPid'] = child.pid
    try:
        deadline = time.monotonic() + 30
        while not (output / 'run/failure-ready.jsonl').exists():
            if child.poll() is not None:
                raise RuntimeError('Owner exited before the deliberate interruption.')
            if time.monotonic() >= deadline:
                raise RuntimeError('Owned browser did not reach the interruption boundary.')
            time.sleep(0.025)
        # Signal only our live direct Popen child, never a process found by port/name.
        child.send_signal(signal.SIGTERM)
        report['exit'] = child.wait(timeout=20)
        result = json.loads((output / 'result.json').read_text())
        assert report['exit'] == 1 and result['reason'] == 'owner-SIGTERM'
        assert result['errors'] == [] and result['survivors'] == []
        report['passed'] = True
    finally:
        if child.poll() is None:
            child.send_signal(signal.SIGTERM)
            report['cleanupExit'] = child.wait(timeout=20)
        (root / 'task128-kernel-interruption-first.injector.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
