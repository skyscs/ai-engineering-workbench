import ctypes,json,os,signal,subprocess,time
from pathlib import Path
root=Path(__file__).parent
libc=ctypes.CDLL(None,use_errno=True)
assert libc.prctl(36,ctypes.c_ulong(1),0,0,0)==0
active=ctypes.c_int();assert libc.prctl(37,ctypes.byref(active),0,0,0)==0 and active.value==1
node='/home/toshiba/aew/toolchain/node-v22.23.2-linux-x64/bin/node'
source="const {spawn}=require('node:child_process');const child=spawn(process.execPath,['-e','setInterval(()=>{},1000)'],{detached:true,stdio:'ignore'});child.unref();console.log(JSON.stringify({pid:child.pid}));"
(root/'child.js').write_text(source)
parent=subprocess.Popen([node,str(root/'child.js')],stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True,env={'PATH':'/usr/bin:/bin','LC_ALL':'C'})
stdout,stderr=parent.communicate(timeout=5);(root/'stdout.log').write_bytes(stdout);(root/'stderr.log').write_bytes(stderr);assert parent.returncode==0
orphan=json.loads(stdout)['pid']
def identity(pid):
 text=Path(f'/proc/{pid}/stat').read_text();parts=text[text.rindex(')')+2:].split();return {'pid':pid,'state':parts[0],'parent':int(parts[1]),'group':int(parts[2]),'started':parts[19]}
observed=identity(orphan)
assert observed['parent']==os.getpid() and observed['group']==orphan and orphan!=parent.pid
# The first discovery happens after the intermediate parent has already exited.
os.kill(orphan,signal.SIGTERM);waited,status=os.waitpid(orphan,0);assert waited==orphan
result={'ownerPid':os.getpid(),'subreaper':active.value,'intermediatePid':parent.pid,'intermediateExit':parent.returncode,'firstObservationAfterParentExit':observed,'orphanWaitStatus':status,'orphanExit':os.waitstatus_to_exitcode(status),'ownedChildrenAfterReaping':Path(f'/proc/{os.getpid()}/task/{os.getpid()}/children').read_text().strip(),'modelCalls':0,'reservedFamilyReads':0}
assert result['ownedChildrenAfterReaping']==''
(root/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
