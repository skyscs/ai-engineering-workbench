"""Independent original-vector and stopped-copy coverage review; no candidate execution."""
from pathlib import Path
import collections
import gzip
import hashlib
import json
import sqlite3

base = Path('/home/toshiba/aew')
repository = base / 'worktrees/task128-execution-seal'
root = base / 'task128-kiln-first'
copies = base / 'task128-kiln-retention'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
oracle = json.loads((repository / 'fixtures/loredock-prepared-flow/oracle.json').read_bytes())
vectors = json.loads(gzip.decompress((repository / 'fixtures/loredock-prepared-flow/source-vectors.json.gz').read_bytes()))
report = {'sourceVectors': [], 'requiredOriginals': [], 'analyses': [], 'observer': 'Author review independent of candidate selection; not blind or external acceptance.',
          'resourceQualification': False, 'modelEligibility': False, 'newCandidateExecutions': 0, 'modelCalls': 0}
inputs = [('R01-representative-cold/input', 'representative'), ('R02-near-limit-cold/input', 'near-limit')]
inputs += [('R14-oracle-preconditions/' + row['id'], row['variant']) for row in oracle['cases']]
for relative, variant in inputs:
    source = root / 'run/matrix' / relative
    materialized = json.loads((source / 'sources.json').read_bytes())
    assert sorted(materialized['originals'], key=lambda row: (row['source'], row['path'])) == vectors[variant]
    for row in vectors[variant]:
        raw = (source / 'sources' / row['source'] / row['path']).read_bytes()
        assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
    report['sourceVectors'].append({'input': relative, 'variant': variant, 'files': len(vectors[variant]), 'matchesFrozenVector': True})
for expected in oracle['cases']:
    source = root / 'run/matrix/R14-oracle-preconditions' / expected['id'] / 'sources'
    for reference in expected['requiredOriginals']:
        item = oracle['references'][reference]
        raw = (source / item['source'] / item['path']).read_bytes()
        text = raw.decode()
        assert text.count(item['quote']) == 1
        start = text[:text.index(item['quote'])].count('\n') + 1
        report['requiredOriginals'].append({'case': expected['id'], 'reference': reference, 'source': item['source'],
            'path': item['path'], 'startLine': start, 'endLine': start + item['quote'].count('\n'),
            'fileSha256': sha(raw), 'quoteSha256': sha(item['quote'].encode()), 'candidateSelectionCredit': False})
for relative in ['R01-representative-cold/cold/data', 'R02-near-limit-cold/cold/data']:
    database = sqlite3.connect('file:' + str(copies / 'run/matrix' / relative / 'loredock.db') + '?mode=ro', uri=True)
    try:
        gaps, statuses, count, padding, payload_bytes = collections.Counter(), collections.Counter(), 0, 0, 0
        for status, gap_count, payload, payload_hash in database.execute('SELECT status,gapCount,payload,payloadHash FROM code_analysis_files'):
            statuses[status] += 1
            assert payload is not None and sha(payload.encode()) == payload_hash
            value = json.loads(payload)
            assert len(value['facts']['gaps']) == gap_count
            gaps.update(value['facts']['gaps'])
            if gap_count:
                count += 1
                padding += value['path'].startswith('samples/value-') and value['path'].endswith('.ts')
            payload_bytes += len(payload.encode())
        report['analyses'].append({'catalog': relative, 'fileStatuses': dict(statuses), 'filesWithGaps': count,
            'paddingFilesWithGaps': padding, 'gaps': dict(gaps), 'payloadBytes': payload_bytes,
            'observation': 'Terminal processing and published coverage are different properties. No preparation is inferred from parsed file counts.'})
    finally:
        database.close()
target = base / 'task128-kiln-original-review.json'
with target.open('x') as file:
    json.dump(report, file, indent=2)
    file.write('\n')
print(json.dumps({'sourceVectors': len(report['sourceVectors']), 'sourceFiles': sum(row['files'] for row in report['sourceVectors']),
                  'requiredOriginals': len(report['requiredOriginals']), 'analyses': report['analyses'],
                  'newCandidateExecutions': 0, 'modelCalls': 0}, indent=2))
