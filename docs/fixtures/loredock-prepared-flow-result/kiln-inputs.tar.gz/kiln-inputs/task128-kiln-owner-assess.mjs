// Invoke the already sealed independent owner assessor on stopped retained records only.
import assert from 'node:assert/strict';
import { writeFile } from 'node:fs/promises';
import { assessRecordedOwner } from './worktrees/task128-execution-seal/scripts/loredock-prepared-flow/resource-assess.mjs';

assert.equal(process.argv.length, 2);
const result = await assessRecordedOwner('/home/toshiba/aew/task128-kiln-first');
await writeFile('/home/toshiba/aew/task128-kiln-owner-assessment.json', JSON.stringify(result, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ status: result.status, checks: result.checks, incomplete: result.incomplete,
  failures: result.failures, observed: result.observed, entries: Object.keys(result.finalInventory).length,
  resourceQualification: false, modelEligibility: false }, null, 2));
