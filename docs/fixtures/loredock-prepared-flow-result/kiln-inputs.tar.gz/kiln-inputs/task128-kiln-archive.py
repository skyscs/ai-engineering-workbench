from pathlib import Path
import json

base = Path('/home/toshiba/aew')
helper = base / 'task128-kernel-archive.py'
exec(helper.read_text().split("for name in ['core', 'browser', 'crash', 'interruption']:")[0])
repo = base / 'worktrees/task128-execution-seal'
out = repo / 'docs/fixtures/loredock-prepared-flow-result'
out.mkdir()
records = {'schemaVersion': 'prepared-flow-first-reserved-result/1', 'family': 'kiln-prepared-flow-127',
           'familyConsumed': True, 'resourceQualification': False, 'modelEligibility': False, 'modelCalls': 0,
           'candidateReadCount': None, 'trees': [], 'logs': [], 'base': '6374e9e98fd4aa74c026c98e9c457734d595ef2f',
           'acceptedSeal': {'pr': 160, 'head': 'aff6b7691ece0f26d4c7a56c48f81f2ec4a637c0',
                            'merge': '6374e9e98fd4aa74c026c98e9c457734d595ef2f',
                            'push': 42090547226, 'pull_request': 42090656068, 'testsPerEvent': 1029,
                            'completeLogsVerifiedBeforeMerge': True, 'identicalTreeVerified': True}}
for name in ['kiln-first', 'kiln-retention']:
    tree(name, base / ('task128-' + name))
for name in ['kiln-first', 'kiln-retain-first', 'kiln-owner-assess-first', 'kiln-original-review-first']:
    log(name, base / ('task128-' + name + '.log'))
for event in ['push', 'pr']:
    log('accepted-seal-ci-' + event, base / ('task128-execution-seal-ci-' + event + '.log'))
inputs = base / 'task128-kiln-inputs'
inputs.mkdir()
for source in sorted((repo / 'scripts/loredock-prepared-flow').glob('*')):
    if source.is_file() and source.suffix in ['.py', '.mjs']:
        (inputs / source.name).write_bytes(source.read_bytes())
for source in [helper, base / 'task128-kiln-retain.py', base / 'task128-kiln-owner-assess.mjs',
               base / 'task128-kiln-original-review.py', base / 'task128-kiln-first.claim.json',
               repo / 'docs/fixtures/loredock-prepared-flow-execution-seal/manifest.json',
               repo / 'docs/fixtures/loredock-prepared-flow-execution-seal/manifest.inventory.json.gz', Path(__file__)]:
    (inputs / source.name).write_bytes(source.read_bytes())
tree('kiln-inputs', inputs)
assessment = base / 'task128-kiln-assessments'
assessment.mkdir()
for source in [base / 'task128-kiln-owner-assessment.json', base / 'task128-kiln-original-review.json']:
    (assessment / source.name).write_bytes(source.read_bytes())
tree('kiln-assessments', assessment)
records['retention'] = json.loads((base / 'task128-kiln-retention/result.json').read_bytes())
originals = json.loads((base / 'task128-kiln-original-review.json').read_bytes())
records['originalReview'] = {'sourceVectors': len(originals['sourceVectors']), 'requiredOriginals': len(originals['requiredOriginals']),
                             'analyses': originals['analyses'], 'observer': originals['observer']}
records['ownerAssessment'] = {key: value for key, value in json.loads((base / 'task128-kiln-owner-assessment.json').read_bytes()).items()
                              if key != 'finalInventory'}
(out / 'records.json').write_text(json.dumps(records, indent=2) + '\n')
print(json.dumps({'trees': len(records['trees']), 'entries': sum(row['entries'] for row in records['trees']),
                  'logs': len(records['logs']), 'familyConsumed': True, 'modelEligibility': False}, indent=2))
