"""Copy and independently check the stopped first reserved run. Never executes the candidate."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import sqlite3
import subprocess
import traceback

base = Path('/home/toshiba/aew')
root = base / 'task128-kiln-first'
run = root / 'run'
output = base / 'task128-kiln-retention'
repository = base / 'worktrees/task128-execution-seal'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
read = lambda file: json.loads(file.read_bytes())


def inventory(directory):
    result = {}
    for parent, directories, files in os.walk(directory, followlinks=False):
        for name in sorted(directories + files):
            file = Path(parent) / name
            relative = str(file.relative_to(directory))
            if file.is_symlink():
                result[relative] = {'target': os.readlink(file)}
            elif file.is_file():
                raw = file.read_bytes()
                result[relative] = {'bytes': len(raw), 'sha256': sha(raw)}
    return result


before = inventory(root)
owner = read(root / 'result.json')
assert owner['driverExit'] is not None and owner['survivors'] == [], 'Wait for complete external-owner teardown.'
output.mkdir()
report = {'catalogs': [], 'sourceGitIdentities': 0, 'sourceFiles': 0, 'httpResponses': 0, 'redactedSessions': 0,
          'httpOutcomes': {}, 'failedFreshProofs': 0, 'controlledCalls': 0, 'errors': [],
          'resourceQualification': False, 'modelEligibility': False, 'modelCalls': 0,
          'reservedFamily': 'kiln-prepared-flow-127', 'familyConsumed': True, 'candidateReadCount': None}
manifest_raw = (repository / 'docs/fixtures/loredock-prepared-flow-execution-seal/manifest.json').read_bytes()
manifest = json.loads(manifest_raw)
claim_raw = (base / 'task128-kiln-first.claim.json').read_bytes()
claim = json.loads(claim_raw)
assert claim['family'] == report['reservedFamily'] and claim['familyConsumed'] is True
assert claim['executionSeal']['manifestSha256'] == sha(manifest_raw)
sequence = [json.loads(line) for line in (run / 'matrix/sequence.jsonl').read_text().splitlines()]
assert sequence[0]['event'] == 'started'
for key, value in claim.items():
    assert sequence[0][key] == value
assert read(root / 'command.json') == manifest['driver']
result = read(run / 'result.json')
matrix = read(run / 'matrix/result.json')
assert matrix == result['matrix']
assert [row['id'] for row in matrix['cases']] == claim['order'] and len(matrix['cases']) == 15
assert result['modelEligibility'] is False and result['modelCalls'] == 0
assert result['reservedFamilyReads'] is None
for row in matrix['cases']:
    for artifact in row.get('artifacts', []):
        file = run / 'matrix' / row['id'] / artifact['path']
        raw = file.read_bytes()
        assert len(raw) == artifact['bytes'] and sha(raw) == artifact['sha256']
report['cases'] = [{key: row.get(key) for key in ['id', 'status', 'reason', 'safeToContinue', 'details', 'error']} for row in matrix['cases']]
report['owner'] = {key: owner[key] for key in ['reason', 'driverExit', 'errors', 'survivors', 'elapsedMs', 'cleanupMs',
                                              'catalogRoots', 'observedCatalogRoots', 'peakSampledStorageBytes']}
report['claimSha256'] = sha(claim_raw)
report['manifestSha256'] = sha(manifest_raw)
environment = {'PATH': str(base / 'toolchain/node-v22.23.2-linux-x64/bin') + ':/usr/bin:/bin', 'LC_ALL': 'C',
               'GIT_CONFIG_NOSYSTEM': '1', 'GIT_CONFIG_GLOBAL': '/dev/null', 'GIT_OPTIONAL_LOCKS': '0'}
for file in run.rglob('sources.json'):
    sources = read(file)
    for name, identity in sources['revisions'].items():
        directory = Path(next(value for value in sources['paths'] if Path(value).name == name))
        assert directory.is_relative_to(root)
        for key, ref in [('revision', 'HEAD'), ('tree', 'HEAD^{tree}')]:
            actual = subprocess.check_output(['/usr/bin/git', '-c', 'core.hooksPath=/dev/null', '-c', 'core.fsmonitor=false',
                'rev-parse', ref], cwd=directory, env=environment, text=True).strip()
            assert actual == identity[key]
        assert not subprocess.check_output(['/usr/bin/git', '-c', 'core.hooksPath=/dev/null', '-c', 'core.fsmonitor=false',
            'status', '--porcelain'], cwd=directory, env=environment)
        report['sourceGitIdentities'] += 1
    for original in sources['originals']:
        directory = Path(next(value for value in sources['paths'] if Path(value).name == original['source']))
        raw = (directory / original['path']).read_bytes()
        assert len(raw) == original['bytes'] and sha(raw) == original['sha256']
        report['sourceFiles'] += 1
for file in run.rglob('requests.jsonl'):
    requests, responses = {}, set()
    for row in map(json.loads, file.read_text().splitlines()):
        key = row['id']
        if row['event'] == 'request':
            assert key not in requests
            requests[key] = row
        elif row['event'] == 'response':
            assert key in requests and key not in responses
            responses.add(key)
            raw = (file.parent / (key + '.json')).read_bytes()
            if requests[key]['route'] == '/session':
                assert json.loads(raw)['token'] == '[removed-session-token]'
                report['redactedSessions'] += 1
            else:
                assert len(raw) == row['bytes']
            status = str(row['status'])
            report['httpOutcomes'][status] = report['httpOutcomes'].get(status, 0) + 1
            report['httpResponses'] += 1
        else:
            report['errors'].append({'http': str(file), 'retainedFailure': row})
    if set(requests) != responses:
        report['errors'].append({'http': str(file), 'requestsWithoutResponse': sorted(set(requests) - responses)})
for file in run.rglob('runtime-stats.json'):
    value = read(file)
    assert value['prepares'] == value['closed']
    report['controlledCalls'] += value['calls']
proofs = {}
for file in run.rglob('failed-fresh-setup.json'):
    value = read(file)
    assert value['attempts'] == value['witnesses'] == value['controlledCalls'] == value['preparationRequests'] == value['expectedRows'] == 0
    assert value['resultSha256'] == sha((file.parent / 'result.json').read_bytes())
    failed = read(file.parent / 'result.json')
    assert failed['errors'] and all(error['code'] == 'INCOMPLETE_CODE_ANALYSIS' for error in failed['errors'])
    proofs[value['data']] = value
    report['failedFreshProofs'] += 1
for original in sorted(run.rglob('loredock.db')):
    relative = original.parent.relative_to(root)
    assert str(relative) in owner['catalogRoots']
    copied = output / relative
    copied.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(original.parent, copied)
    assert inventory(original.parent) == inventory(copied)
    entry = {'source': str(original.parent), 'copy': str(copied)}
    database = sqlite3.connect('file:' + str(copied / 'loredock.db') + '?mode=ro', uri=True)
    try:
        integrity = database.execute('PRAGMA integrity_check').fetchall()
        foreign_keys = database.execute('PRAGMA foreign_key_check').fetchall()
        assert integrity == [('ok',)] and foreign_keys == []
        rows = database.execute('SELECT w.purged,w.contextHash,w.witness,w.witnessBytes,a.context FROM answer_witnesses w JOIN answer_attempts a ON a.id=w.answerId').fetchall()
        for purged, context_hash, witness, witness_bytes, context in rows:
            if purged:
                assert witness is None and context is None and witness_bytes == 0
            else:
                assert sha(context.encode()) == context_hash and len(witness.encode()) == witness_bytes
        attempts = database.execute('SELECT count(*) FROM answer_attempts').fetchone()[0]
        if str(original.parent) in proofs:
            assert attempts == 0 and rows == []
        entry.update(integrity='ok', foreignKeys=[], attempts=attempts, witnesses=len(rows))
    except Exception:
        entry['error'] = traceback.format_exc()
        report['errors'].append({'catalog': str(original), 'error': entry['error']})
    finally:
        database.close()
    report['catalogs'].append(entry)
assert inventory(root) == before
report.update(rawInputsUnchanged=True, entries=len(before), catalogCount=len(report['catalogs']))
(output / 'raw-input-inventory.json').write_text(json.dumps(before, indent=2) + '\n')
(output / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({**report, 'catalogs': len(report['catalogs'])}, indent=2))
