from pathlib import Path
import json

base = Path('/home/toshiba/aew')
helper = base / 'task128-kernel-archive.py'
exec(helper.read_text().split("for name in ['core', 'browser', 'crash', 'interruption']:")[0])
repo = base / 'worktrees/task128-execution-seal'
out = repo / 'docs/fixtures/loredock-prepared-flow-result'
records = json.loads((out / 'records.json').read_bytes())
for name in ['kiln-static-first', 'kiln-input-seal', 'kiln-archive-first', 'kiln-raw-final']:
    log(name, base / ('task128-' + name + '.log'))
source = base / 'task128-kiln-static-inputs'
source.mkdir()
for file in [base / 'task128-kiln-static.py', Path(__file__)]:
    (source / file.name).write_bytes(file.read_bytes())
tree('kiln-static-inputs', source)
(out / 'records.json').write_text(json.dumps(records, indent=2) + '\n')
print(json.dumps({'trees': len(records['trees']), 'entries': sum(row['entries'] for row in records['trees']),
                  'logs': len(records['logs'])}, indent=2))
