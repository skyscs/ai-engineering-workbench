define(["dojo/request"], function (request) {
  return { stopCycle: function (cell) {
    return request.post("/kiln/stop", { headers: { "X-Safety-Cell": cell } });
  } };
});
