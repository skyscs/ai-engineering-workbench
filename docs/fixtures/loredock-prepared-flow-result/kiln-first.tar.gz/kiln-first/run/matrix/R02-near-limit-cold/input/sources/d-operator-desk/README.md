# Operator desk
The legacy Dojo stopCycle helper posts a stop request. It does not import the console queue helper.
These files describe static examples with unknown deployment coherence.
