// Synthetic constant for d-operator-desk; no runtime binding.
export const sample0014 = 15;
