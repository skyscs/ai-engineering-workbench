from pathlib import Path
import json
import re

base = Path('/home/toshiba/aew')
helper = base / 'task128-kernel-archive.py'
exec(helper.read_text().split("for name in ['core', 'browser', 'crash', 'interruption']:")[0])
repo = base / 'worktrees/task128-preflight-boundaries'
out = repo / 'docs/fixtures/loredock-prepared-flow-preflight'
records = {'schemaVersion': 'prepared-flow-preflight-development/1', 'resourceQualification': False,
           'modelCalls': 0, 'reservedFamilyReads': 0, 'tests': 955, 'trees': [], 'logs': [],
           'acceptedCancellation': {'pr': 134, 'head': 'f07132df0af5effbafb785b5de36751d05aff9e4',
                                    'merge': 'eedc69eff34a87af133d7ae618628e3762014840',
                                    'push': 41996528951, 'pull_request': 41996827429, 'testsPerEvent': 955}}
for name in ['preflight-observation-first', 'published-build-fault-first']:
    tree(name, base / ('task128-' + name), 'The public build-start case remains incomplete and the driver exits 1. The separately recorded published-build fault does not rewrite this outcome.' if name.startswith('preflight') else None)
    log(name, base / ('task128-' + name + '.log'))
tree('preflight-retention', base / 'task128-preflight-retention')
for name in ['preflight-check-first', 'preflight-install', 'preflight-build', 'preflight-seal-check', 'preflight-retention', 'boundary-ci-push', 'boundary-ci-pr']:
    raw = log(name, base / ('task128-' + name + '.log'))
    if name == 'preflight-check-first':
        for i, location in enumerate(re.findall(r'Retained kernel-owner test: (/tmp/loredock-kernel-(?:adoption|owner)-[A-Za-z0-9]+)', raw)):
            tree('preflight-check-owner-' + str(i+1), Path(location))
inputs = base / 'task128-preflight-inputs'
inputs.mkdir()
for source in [repo/'scripts/loredock-prepared-flow/preflight-observation-development.mjs',
               repo/'scripts/loredock-prepared-flow/published-build-fault-development.mjs', helper,
               base/'task128-preflight-retention.py', Path(__file__)]:
    (inputs / source.name).write_bytes(source.read_bytes())
tree('preflight-inputs', inputs)
records['retention'] = json.loads((base / 'task128-preflight-retention/result.json').read_text())
(out/'records.json').write_text(json.dumps(records, indent=2) + '\n')
print(json.dumps({'trees': len(records['trees']), 'logs': len(records['logs']), 'tests': records['tests']}, indent=2))
