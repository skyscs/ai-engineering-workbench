from pathlib import Path
import hashlib
import json
import shutil
import sqlite3

base = Path('/home/toshiba/aew')
output = base / 'task128-preflight-retention'
output.mkdir()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
def tree(root):
    return {str(p.relative_to(root)): sha(p.read_bytes()) for p in sorted(root.rglob('*')) if p.is_file()}
results = []
for name in ['preflight-observation-first', 'published-build-fault-first']:
    root = base / ('task128-' + name)
    before = tree(root)
    owner = json.loads((root / 'result.json').read_text())
    assert not owner['errors'] and not owner['survivors']
    run = json.loads((root / 'run/result.json').read_text())
    assert not run['errors']
    if name == 'preflight-observation-first':
        assert owner['reason'] == 'driver-failure' and owner['driverExit']['exit'] == 1
        assert [row['observedFirstPreflight'] for row in run['cases']] == [True, True, False]
        assert run['cases'][2]['afterMutation']['status'] == 'failed'
        assert run['cases'][2]['buildAtAnswerObservation']['published'] is False
        for case in run['cases']:
            assert not case['errors'] and case['runtime'] == {'prepares': 0, 'calls': 0, 'closed': 0}
            stats = json.loads((root/'run'/case['kind']/'daemon/runtime-stats.json').read_text())
            assert stats == case['runtime']
    else:
        assert owner['reason'] == 'completed' and owner['driverExit']['exit'] == 0
        assert run['admitted']['status'] == 'preparing' and run['admitted']['inputKind'] == 'prepared-question/1'
        assert run['admitted']['buildId'] == run['actualBuilds']['first']['id']
        assert run['actualPublishedProject'] == run['publishedProjectAfterFault']
        assert run['runtime'] == {'prepares': 0, 'calls': 0, 'closed': 0}
        assert run['stored']['status'] == 'failed' and run['stored']['dispatchedAt'] is None
    source = json.loads((root / 'run/sources.json').read_text())
    for row in source['originals']:
        raw = (root / 'run/sources' / row['source'] / row['path']).read_bytes()
        assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
    databases = []
    for db in sorted((root / 'run').rglob('loredock.db')):
        destination = output / name / db.parent.relative_to(root / 'run')
        shutil.copytree(db.parent, destination)
        copy = destination / db.name
        connection = sqlite3.connect(copy.as_uri() + '?mode=ro', uri=True)
        assert connection.execute('PRAGMA integrity_check').fetchall() == [('ok',)]
        assert connection.execute('PRAGMA foreign_key_check').fetchall() == []
        rows = connection.execute('SELECT status,dispatchedAt FROM answer_attempts').fetchall()
        assert all(row[1] is None for row in rows)
        databases.append({'directory': str(db.parent.relative_to(root / 'run')), 'integrity': 'ok', 'foreignKeys': [], 'answers': rows})
        connection.close()
    assert tree(root) == before
    results.append({'case': name, 'sourceHashesUnchanged': True, 'rawTreeUnchangedByInspection': True,
                    'databases': databases, 'ownerErrors': [], 'ownedSurvivors': []})
(output / 'result.json').write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps(results, indent=2))
