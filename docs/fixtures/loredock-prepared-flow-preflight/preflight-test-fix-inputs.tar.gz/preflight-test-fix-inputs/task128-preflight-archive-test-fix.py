from pathlib import Path
import json
import re

base = Path('/home/toshiba/aew')
helper = base / 'task128-kernel-archive.py'
exec(helper.read_text().split("for name in ['core', 'browser', 'crash', 'interruption']:")[0])
repo = base / 'worktrees/task128-preflight-boundaries'
out = repo / 'docs/fixtures/loredock-prepared-flow-preflight'
records = json.loads((out/'records.json').read_text())
for name in ['preflight-ci-push-first', 'preflight-ci-pr-first', 'preflight-terminal-focused',
             'preflight-check-after-test-fix', 'preflight-seal-after-test-fix', 'preflight-static-after-test-fix']:
    raw = log(name, base / ('task128-' + name + '.log'))
    if name == 'preflight-check-after-test-fix':
        for i, location in enumerate(re.findall(r'Retained kernel-owner test: (/tmp/loredock-kernel-(?:adoption|owner)-[A-Za-z0-9]+)', raw)):
            tree('preflight-check-fixed-owner-' + str(i+1), Path(location))
        for i, location in enumerate(re.findall(r'Retained terminal integration: (/tmp/terminal-memory-[A-Za-z0-9-]+)', raw)):
            tree('preflight-check-fixed-terminal-' + str(i+1), Path(location))
inputs = base / 'task128-preflight-test-fix-inputs'
inputs.mkdir()
for source in [repo/'apps/loredock/tests/terminal-memory-process.test.ts',
               base/'task128-preflight-ci-failure-report.json', base/'task128-preflight-static-after-test-fix.py', Path(__file__)]:
    (inputs / source.name).write_bytes(source.read_bytes())
tree('preflight-test-fix-inputs', inputs)
records['ciReviewCorrection'] = {'initialHead': '49e8d36c3e4929efa8dcba0c2e1aced9e5f9b8ff',
    'pushPassed': 41998815851, 'pullRequestFailed': 41999296250, 'operation': 'repeat-3',
    'sampleMs': 405.999008, 'unchangedLimitMs': 150, 'resourceResultRemainsFailed': True,
    'remoteTemporaryRawArtifactsAvailable': False, 'testChange': 'Separate functional terminal integration from retained resource failures.',
    'targetedTestsPassed': 3, 'correctedLocalFullTestsPassed': 955, 'assessorAndThresholdChanges': False}
(out/'records.json').write_text(json.dumps(records, indent=2) + '\n')
print(json.dumps({'trees': len(records['trees']), 'logs': len(records['logs'])}, indent=2))
