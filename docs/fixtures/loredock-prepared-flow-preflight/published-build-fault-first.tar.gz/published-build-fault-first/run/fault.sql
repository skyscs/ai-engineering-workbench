CREATE TRIGGER owned_publish_at_admission AFTER INSERT ON answer_witnesses BEGIN
UPDATE project SET publishedBuildId='065da064-8d04-452a-bd25-3cb650740d0c' WHERE id=1;
END;
