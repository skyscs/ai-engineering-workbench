import importlib.util,json,os,subprocess,types
from pathlib import Path
spec=importlib.util.spec_from_file_location('owned_module',"/home/toshiba/aew/worktrees/task128-browser-lifetime/scripts/loredock-prepared-flow/kernel-owner.py")
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
root=Path("/tmp/loredock-kernel-adoption-XBKNBr");output=root/'output';output.mkdir()
owner=module.Owner(types.SimpleNamespace(output=output,wall_ms=10000,storage_bytes=2147483648,grace_ms=200))
try:
 owner.bootstrap()
 parent=subprocess.Popen(["/home/toshiba/aew/toolchain/node-v22.23.2-linux-x64/bin/node",'-e',"const {spawn}=require('node:child_process');const child=spawn(process.execPath,['-e','setInterval(()=>{},1000)'],{detached:true,stdio:'ignore'});child.unref();console.log(child.pid);"],stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
 stdout,stderr=parent.communicate(timeout=5);(root/'intermediate-stdout.log').write_bytes(stdout);(root/'intermediate-stderr.log').write_bytes(stderr)
 assert parent.returncode==0
 orphan=int(stdout);rows=owner.descendants();row=next(row for row in rows if row['pid']==orphan)
 assert row['parent']==os.getpid() and row['group']==orphan
 owner.cleanup();owner.reap();assert owner.descendants()==[]
 assert any(row['pid']==orphan and row['exit']==-15 for row in owner.report['reaped'])
 module.save(output/'result.json',owner.report)
finally:
 owner.cleanup();owner.log.close();owner.samples.close()
