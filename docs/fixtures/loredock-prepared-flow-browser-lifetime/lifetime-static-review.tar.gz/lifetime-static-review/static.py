from pathlib import Path
from urllib.parse import unquote
import ast
import gzip
import hashlib
import json
import re
import subprocess
import tarfile

root = Path('/home/toshiba/aew/worktrees/task128-browser-lifetime')
out = root / 'docs/fixtures/loredock-prepared-flow-browser-lifetime'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
counts = {'trees': 0, 'entries': 0, 'logs': 0, 'localLinks': 0}

def headers(value):
    if isinstance(value, list):
        for child in value:
            headers(child)
    if isinstance(value, dict):
        if isinstance(value.get('name'), str) and re.match(r'^(set-cookie|cookie|x-loredock-csrf)$', value['name'], re.I) and 'value' in value:
            assert value['value'] == '[removed-session-material]'
        for key, child in value.items():
            if re.match(r'^(set-cookie|cookie|x-loredock-csrf|token)$', key, re.I):
                assert child == '[removed-session-material]'
            if key == 'headersText':
                for line in child.splitlines():
                    if re.match(r'^(set-cookie|cookie|x-loredock-csrf):', line, re.I):
                        assert line.split(':', 1)[1].strip() == '[removed-session-material]'
            headers(child)

for record in ['records.json']:
    data = json.loads((out / record).read_text())
    for row in data['logs']:
        raw = (out / row['path']).read_bytes()
        assert sha(raw) == row['archiveSha256']
        content = gzip.decompress(raw)
        assert len(content) == row['rawBytes'] and sha(content) == row['rawSha256']
        counts['logs'] += 1
    for row in data['trees']:
        raw = (out / row['path']).read_bytes()
        assert sha(raw) == row['sha256']
        expected = row.get('files')
        if expected is None:
            raw = (out / row['inventory']).read_bytes()
            assert sha(raw) == row['inventorySha256']
            expected = json.loads(gzip.decompress(raw))
        prefix = row['path'].removesuffix('.tar.gz') + '/'
        with tarfile.open(out / row['path'], 'r:gz') as archive:
            assert {m.name.removeprefix(prefix) for m in archive.getmembers()} == set(expected)
            for name, info in expected.items():
                member = archive.getmember(prefix + name)
                if info.get('kind') == 'symlink':
                    assert member.issym() and member.linkname == info['target']
                else:
                    assert member.isfile()
                    raw = archive.extractfile(member).read()
                    assert len(raw) == info['bytes'] and sha(raw) == info['sha256']
                    if name.endswith('/browser/events.jsonl'):
                        for line in raw.splitlines():
                            headers(json.loads(line))
                counts['entries'] += 1
        counts['trees'] += 1
base = '16f1c07815d3122fdd7227b1306ecf00883c7f80'
assert not subprocess.check_output(['git', 'diff', '--name-only', base, '--', 'apps', 'packages', 'fixtures', '.github', 'pnpm-lock.yaml', 'package.json', 'tasks/128-loredock-prepared-flow-resource-qualification.md', 'docs/loredock/PREPARED_FLOW_QUALIFICATION.md'], cwd=root).strip()
changed = set(subprocess.check_output(['git', 'diff', '--name-only', base], cwd=root, text=True).splitlines() +
              subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=root, text=True).splitlines())
for name in changed:
    file = root / name
    if file.suffix not in ['.md', '.json', '.mjs', '.py', '.ts']:
        continue
    text = file.read_text()
    assert not re.search('[А-Яа-яЁё]', text), name
    if file.suffix == '.py':
        ast.parse(text)
    if file.suffix == '.json':
        json.loads(text)
    if file.suffix != '.md':
        continue
    text = re.sub(r'```[^\n]*\n.*?```', '', text, flags=re.S)
    text = re.sub(r'`[^`\n]*`', '', text)
    for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)', text):
        if re.match(r'^(https?://|mailto:|#)', target):
            continue
        target = unquote(target.split('#')[0].split(' "')[0].strip('<>'))
        if target:
            assert (file.parent / target).exists(), (name, target)
            counts['localLinks'] += 1
print(json.dumps({**counts, 'applicationAndFrozenInputsUnchanged': True, 'archivedBrowserHeadersRedacted': True,
                  'modelCalls': 0, 'candidateFamilyReads': 0}, indent=2))
