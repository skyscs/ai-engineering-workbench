from pathlib import Path
import json
import re

base=Path('/home/toshiba/aew');helper=base/'task128-kernel-archive.py'
exec(helper.read_text().split("for name in ['core', 'browser', 'crash', 'interruption']:")[0])
repo=base/'worktrees/task128-browser-lifetime';out=repo/'docs/fixtures/loredock-prepared-flow-browser-lifetime'
records={'schemaVersion':'prepared-flow-browser-lifetime-development/1','resourceQualification':False,
         'modelCalls':0,'reservedFamilyReads':0,'tests':962,'trees':[],'logs':[],
         'acceptedOracle':{'pr':138,'head':'5bfad57f7c500f4992a74019035ddcc6e0c80fab',
                           'merge':'16f1c07815d3122fdd7227b1306ecf00883c7f80',
                           'push':42008587392,'pull_request':42008788188,'testsPerEvent':958}}
for name in ['browser-first','crash-first','browser-bound-parent','crash-bound-parent']:
    tree('lifetime-'+name,base/('task128-lifetime-'+name),
         'Earlier ordinary collector before explicit launcher-PID binding; original source inputs retained.' if name.endswith('first') else
         'Final parent-bound behavior. Fault timing overlaps repository checks; no resource qualification. Final source metadata clarifies OS counter interpretation without rewriting these raw reports.')
    log('lifetime-'+name,base/('task128-lifetime-'+name+'.log'))
tree('lifetime-retention',base/'task128-lifetime-retention')
tree('lifetime-first-inputs',base/'task128-lifetime-first-inputs')
for name in ['lifetime-install','lifetime-build','lifetime-focused-first','lifetime-focused-bound-parent','lifetime-focused-final','lifetime-check-first','lifetime-check-final','lifetime-retention','lifetime-seal-check','oracle-ci-push','oracle-ci-pr']:
    raw=log(name,base/('task128-'+name+'.log'))
    if name.startswith(('lifetime-focused-','lifetime-check-')):
        for kind,pattern in [('lifetime',r'Retained browser-lifetime test: (/tmp/loredock-browser-lifetime-[A-Za-z0-9]+)'),
                             ('owner',r'Retained kernel-owner test: (/tmp/loredock-kernel-(?:adoption|owner)-[A-Za-z0-9]+)'),
                             ('checkpoint',r'Retained history-checkpoint test: (/tmp/loredock-history-checkpoint-[A-Za-z0-9]+)')]:
            for i,location in enumerate(re.findall(pattern,raw)):
                tree(name+'-'+kind+'-'+str(i+1),Path(location))
inputs=base/'task128-lifetime-inputs';inputs.mkdir()
for source in [repo/'scripts/loredock-prepared-flow/browser.mjs',repo/'scripts/loredock-prepared-flow/browser-lifetime.py',
               repo/'scripts/tests/loredock-browser-lifetime.test.mjs',helper,base/'task128-lifetime-retention.py',Path(__file__)]:
    (inputs/source.name).write_bytes(source.read_bytes())
(inputs/'counter-references.json').write_text(json.dumps({'sources':['https://man7.org/linux/man-pages/man2/wait4.2.html','https://man7.org/linux/man-pages/man2/getrusage.2.html'],
 'interpretation':'Retain OS child counters without exclusive per-PID attribution or a simultaneous whole-tree peak; do not add maxima.'},indent=2)+'\n')
tree('lifetime-inputs',inputs)
records['retention']=json.loads((base/'task128-lifetime-retention/result.json').read_text())
(out/'records.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps({'trees':len(records['trees']),'logs':len(records['logs']),'tests':records['tests']},indent=2))
