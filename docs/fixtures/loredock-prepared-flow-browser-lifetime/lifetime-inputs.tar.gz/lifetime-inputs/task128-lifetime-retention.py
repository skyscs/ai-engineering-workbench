from pathlib import Path
import hashlib
import json
import os
import shutil
import sqlite3
import stat

base=Path('/home/toshiba/aew')
output=base/'task128-lifetime-retention';output.mkdir()
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def tree(root):
    result={}
    for directory,dirs,files in os.walk(root,followlinks=False):
        for name in dirs+files:
            file=Path(directory)/name;mode=file.lstat().st_mode
            if stat.S_ISREG(mode):result[str(file.relative_to(root))]=sha(file.read_bytes())
            elif stat.S_ISLNK(mode):result[str(file.relative_to(root))]={'symlink':os.readlink(file)}
    return result

results=[]
for name in ['browser-first','crash-first','browser-bound-parent','crash-bound-parent']:
    root=base/('task128-lifetime-'+name);before=tree(root)
    owner=json.loads((root/'result.json').read_text())
    lifetime=json.loads((root/'run/browser/lifetime/result.json').read_text())
    assert not owner['errors'] and not owner['survivors'] and not lifetime['errors'] and not lifetime['survivors']
    assert lifetime['subreaper'] and lifetime['globalLimitsOwner']=='external-evaluation-watchdog'
    crash=name.startswith('crash')
    assert owner['driverExit']['exit']==(7 if crash else 0)
    assert owner['reason']==('driver-left-owned-process' if crash else 'completed')
    assert lifetime['reason'] in (['parent-exited','collector-SIGTERM'] if crash else ['completed'])
    if not crash:assert lifetime['driverExit']['exit']==0
    assert len(lifetime['reaped'])>1 and any(row['pid']!=lifetime['driverExit']['pid'] for row in lifetime['reaped'])
    assert all(row['maxRssBytes']>=0 and row['userSeconds']>=0 and row['systemSeconds']>=0 for row in lifetime['reaped'])
    source=json.loads((root/'run/sources.json').read_text())
    for row in source['originals']:
        raw=(root/'run/sources'/row['source']/row['path']).read_bytes()
        assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
    copy=output/name/'data';shutil.copytree(root/'run/data',copy)
    database=sqlite3.connect((copy/'loredock.db').as_uri()+'?mode=ro',uri=True)
    assert database.execute('PRAGMA integrity_check').fetchall()==[('ok',)]
    assert database.execute('PRAGMA foreign_key_check').fetchall()==[]
    assert database.execute('SELECT status FROM answer_attempts').fetchall()==[('succeeded',)]
    assert database.execute('SELECT count(*) FROM answer_witnesses').fetchone()[0]==1
    database.close()
    samples=[json.loads(line) for line in (root/'run/browser/process-tree.jsonl').read_text().splitlines()]
    process=json.loads((root/'run/browser/process.json').read_text())
    assert samples and all(row['rows'][0]['pid']==process['pid'] for row in samples)
    assert all(row['rssBytes']==sum(child.get('rssBytes',0) for child in row['rows']) for row in samples)
    if not crash:
        result=json.loads((root/'run/result.json').read_text())
        assert not result['errors'] and result['controlled']['calls']==1
        assert result['browser']['memoryScope'].startswith('Browser lifetime collector')
        assert result['browser']['memorySamples']==len(samples)
    assert tree(root)==before
    results.append({'case':name,'sourceHashesUnchanged':True,'rawTreeUnchangedByInspection':True,
                    'catalogIntegrity':'ok','foreignKeys':[],'answers':1,'witnesses':1,'ownerErrors':[],
                    'ownedSurvivors':[],'collectorReason':lifetime['reason'],'reapedChildren':len(lifetime['reaped']),
                    'memorySamples':len(samples),'incompleteSamples':sum(not row['complete'] for row in samples),
                    'maximumSampledRssBytesIncludingCollector':max(row['rssBytes'] for row in samples)})
(output/'result.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
