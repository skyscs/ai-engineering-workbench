"""Consume the separately sealed Task 154 launch exactly once."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time

sys.dont_write_bytecode = True
root = Path('/home/toshiba/aew')
seal = json.loads((root / 'task154-launch-seal.json').read_text())
manifest = Path(seal['manifest'])
assert hashlib.sha256(manifest.read_bytes()).hexdigest() == seal['sha256']
assert not Path(seal['firstOutput']).exists()
assert not Path(seal['firstOutput'] + '.claim').exists()
helper = manifest.parent / 'probe.py'
spec = importlib.util.spec_from_file_location('sealed_user_probe', helper)
probe = importlib.util.module_from_spec(spec)
spec.loader.exec_module(probe)
probe.load_manifest(manifest, seal['sha256'])
command = ['/usr/bin/python3', '-I', '-S', '-B', str(helper), '--run-first', str(manifest), seal['sha256']]
started = time.monotonic_ns()
probe.retain(root / 'task154-launch-intent.json', {'manifestSha256': seal['sha256'], 'command': command,
    'candidateHead': seal['candidateHead'], 'startedAtNs': str(started),
    'status': 'Intent retained before the sole launch; outcome is recorded separately.'})
record = {'manifestSha256': seal['sha256'], 'command': command, 'candidateHead': seal['candidateHead']}
with (root / 'task154-namespace-launch-first.log').open('xb') as stream:
    try:
        result = subprocess.run(command, stdin=subprocess.DEVNULL, stdout=stream, stderr=subprocess.STDOUT,
            timeout=45, env={'PATH': '/usr/bin:/bin', 'LANG': 'C.UTF-8', 'XDG_RUNTIME_DIR': '/run/user/1000',
                'DBUS_SESSION_BUS_ADDRESS': 'unix:path=/run/user/1000/bus'})
        record.update(exitCode=result.returncode, failure=None)
    except (Exception, KeyboardInterrupt) as error:
        record.update(exitCode=None, failure=type(error).__name__, message=str(error)[:4096])
    stream.flush()
    os.fsync(stream.fileno())
record['durationNs'] = str(time.monotonic_ns() - started)
probe.retain(root / 'task154-namespace-launch-first.json', record)
print(json.dumps(record, separators=(',', ':')))
raise SystemExit(0 if record['exitCode'] == 0 and record['failure'] is None else 1)
