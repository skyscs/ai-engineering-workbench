from pathlib import Path
import gzip
import hashlib
import json
import os
import shutil
import sqlite3
import stat

base=Path('/home/toshiba/aew');root=base/'task128-browser-measurements-first';run=root/'run';repo=base/'worktrees/task128-browser-measurements'
output=base/'task128-browser-measurements-retention';output.mkdir()
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def read(file):return json.loads(file.read_text())
def inventory(directory):
    result={}
    for parent,dirs,files in os.walk(directory,followlinks=False):
        for name in sorted(dirs+files):
            p=Path(parent)/name;s=p.lstat();rel=str(p.relative_to(directory))
            if stat.S_ISLNK(s.st_mode):result[rel]={'kind':'symlink','target':os.readlink(p)}
            elif stat.S_ISREG(s.st_mode):result[rel]={'bytes':s.st_size,'sha256':sha(p.read_bytes())}
            else:assert stat.S_ISDIR(s.st_mode)
    return result
before=inventory(root);owner=read(root/'result.json');driver=read(run/'result.json')
assert owner['reason']=='driver-failure' and owner['driverExit']['exit']==1 and owner['errors']==[] and owner['survivors']==[] and driver['errors']==[]
report={'resourceQualification':False,'modelCalls':0,'reservedFamilyReads':0,'catalogs':[],'httpBodies':0,'httpRedactedSessions':0,'browserBodies':0,'browserRedactedSessions':0,'reusedInputFiles':0,'screenshots':[]}
history=base/'task128-ordered-history-second';manifest=json.loads(gzip.decompress((repo/'docs/fixtures/loredock-prepared-flow-history/ordered-history-second.inventory.json.gz').read_bytes()))
for name,info in manifest.items():
    if any(name.startswith(prefix) for prefix in ['run/sources/','run/capacity/checkpoint-20/','run/capacity/checkpoint-64/']):
        raw=(history/name).read_bytes();assert len(raw)==info['bytes'] and sha(raw)==info['sha256'];report['reusedInputFiles']+=1
assert [row['rows'] for row in driver['cases']]==[20,64]
for row in driver['cases']:
    count=row['rows'];case=run/('history-'+str(count));checkpoint=read(case/'input.json');assert inventory(Path(checkpoint['data']))==checkpoint['files']
    assert row['value']['errors']==[]
    assessment=row['assessment'];assert assessment['status']=='failed' and assessment['incomplete']==[] and assessment['api']['http']['status']=='passed'
    assert [c['metric'] for c in assessment['checks'] if not c['passed']]==['browserProcessTreeRssBytes']
    browser=case/'browser';process=read(case/'daemon/process.json');assert all(process[k] is False for k in ['controlled','fault','accounting'])
    assert read(case/'daemon/exit.json')['code']==0
    end=read(browser/'exit.json');assert end['code']==0 and end['errors']==[] and end['sampleError'] is None and end['incompleteMemorySamples']==0
    assert end['lifetime']['reason']=='completed' and end['lifetime']['errors']==[] and end['lifetime']['survivors']==[]
    events=[json.loads(line) for line in (browser/'events.jsonl').read_text().splitlines()];requests={};bodies={};finished=set();preparations=0
    for event in events:
        if event['event']=='protocol':
            value=event['value'];params=value['params'];method=value['method'];key=params.get('requestId')
            if method=='Network.requestWillBeSent' and params['request']['url'].startswith('http://127.0.0.1:4244/api/'):
                assert key not in requests;requests[key]=params['request']
                if requests[key]['method']=='POST' and requests[key]['url'].endswith('/api/question-preparations'):preparations+=1
                assert not (requests[key]['method']=='POST' and requests[key]['url'].endswith('/api/prepared-answers'))
            if method=='Network.loadingFinished' and key in requests:finished.add(key)
            if method=='Network.loadingFailed':assert key not in requests
        if event['event']=='api-body':assert event['requestId'] not in bodies;bodies[event['requestId']]=event
    assert set(requests)==set(bodies)==finished and preparations==1
    for key,event in bodies.items():
        raw=(browser/event['file']).read_bytes();assert len(raw)==event['retainedBytes'] and sha(raw)==event['retainedSha256']
        assert event['url']==requests[key]['url'];value=json.loads(raw);parsed=read(browser/('response-'+key.replace('.','-')+'.json'))
        if event['redacted']:
            assert requests[key]['url'].endswith('/api/session') and event['rawSha256'] is None
            assert value['token']=='[removed-session-token]' and parsed['token']=='[removed-session-material]';report['browserRedactedSessions']+=1
        else:assert len(raw)==event['bytes'] and sha(raw)==event['rawSha256'] and value==parsed
        report['browserBodies']+=1
    assert len(bodies)==assessment['api']['requests']==assessment['api']['bodies']
    observation=read(browser/'observation.json');assert observation['pendingPaints']==0 and len(observation['actions'])==1 and observation['updates']
    assert observation['longTasks']==[]
    for kind in ['actions','updates']:
        for value in observation[kind]:assert value['visible'] and 0<=value['duration']<=2000
    for name in ['desktop','mobile']:
        assert read(browser/(name+'.json'))['overflow'] is False
        file=browser/(name+'.png');raw=file.read_bytes();assert raw.startswith(b'\x89PNG\r\n\x1a\n')
        report['screenshots'].append({'path':str(file),'bytes':len(raw),'sha256':sha(raw)})
    copied=output/('history-'+str(count))/'data';copied.parent.mkdir(parents=True);shutil.copytree(case/'data',copied);assert inventory(case/'data')==inventory(copied)
    db=sqlite3.connect('file:'+str(copied/'loredock.db')+'?mode=ro',uri=True)
    try:
        assert db.execute('PRAGMA integrity_check').fetchall()==[('ok',)] and db.execute('PRAGMA foreign_key_check').fetchall()==[]
        assert db.execute('SELECT status,count(*) FROM answer_attempts GROUP BY status').fetchall()==[('succeeded',count)]
        assert sorted(x['id'] for x in checkpoint['admissions'])==[x[0] for x in db.execute('SELECT id FROM answer_attempts ORDER BY id')]
        storage=db.execute('SELECT count(*),sum(purged),sum(witnessBytes) FROM answer_witnesses').fetchone();assert storage==(count,0,count*66336)
        report['catalogs'].append({'source':str(case/'data'),'copy':str(copied),'integrity':'ok','foreignKeyErrors':[],'successfulAttempts':count,'witnessStorage':storage})
    finally:db.close()
for file in run.rglob('requests.jsonl'):
    requests={};responses=set()
    for line in file.read_text().splitlines():
        row=json.loads(line);key=row['id'];assert row['event']!='failure'
        if row['event']=='request':assert key not in requests;requests[key]=row
        if row['event']=='response':
            assert key in requests and key not in responses and row['status']<400;responses.add(key);raw=(file.parent/(key+'.json')).read_bytes()
            if requests[key]['route']=='/session':assert json.loads(raw)['token']=='[removed-session-token]';report['httpRedactedSessions']+=1
            else:assert len(raw)==row['bytes'];report['httpBodies']+=1
    assert set(requests)==responses
assert len(report['catalogs'])==2 and inventory(root)==before
report.update(rawInputsUnchanged=True,entries=len(before))
(output/'result.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
