from pathlib import Path
import json
import re

base=Path('/home/toshiba/aew');helper=base/'task128-kernel-archive.py'
exec(helper.read_text().split("for name in ['core', 'browser', 'crash', 'interruption']:")[0])
repo=base/'worktrees/task128-browser-measurements';out=repo/'docs/fixtures/loredock-prepared-flow-browser-measurements';out.mkdir(exist_ok=True)
accepted=json.loads((base/'task128-integration-handoff.json').read_text())['latestAccepted'];assert accepted['pr']==151 and accepted['testsPerEvent']==985
records={'schemaVersion':'prepared-flow-browser-measurements-development/1','resourceQualification':False,'modelCalls':0,'reservedFamilyReads':0,'trees':[],'logs':[],'screenshots':[],'acceptedOracles':accepted}
for name in ['browser-measurements-first','browser-measurements-first-inputs','browser-measurements-reassessment-first','browser-measurements-retention']:tree(name,base/('task128-'+name))
history=base/'task128-ordered-history-second/run'
for name,source in [('sources',history/'sources'),('checkpoint-20',history/'capacity/checkpoint-20'),('checkpoint-64',history/'capacity/checkpoint-64')]:tree('browser-measurements-reused-'+name,source)
for name in ['browser-measurements-first','browser-measurements-reassessment-first','browser-measurements-install','browser-measurements-build','browser-measurements-tests-first','browser-measurements-tests-second','browser-measurements-retention','browser-measurements-reassessment-check','browser-measurements-seal-check','oracle-cases-ci-push','oracle-cases-ci-pr']:log(name,base/('task128-'+name+'.log'))
for run in ['first','second']:
    testlog=(base/('task128-browser-measurements-tests-'+run+'.log')).read_text()
    for i,location in enumerate(re.findall(r'Retained browser-evidence test: (/tmp/loredock-browser-evidence-[A-Za-z0-9]+)',testlog)):tree('browser-measurements-test-'+run+'-'+str(i+1),Path(location))
inputs=base/'task128-browser-measurements-inputs';inputs.mkdir()
for source in [repo/'scripts/loredock-prepared-flow'/name for name in ['browser.mjs','browser-evidence.mjs','browser-assess.mjs','browser-measurements-development.mjs','reassess-browser-development.mjs']]+[
    repo/'scripts/tests/loredock-browser-evidence.test.mjs',helper,base/'task128-browser-measurements-retention.py',base/'task128-browser-measurements-reassessment-check.py',repo/'docs/fixtures/loredock-prepared-flow-history/ordered-history-second.inventory.json.gz',Path(__file__)]:
    (inputs/source.name).write_bytes(source.read_bytes())
tree('browser-measurements-inputs',inputs)
for rows in [20,64]:
    for name in ['desktop','mobile']:
        file=base/'task128-browser-measurements-first/run'/('history-'+str(rows))/'browser'/(name+'.png');raw=file.read_bytes();destination=out/('history-'+str(rows)+'-'+name+'.png');assert not destination.exists();destination.write_bytes(raw)
        records['screenshots'].append({'path':destination.name,'bytes':len(raw),'sha256':sha(raw)})
records['retention']=json.loads((base/'task128-browser-measurements-retention/result.json').read_text())
records['reassessmentCheck']=json.loads((base/'task128-browser-measurements-reassessment-check.log').read_text())
(out/'records.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps({'trees':len(records['trees']),'logs':len(records['logs'])},indent=2))
