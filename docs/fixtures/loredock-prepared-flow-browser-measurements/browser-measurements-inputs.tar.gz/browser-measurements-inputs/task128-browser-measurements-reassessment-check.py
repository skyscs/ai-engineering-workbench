from pathlib import Path
import json
base=Path('/home/toshiba/aew');original=base/'task128-browser-measurements-first/run';root=base/'task128-browser-measurements-reassessment-first'
read=lambda p:json.loads(p.read_text())
owner=read(root/'result.json');result=read(root/'run/result.json')
assert owner['reason']=='driver-failure' and owner['driverExit']['exit']==1 and owner['errors']==[] and owner['survivors']==[]
assert result['errors']==[] and result['newBrowserRuns']==0 and result['rawInputUnchanged'] is True
rows=[]
for row in result['cases']:
    previous=read(original/('history-'+str(row['rows']))/'browser-assessment.json');current=row['assessment']
    assert previous['status']==current['status']=='failed' and current['incomplete']==[]
    assert current['api']==previous['api'] and current['observed']==previous['observed']
    assert [c for c in current['checks'] if c['metric']!='browserSampleGapMs']==previous['checks']
    cadence=next(c for c in current['checks'] if c['metric']=='browserSampleGapMs')
    assert cadence['limit']==100 and cadence['value']>100 and not cadence['passed']
    assert cadence['value']==previous['observed']['maxSampleGapMs']
    rows.append({'rows':row['rows'],'onlyAddedCheck':cadence,'originalFailurePreserved':True})
assert len(rows)==2
print(json.dumps({'cases':rows,'newBrowserRuns':0,'resourceQualification':False},indent=2))
