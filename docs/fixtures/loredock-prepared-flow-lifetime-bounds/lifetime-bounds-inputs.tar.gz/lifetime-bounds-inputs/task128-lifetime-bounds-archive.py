from pathlib import Path
import json

base=Path('/home/toshiba/aew');helper=base/'task128-kernel-archive.py'
exec(helper.read_text().split("for name in ['core', 'browser', 'crash', 'interruption']:")[0])
repo=base/'worktrees/task128-lifetime-bounds';out=repo/'docs/fixtures/loredock-prepared-flow-lifetime-bounds';out.mkdir(exist_ok=True)
accepted=json.loads((base/'task128-integration-handoff.json').read_text())['latestAccepted'];assert accepted['pr']==155 and accepted['testsPerEvent']==1004
records={'schemaVersion':'prepared-flow-lifetime-bounds-development/1','resourceQualification':False,'modelCalls':0,'reservedFamilyReads':0,'trees':[],'logs':[],'acceptedHttpOutcomes':accepted}
for name in ['lifetime-bounds-first','lifetime-bounds-retention','lifetime-bounds-first-inputs']:tree(name,base/('task128-'+name))
for name in ['lifetime-bounds-first','lifetime-bounds-install','lifetime-bounds-build','lifetime-bounds-tests-first','lifetime-bounds-tests-second','lifetime-bounds-retention','lifetime-bounds-seal-check','http-outcomes-ci-push','http-outcomes-ci-pr','http-outcomes-merge-audit']:log(name,base/('task128-'+name+'.log'))
inputs=base/'task128-lifetime-bounds-inputs';inputs.mkdir()
for source in [repo/'scripts/loredock-prepared-flow'/name for name in ['lifetime-assess.mjs','lifetime-bounds-development.mjs','cold-warm-cases.mjs','flow.mjs','io.mjs','worker-accounting-case.mjs','accounting.mjs','launcher.mjs']]+[
    repo/'scripts/tests/loredock-lifetime-assess.test.mjs',repo/'scripts/tests/loredock-cold-warm.test.mjs',helper,base/'task128-lifetime-bounds-retention.py',Path(__file__)]+[
    repo/'apps/loredock/src'/name for name in ['question-preparation.ts','prepared-answer.ts','answer-witness-store.ts','operation-budget.ts']]:
    (inputs/source.name).write_bytes(source.read_bytes())
tree('lifetime-bounds-inputs',inputs)
records['retention']=json.loads((base/'task128-lifetime-bounds-retention/result.json').read_text())
(out/'records.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps({'trees':len(records['trees']),'logs':len(records['logs'])},indent=2))
