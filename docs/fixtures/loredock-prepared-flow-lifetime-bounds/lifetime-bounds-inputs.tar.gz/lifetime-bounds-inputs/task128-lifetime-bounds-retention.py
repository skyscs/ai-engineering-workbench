from pathlib import Path
import hashlib
import json
import shutil
import sqlite3
import subprocess

base=Path('/home/toshiba/aew');root=base/'task128-lifetime-bounds-first';run=root/'run'
output=base/'task128-lifetime-bounds-retention';output.mkdir()
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def read(file):return json.loads(file.read_text())
def inventory(directory):return {str(p.relative_to(directory)):{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(directory.rglob('*')) if p.is_file()}
before=inventory(root);owner=read(root/'result.json');driver=read(run/'result.json')
assert owner['reason']=='driver-failure' and owner['driverExit']['exit']==1 and owner['errors']==[] and owner['survivors']==[] and driver['errors']==[]
assert len(driver['daemonMetricFailures'])==2 and driver['workFailures']==[]
for row in driver['daemonMetricFailures']:assert row['metric']=='rawIntervalGapMs' and row['value']>row['limit']==100
report={'resourceQualification':False,'modelCalls':0,'reservedFamilyReads':0,'catalogs':[],'httpBodies':0,'redactedSessions':0,'sourceGitIdentities':0}
sources=read(run/'sources.json')
for name,identity in sources['revisions'].items():
    directory=run/'sources'/name
    for key,ref in [('revision','HEAD'),('tree','HEAD^{tree}')]:
        assert subprocess.check_output(['git','-c','core.hooksPath=/dev/null','rev-parse',ref],cwd=directory,text=True).strip()==identity[key]
    assert not subprocess.check_output(['git','-c','core.hooksPath=/dev/null','status','--porcelain'],cwd=directory)
    report['sourceGitIdentities']+=1
for row in sources['originals']:
    raw=(run/'sources'/row['source']/row['path']).read_bytes();assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
for file in run.rglob('requests.jsonl'):
    pending={};responses=set()
    for line in file.read_text().splitlines():
        row=json.loads(line);key=row['id'];assert row['event']!='failure'
        if row['event']=='request':assert key not in pending;pending[key]=row
        if row['event']=='response':
            assert key in pending and key not in responses and row['status']<400;responses.add(key)
            raw=(file.parent/(key+'.json')).read_bytes()
            if pending[key]['route']=='/session':assert json.loads(raw)['token']=='[removed-session-token]';report['redactedSessions']+=1
            else:assert len(raw)==row['bytes'];report['httpBodies']+=1
    assert set(pending)==responses
cold=read(run/'cold/result.json');warm=read(run/'warm/result.json');diagnostic=read(run/'accounting/result.json')
assert all(x['errors']==[] for x in [cold,warm,diagnostic])
assert len(warm['repetitions'])==3 and warm['exactWitnessPromptParity'] is True
assert diagnostic['outputParity'] is True and diagnostic['storedByteParity'] is True and diagnostic['diagnosticTimingQualified'] is False
assert diagnostic['runtime']=={'prepares':1,'calls':1,'closed':1}
assert diagnostic['audit']=={'activeScope':None,'lateActivities':[],'unscopedBudgets':[],'observedBudgets':10,'unclosedBudgets':[]}
accounting=diagnostic['accounting'];assert len(accounting['budgets'])==10 and accounting['totalWork']==2570082
for budget in accounting['budgets']:
    assert budget['closes']==1 and budget['errors']=={} and sum(x['accepted'] for x in budget['charges'].values())==budget['final']['totalWork']
assert accounting['totalWork']==sum(b['final']['totalWork'] for b in accounting['budgets'])
assert accounting['requestedWork']==sum(x['requested'] for b in accounting['budgets'] for x in b['charges'].values())==accounting['totalWork']
assert all(x['passed'] for x in diagnostic['workChecks'])
assert inventory(Path(cold['checkpoint']['data']))==cold['checkpoint']['files']
assert read(run/'accounting/inputs.json')['ordinaryReference']==warm['repetitions'][0]
for directory,controlled,account in [('cold/production',False,False),('warm/controlled',True,False),('accounting/diagnostic',True,True)]:
    process=read(run/directory/'process.json');assert process['controlled']==controlled and process['accounting']==account and process['fault'] is False
    assert read(run/directory/'exit.json')['code']==0
reference=warm['repetitions'][0];actual=diagnostic['observation']
def omit(x,keys):return {k:v for k,v in x.items() if k not in keys}
assert omit(reference['prepared']['review'],['id','requestId'])==omit(actual['prepared']['review'],['id','requestId'])
assert omit(reference['published']['answer'],['id','createdAt','dispatchedAt'])==omit(actual['published']['answer'],['id','createdAt','dispatchedAt'])
assert (run/'warm/controlled/request-1.json').read_bytes()==(run/'accounting/diagnostic/request-1.json').read_bytes()
witnesses={}
for original in sorted(run.rglob('loredock.db')):
    relative=original.parent.relative_to(run);copied=output/relative;copied.parent.mkdir(parents=True,exist_ok=True)
    shutil.copytree(original.parent,copied);assert inventory(original.parent)==inventory(copied)
    db=sqlite3.connect('file:'+str(copied/'loredock.db')+'?mode=ro',uri=True)
    try:
        assert db.execute('PRAGMA integrity_check').fetchall()==[('ok',)] and db.execute('PRAGMA foreign_key_check').fetchall()==[]
        states=db.execute('SELECT status,count(*) FROM answer_attempts GROUP BY status').fetchall()
        rows=db.execute('SELECT a.id,a.context,w.witness,w.reviewedHash FROM answer_attempts a JOIN answer_witnesses w ON w.answerId=a.id').fetchall()
        if relative.parts[0]=='cold':assert states==[] and rows==[]
        else:
            observations=warm['repetitions'] if relative.parts[0]=='warm' else [{**actual,'stored':diagnostic['stored']}]
            assert states==[('succeeded',len(observations))] and len(rows)==len(observations)
            for observation in observations:
                row=next(r for r in rows if r[0]==observation['published']['answer']['id']); context,witness,reviewed=row[1:]
                assert json.loads(context)==observation['prepared']['review']['context']
                assert json.loads(witness)['prompt']==observation['request']['prompt']
                assert json.loads(witness)['compact']==observation['prepared']['review']['compact']
                assert observation['stored']=={'contextSha256':sha(context.encode()),'witnessSha256':sha(witness.encode()),'witnessBytes':len(witness.encode()),'reviewedHash':reviewed}
            target=reference if relative.parts[0]=='warm' else actual
            witnesses[relative.parts[0]]=next(r[1:] for r in rows if r[0]==target['published']['answer']['id'])
        report['catalogs'].append({'source':str(original.parent),'copy':str(copied),'integrity':'ok','foreignKeyErrors':[],'answerStates':states,'witnessRows':len(rows)})
    finally:db.close()
assert witnesses['warm']==witnesses['accounting']

lifetime=read(run/'lifetime-assessment.json');assert lifetime==driver['lifetime'] and lifetime['status']=='passed'
assert lifetime['incomplete']==[] and lifetime['diagnosticTimingUsed'] is False and lifetime['exactPerOperationDurations'] is False
assert len(lifetime['checks'])==16 and all(row['status']=='passed' and row['value']<=row['limit'] for row in lifetime['checks'])
for row in warm['repetitions']:
    assert row['scopeEnd']=='history-and-runtime-closed' and row['drainedElapsedMs']>=row['elapsedMs']>=row['prepared']['elapsedMs']
    assert row['runtime']=={'prepares':row['repetition'],'calls':row['repetition'],'closed':row['repetition']}
    assert row['drainedElapsedMs']<=5000
    original=read(run/('warm/repetition-'+str(row['repetition'])+'.json'))
    assert original['drainedElapsedMs']==row['drainedElapsedMs'] and original['scopeEnd']==row['scopeEnd']
for value in [cold,warm]:assert value['exit']['alreadyExited'] is False and 0<=value['exit']['shutdownMs']<=10000
assert cold['index']['indexThroughAnalysisMs']>=cold['index']['indexMs'] and cold['index']['indexThroughAnalysisMs']<=300000
report['lifetimeChecks']=len(lifetime['checks']);report['enclosingBoundsOnly']=True

assert len(report['catalogs'])==4 and inventory(root)==before
assert inventory(Path(cold['checkpoint']['data']))==cold['checkpoint']['files']
report.update(rawInputsUnchanged=True,entries=len(before),actualBudgets=10,totalWork=2570082,rawRequestAndStoredByteParity=True)
(output/'result.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
