<script setup lang="ts">
import { searchCatalog } from "./search";
const search4 = () => searchCatalog("title");
</script>
<template><button @click="search4">Search catalog</button></template>
