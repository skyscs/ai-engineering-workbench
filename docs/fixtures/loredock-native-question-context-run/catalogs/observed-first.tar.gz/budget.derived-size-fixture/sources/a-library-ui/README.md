# Library desk
returnLoan calls requestReturn to submit POST /loans/returns with X-Library-Branch.
Catalog search actions use a separate read route. Static source links do not verify deployment.
