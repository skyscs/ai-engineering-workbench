<script setup lang="ts">
import { searchCatalog } from "./search";
const search5 = () => searchCatalog("title");
</script>
<template><button @click="search5">Search catalog</button></template>
