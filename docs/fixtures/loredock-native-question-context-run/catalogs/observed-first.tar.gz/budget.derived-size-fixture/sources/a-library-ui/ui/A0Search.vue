<script setup lang="ts">
import { searchCatalog } from "./search";
const search0 = () => searchCatalog("title");
</script>
<template><button @click="search0">Search catalog</button></template>
