<script setup lang="ts">
import { searchCatalog } from "./search";
const search2 = () => searchCatalog("title");
</script>
<template><button @click="search2">Search catalog</button></template>
