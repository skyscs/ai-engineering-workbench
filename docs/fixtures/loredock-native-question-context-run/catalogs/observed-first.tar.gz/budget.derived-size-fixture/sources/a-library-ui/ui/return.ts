export function requestReturn(branch: string, loan: string) {
  return fetch("/loans/returns", { method: "POST", headers: { "X-Library-Branch": branch }, body: JSON.stringify({ loan }) });
}
