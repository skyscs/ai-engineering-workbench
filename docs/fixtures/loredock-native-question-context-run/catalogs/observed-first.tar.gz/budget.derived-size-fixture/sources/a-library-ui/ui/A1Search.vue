<script setup lang="ts">
import { searchCatalog } from "./search";
const search1 = () => searchCatalog("title");
</script>
<template><button @click="search1">Search catalog</button></template>
