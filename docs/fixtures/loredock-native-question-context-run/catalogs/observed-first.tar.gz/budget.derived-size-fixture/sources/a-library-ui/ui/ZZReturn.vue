<script setup lang="ts">
import { requestReturn } from "./return";
const props = defineProps<{ branch: string; loan: string }>();
const returnLoan = () => requestReturn(props.branch, props.loan);
</script>
<template><button @click="returnLoan">Return loan</button></template>
