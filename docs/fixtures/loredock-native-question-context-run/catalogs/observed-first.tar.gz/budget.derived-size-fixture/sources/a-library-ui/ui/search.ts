export function searchCatalog(key: string) {
  return fetch("/catalog/search", { method: "GET", headers: { "X-Search-Key": key } });
}
