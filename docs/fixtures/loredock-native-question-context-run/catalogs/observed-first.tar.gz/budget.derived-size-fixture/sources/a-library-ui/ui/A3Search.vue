<script setup lang="ts">
import { searchCatalog } from "./search";
const search3 = () => searchCatalog("title");
</script>
<template><button @click="search3">Search catalog</button></template>
