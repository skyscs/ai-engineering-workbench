# Operations scope
No production environment, broker address or deployed revision vector is supplied.
