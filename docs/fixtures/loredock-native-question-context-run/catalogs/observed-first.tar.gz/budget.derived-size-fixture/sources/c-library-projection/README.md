# Loan projection
LoanWriter subscribes to library.loan.returned.v2 and its onMessage method calls MongoCollection.replaceOne.
The collection interface has no concrete database binding here.
