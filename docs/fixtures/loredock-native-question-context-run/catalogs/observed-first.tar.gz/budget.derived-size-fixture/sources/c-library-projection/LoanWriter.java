record LoanReturned(String branch, String loan) {}
record BranchKey(String branch) {}
interface MongoCollection { void replaceOne(BranchKey selector, LoanReturned document, boolean upsert); }
interface KafkaSubscriber { void subscribe(String topic, String group, LoanWriter handler); }
final class LoanWriter {
  private final MongoCollection collection;
  LoanWriter(MongoCollection collection) { this.collection = collection; }
  void start(KafkaSubscriber subscriber, String group) { subscriber.subscribe("library.loan.returned.v2", group, this); }
  void onMessage(LoanReturned event) {
    var selector = new BranchKey(event.branch());
    collection.replaceOne(selector, event, true);
  }
}
