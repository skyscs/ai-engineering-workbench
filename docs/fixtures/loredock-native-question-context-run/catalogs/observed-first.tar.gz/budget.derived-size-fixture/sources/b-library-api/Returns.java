record LoanReturned(String branch, String loan) {}
interface EventPublisher { void publish(String topic, String key, LoanReturned event); }
final class Returns {
  private final EventPublisher publisher;
  Returns(EventPublisher publisher) { this.publisher = publisher; }
  void accept(String branch, String loan) {
    var event = new LoanReturned(branch, loan);
    publisher.publish("library.loan.returned.v2", branch, event);
  }
}
