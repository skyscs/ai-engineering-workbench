# Loan returns
Returns.accept publishes LoanReturned on library.loan.returned.v2.
The declaration does not establish a live broker, delivery guarantees or header enforcement.
