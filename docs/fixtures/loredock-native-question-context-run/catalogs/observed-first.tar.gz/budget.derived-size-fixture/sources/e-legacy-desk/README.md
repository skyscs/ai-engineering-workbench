# Legacy desk
The Dojo module exposes a local catalog helper; its presence does not prove runtime use.
