define([], function () { return { catalogHint: function () { return "catalog"; } }; });
