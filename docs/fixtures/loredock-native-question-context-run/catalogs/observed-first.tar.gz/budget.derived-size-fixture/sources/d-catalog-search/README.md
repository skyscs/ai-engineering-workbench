# Catalog search
Lookup.find handles GET /catalog/search. It does not declare a loan-return publisher.
