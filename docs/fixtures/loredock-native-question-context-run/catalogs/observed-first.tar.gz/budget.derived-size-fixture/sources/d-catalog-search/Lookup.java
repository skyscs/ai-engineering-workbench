final class Lookup { void find(String key) {} }
