export const padding493 = 1;
