export const padding205 = 1;
