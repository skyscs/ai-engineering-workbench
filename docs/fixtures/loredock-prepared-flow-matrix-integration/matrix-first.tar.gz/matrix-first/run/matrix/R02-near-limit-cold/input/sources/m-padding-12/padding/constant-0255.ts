export const padding255 = 1;
