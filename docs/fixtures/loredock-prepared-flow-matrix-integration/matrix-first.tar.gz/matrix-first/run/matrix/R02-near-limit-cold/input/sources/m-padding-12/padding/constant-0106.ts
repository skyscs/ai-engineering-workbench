export const padding106 = 1;
