export const padding266 = 1;
