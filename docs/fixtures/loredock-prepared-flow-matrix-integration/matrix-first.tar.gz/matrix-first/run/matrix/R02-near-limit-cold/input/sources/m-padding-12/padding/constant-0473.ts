export const padding473 = 1;
