export const padding1 = 1;
