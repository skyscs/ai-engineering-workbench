export const padding272 = 1;
