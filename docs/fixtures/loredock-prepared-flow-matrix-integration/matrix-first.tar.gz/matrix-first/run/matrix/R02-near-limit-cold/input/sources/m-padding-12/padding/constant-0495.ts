export const padding495 = 1;
