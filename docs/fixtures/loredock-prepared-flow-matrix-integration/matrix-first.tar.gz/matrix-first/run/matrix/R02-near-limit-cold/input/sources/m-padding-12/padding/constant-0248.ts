export const padding248 = 1;
