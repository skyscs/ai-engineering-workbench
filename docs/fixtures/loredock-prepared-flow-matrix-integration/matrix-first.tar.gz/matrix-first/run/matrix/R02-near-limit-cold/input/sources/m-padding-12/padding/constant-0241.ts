export const padding241 = 1;
