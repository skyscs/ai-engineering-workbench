export const padding296 = 1;
