export const padding232 = 1;
