export const padding340 = 1;
