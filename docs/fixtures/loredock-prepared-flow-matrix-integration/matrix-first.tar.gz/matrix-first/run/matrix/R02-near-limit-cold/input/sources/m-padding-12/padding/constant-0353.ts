export const padding353 = 1;
