export const padding42 = 1;
