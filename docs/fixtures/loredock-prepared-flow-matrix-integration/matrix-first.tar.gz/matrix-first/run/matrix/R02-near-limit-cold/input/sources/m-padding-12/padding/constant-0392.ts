export const padding392 = 1;
