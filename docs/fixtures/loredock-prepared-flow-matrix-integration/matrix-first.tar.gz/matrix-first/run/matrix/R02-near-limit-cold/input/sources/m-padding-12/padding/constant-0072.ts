export const padding72 = 1;
