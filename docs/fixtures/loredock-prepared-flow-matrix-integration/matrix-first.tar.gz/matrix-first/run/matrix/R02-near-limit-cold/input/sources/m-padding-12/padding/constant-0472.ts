export const padding472 = 1;
