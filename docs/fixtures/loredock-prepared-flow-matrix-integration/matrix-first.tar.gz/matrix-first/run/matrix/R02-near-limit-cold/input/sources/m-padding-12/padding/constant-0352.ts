export const padding352 = 1;
