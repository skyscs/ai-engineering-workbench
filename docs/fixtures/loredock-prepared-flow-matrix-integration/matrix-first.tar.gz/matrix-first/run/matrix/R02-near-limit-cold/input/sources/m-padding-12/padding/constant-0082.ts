export const padding82 = 1;
