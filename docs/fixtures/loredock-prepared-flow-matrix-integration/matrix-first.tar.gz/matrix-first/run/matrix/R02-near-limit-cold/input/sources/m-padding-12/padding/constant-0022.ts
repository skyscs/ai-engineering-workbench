export const padding22 = 1;
