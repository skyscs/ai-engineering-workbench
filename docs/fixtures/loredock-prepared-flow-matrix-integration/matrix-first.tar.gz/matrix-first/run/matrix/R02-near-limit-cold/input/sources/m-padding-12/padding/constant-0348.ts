export const padding348 = 1;
