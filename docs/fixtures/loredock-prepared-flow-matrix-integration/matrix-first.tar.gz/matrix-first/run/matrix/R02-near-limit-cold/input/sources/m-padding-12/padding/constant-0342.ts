export const padding342 = 1;
