export const padding425 = 1;
