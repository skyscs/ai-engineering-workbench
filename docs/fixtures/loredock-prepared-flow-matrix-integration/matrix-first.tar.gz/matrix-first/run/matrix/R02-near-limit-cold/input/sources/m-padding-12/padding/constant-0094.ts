export const padding94 = 1;
