export const padding45 = 1;
