export const padding76 = 1;
