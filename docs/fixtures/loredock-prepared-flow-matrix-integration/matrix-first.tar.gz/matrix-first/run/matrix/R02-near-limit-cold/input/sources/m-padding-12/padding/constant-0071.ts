export const padding71 = 1;
