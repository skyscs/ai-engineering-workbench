export const padding172 = 1;
