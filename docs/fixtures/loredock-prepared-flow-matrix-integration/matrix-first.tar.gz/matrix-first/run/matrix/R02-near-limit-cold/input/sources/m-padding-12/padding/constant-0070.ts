export const padding70 = 1;
