export const padding466 = 1;
