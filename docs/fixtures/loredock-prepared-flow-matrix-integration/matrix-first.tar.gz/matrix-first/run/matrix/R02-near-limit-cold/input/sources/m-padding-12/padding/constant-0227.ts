export const padding227 = 1;
