export const padding73 = 1;
