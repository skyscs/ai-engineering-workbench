export const padding105 = 1;
