export const padding393 = 1;
