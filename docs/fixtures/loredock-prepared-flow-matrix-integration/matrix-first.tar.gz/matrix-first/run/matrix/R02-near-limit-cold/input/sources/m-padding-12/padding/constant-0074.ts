export const padding74 = 1;
