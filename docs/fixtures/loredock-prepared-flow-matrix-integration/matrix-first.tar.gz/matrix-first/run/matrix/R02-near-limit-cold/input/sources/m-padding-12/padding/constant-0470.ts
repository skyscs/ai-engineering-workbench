export const padding470 = 1;
