export const padding77 = 1;
