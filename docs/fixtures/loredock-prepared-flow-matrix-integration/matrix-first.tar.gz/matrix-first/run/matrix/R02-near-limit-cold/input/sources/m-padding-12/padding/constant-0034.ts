export const padding34 = 1;
