export const padding12 = 1;
