export const padding47 = 1;
