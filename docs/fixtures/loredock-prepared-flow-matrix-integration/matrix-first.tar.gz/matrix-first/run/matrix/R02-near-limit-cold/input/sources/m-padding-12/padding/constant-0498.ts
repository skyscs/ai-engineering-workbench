export const padding498 = 1;
