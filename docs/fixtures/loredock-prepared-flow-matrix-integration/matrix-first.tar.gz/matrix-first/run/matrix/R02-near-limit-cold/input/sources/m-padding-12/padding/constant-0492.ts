export const padding492 = 1;
