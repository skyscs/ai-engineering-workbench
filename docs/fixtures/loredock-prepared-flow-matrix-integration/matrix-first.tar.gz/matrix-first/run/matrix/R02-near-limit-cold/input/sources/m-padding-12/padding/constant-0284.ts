export const padding284 = 1;
