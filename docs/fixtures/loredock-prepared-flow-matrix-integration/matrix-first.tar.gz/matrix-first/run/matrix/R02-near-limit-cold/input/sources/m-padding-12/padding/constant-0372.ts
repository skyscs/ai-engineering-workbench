export const padding372 = 1;
