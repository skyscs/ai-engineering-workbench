export const padding320 = 1;
