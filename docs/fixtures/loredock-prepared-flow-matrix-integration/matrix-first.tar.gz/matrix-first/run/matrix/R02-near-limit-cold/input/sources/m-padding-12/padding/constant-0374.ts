export const padding374 = 1;
