export const padding210 = 1;
