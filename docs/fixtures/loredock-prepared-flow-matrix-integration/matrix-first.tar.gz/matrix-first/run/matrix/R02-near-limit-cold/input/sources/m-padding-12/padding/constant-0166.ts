export const padding166 = 1;
