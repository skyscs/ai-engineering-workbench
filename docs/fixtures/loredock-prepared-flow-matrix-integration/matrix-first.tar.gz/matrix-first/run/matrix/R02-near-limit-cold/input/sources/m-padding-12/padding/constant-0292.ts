export const padding292 = 1;
