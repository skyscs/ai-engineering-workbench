export const padding107 = 1;
