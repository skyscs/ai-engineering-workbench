export const padding476 = 1;
