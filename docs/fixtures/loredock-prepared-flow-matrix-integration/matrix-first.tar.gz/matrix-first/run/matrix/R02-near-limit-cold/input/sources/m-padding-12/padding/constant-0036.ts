export const padding36 = 1;
