export const padding344 = 1;
