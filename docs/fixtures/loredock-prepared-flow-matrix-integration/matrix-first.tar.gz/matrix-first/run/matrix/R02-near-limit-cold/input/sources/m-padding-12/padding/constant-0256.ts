export const padding256 = 1;
