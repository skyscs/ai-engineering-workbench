export const padding187 = 1;
