export const padding120 = 1;
