export const padding206 = 1;
