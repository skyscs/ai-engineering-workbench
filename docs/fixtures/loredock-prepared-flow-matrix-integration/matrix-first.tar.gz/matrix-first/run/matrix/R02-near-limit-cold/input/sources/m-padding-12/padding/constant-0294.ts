export const padding294 = 1;
