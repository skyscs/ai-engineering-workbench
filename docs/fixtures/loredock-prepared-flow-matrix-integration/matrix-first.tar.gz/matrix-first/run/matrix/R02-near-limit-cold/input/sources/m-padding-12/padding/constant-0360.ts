export const padding360 = 1;
