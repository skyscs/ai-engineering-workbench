export const padding27 = 1;
