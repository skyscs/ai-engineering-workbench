export const padding347 = 1;
