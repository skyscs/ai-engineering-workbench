export const padding32 = 1;
