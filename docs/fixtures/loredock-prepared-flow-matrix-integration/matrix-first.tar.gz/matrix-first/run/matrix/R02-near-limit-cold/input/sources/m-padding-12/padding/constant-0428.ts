export const padding428 = 1;
