export const padding52 = 1;
