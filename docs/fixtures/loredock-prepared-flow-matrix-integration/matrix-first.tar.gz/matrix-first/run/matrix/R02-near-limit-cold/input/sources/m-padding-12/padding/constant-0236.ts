export const padding236 = 1;
