import assert from 'node:assert/strict';
import { mkdir, writeFile } from 'node:fs/promises';
import { assessRecordedOwner } from './worktrees/task128-matrix-integration/scripts/loredock-prepared-flow/resource-assess.mjs';

const output='/home/toshiba/aew/task128-matrix-integration-owner-assessment';
await mkdir(output);
const result=await assessRecordedOwner('/home/toshiba/aew/task128-matrix-first');
assert.equal(result.resourceQualification,false);
assert.equal(result.modelEligibility,false);
await writeFile(output+'/result.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({status:result.status,checks:result.checks.length,failures:result.failures,
  failedChecks:result.checks.filter(row=>!row.passed),incomplete:result.incomplete,
  observed:result.observed,finalInventoryEntries:Object.keys(result.finalInventory).length},null,2));
