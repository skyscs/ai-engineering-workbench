from pathlib import Path
import hashlib
import json
import os
import shutil
import sqlite3
import subprocess

base=Path('/home/toshiba/aew');root=base/'task128-matrix-first';run=root/'run';repo=base/'worktrees/task128-matrix-integration'
output=base/'task128-matrix-integration-retention';output.mkdir()
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def read(file):return json.loads(file.read_text())
def inventory(directory):
    result={}
    for parent,dirs,files in os.walk(directory,followlinks=False):
        for name in sorted(dirs+files):
            file=Path(parent)/name;relative=str(file.relative_to(directory))
            if file.is_symlink():result[relative]={'target':os.readlink(file)}
            elif file.is_file():
                raw=file.read_bytes();result[relative]={'bytes':len(raw),'sha256':sha(raw)}
    return result
before=inventory(root);owner=read(root/'result.json');driver=read(run/'result.json');plan=read(run/'plan.json');matrix=read(run/'matrix/result.json')
assert owner['reason']=='driver-failure' and owner['driverExit']['exit']==1 and owner['errors']==[] and owner['survivors']==[]
assert driver['errors']==[] and driver['matrix']==matrix and matrix['allCasesPassed'] is False and matrix['modelEligibility'] is False
protocol=read(repo/'fixtures/loredock-prepared-flow/protocol.json');order=[row['id'] for row in protocol['resourceCases']]
assert [row['id'] for row in matrix['cases']]==order and matrix['errors']==[]
claim=read(Path(plan['claimPath']));assert claim['directory']==str(run/'matrix') and claim['family']==plan['family']
assert owner['catalogRoots']==plan['catalogRoots'] and len(owner['catalogRoots'])==63
report={'resourceQualification':False,'modelCalls':0,'reservedFamilyReads':0,'cases':[], 'catalogs':[], 'sourceGitIdentities':0,
        'sourceFiles':0,'httpResponses':0,'httpFailures':0,'redactedSessions':0,'browserBodies':0,'browserSessions':0,'controlledCalls':0}
for row in matrix['cases']:
    for artifact in row.get('artifacts',[]):
        raw=(run/'matrix'/row['id']/artifact['path']).read_bytes();assert len(raw)==artifact['bytes'] and sha(raw)==artifact['sha256']
    report['cases'].append({'id':row['id'],'status':row['status'],'details':row.get('details'),'reason':row.get('reason')})
events=[json.loads(line) for line in (run/'matrix/sequence.jsonl').read_text().splitlines()]
assert events[0]['event']=='started' and events[-1]['event']=='finished'
assert [row['id'] for row in events if row['event']=='case-finished']==order
started=[row['id'] for row in events if row['event']=='case-started'];assert len(started)==len(set(started))
env={**os.environ,'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null','GIT_OPTIONAL_LOCKS':'0'}
for file in run.rglob('sources.json'):
    sources=read(file)
    for name,identity in sources['revisions'].items():
        directory=Path(next(p for p in sources['paths'] if Path(p).name==name));assert directory.is_relative_to(root)
        for key,ref in [('revision','HEAD'),('tree','HEAD^{tree}')]:
            assert subprocess.check_output(['git','-c','core.hooksPath=/dev/null','-c','core.fsmonitor=false','rev-parse',ref],cwd=directory,env=env,text=True).strip()==identity[key]
        assert not subprocess.check_output(['git','-c','core.hooksPath=/dev/null','-c','core.fsmonitor=false','status','--porcelain'],cwd=directory,env=env)
        report['sourceGitIdentities']+=1
    for original in sources['originals']:
        directory=Path(next(p for p in sources['paths'] if Path(p).name==original['source']));raw=(directory/original['path']).read_bytes()
        assert len(raw)==original['bytes'] and sha(raw)==original['sha256'];report['sourceFiles']+=1
for file in run.rglob('requests.jsonl'):
    requests={};responses=set()
    for row in map(json.loads,file.read_text().splitlines()):
        key=row['id']
        if row['event']=='request':assert key not in requests;requests[key]=row
        elif row['event']=='failure':report['httpFailures']+=1
        else:
            assert row['event']=='response' and key in requests and key not in responses;responses.add(key)
            raw=(file.parent/(key+'.json')).read_bytes()
            if requests[key]['route']=='/session':assert json.loads(raw)['token']=='[removed-session-token]';report['redactedSessions']+=1
            else:assert len(raw)==row['bytes']
            report['httpResponses']+=1
for file in run.rglob('events.jsonl'):
    if file.parent.name!='browser':continue
    for row in map(json.loads,file.read_text().splitlines()):
        if row['event']!='api-body':continue
        raw=(file.parent/row['file']).read_bytes();assert len(raw)==row['retainedBytes'] and sha(raw)==row['retainedSha256']
        assert row['file']=='raw-response-'+sha(row['requestId'].encode())+'.json'
        if row['redacted']:
            assert row['url']=='http://127.0.0.1:4244/api/session' and row['rawSha256'] is None and json.loads(raw)['token']=='[removed-session-token]';report['browserSessions']+=1
        else:assert len(raw)==row['bytes'] and sha(raw)==row['rawSha256']
        report['browserBodies']+=1
for file in run.rglob('runtime-stats.json'):
    stats=read(file);assert stats['closed']==stats['prepares'];report['controlledCalls']+=stats['calls']
for original in sorted(run.rglob('loredock.db')):
    relative=original.parent.relative_to(root);assert str(relative) in plan['catalogRoots']
    copied=output/relative;copied.parent.mkdir(parents=True,exist_ok=True);shutil.copytree(original.parent,copied)
    assert inventory(original.parent)==inventory(copied)
    db=sqlite3.connect('file:'+str(copied/'loredock.db')+'?mode=ro',uri=True)
    try:
        assert db.execute('PRAGMA integrity_check').fetchall()==[('ok',)] and db.execute('PRAGMA foreign_key_check').fetchall()==[]
        rows=db.execute('SELECT w.answerId,w.purged,w.contextHash,w.witness,w.witnessBytes,a.context FROM answer_witnesses w JOIN answer_attempts a ON a.id=w.answerId ORDER BY w.answerId').fetchall()
        for answer,purged,context_hash,witness,witness_bytes,context in rows:
            if purged:assert witness is None and context is None and witness_bytes==0
            else:assert sha(context.encode())==context_hash and len(witness.encode())==witness_bytes
        report['catalogs'].append({'source':str(original.parent),'copy':str(copied),'integrity':'ok','foreignKeyErrors':[],
            'rows':len(rows),'purged':sum(row[1] for row in rows),'witnessBytes':sum(row[4] for row in rows),
            'answerStates':db.execute('SELECT status,count(*) FROM answer_attempts GROUP BY status').fetchall()})
    finally:db.close()
assert inventory(root)==before
report.update(rawInputsUnchanged=True,entries=len(before),caseStarts=len(started),declaredCatalogRoots=63,
    observedCatalogRoots=len(owner['observedCatalogRoots']),ownerElapsedMs=owner['elapsedMs'],ownerPeakBytes=owner['peakSampledStorageBytes'])
(output/'claim-copy.json').write_text(json.dumps(claim,indent=2)+'\n')
(output/'result.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({**report,'catalogs':len(report['catalogs'])},indent=2))
