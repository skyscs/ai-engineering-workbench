from pathlib import Path
import json

base=Path('/home/toshiba/aew');helper=base/'task128-kernel-archive.py'
exec(helper.read_text().split("for name in ['core', 'browser', 'crash', 'interruption']:")[0])
repo=base/'worktrees/task128-matrix-integration';out=repo/'docs/fixtures/loredock-prepared-flow-matrix-integration'
assert out.is_dir() and not (out/'records.json').exists()
records={'schemaVersion':'prepared-flow-matrix-integration-development/1','resourceQualification':False,'modelCalls':0,
         'reservedFamilyReads':0,'trees':[],'logs':[], 'base':'c14f06177e0d0602cf52a5c016f486dd2659802f'}
for name in ['matrix-first','matrix-first-inputs','matrix-integration-retention','matrix-integration-owner-assessment']:
    tree(name,base/('task128-'+name))
for name in ['matrix-first','matrix-install','matrix-build','matrix-tests-first','matrix-seal-first','matrix-integration-retention','matrix-integration-owner-assessment']:
    log(name,base/('task128-'+name+'.log'))
inputs=base/'task128-matrix-integration-inputs';inputs.mkdir()
for source in sorted((repo/'scripts/loredock-prepared-flow').glob('*')):
    if source.is_file() and source.suffix in ['.py','.mjs']:(inputs/source.name).write_bytes(source.read_bytes())
for source in [repo/'scripts/tests/loredock-matrix-plan.test.mjs',repo/'scripts/tests/loredock-flow-coordinator.test.mjs',
               helper,base/'task128-matrix-integration-retention.py',base/'task128-matrix-integration-owner-assessment.mjs',
               base/'task128-matrix-roots-first.json',base/'task128-matrix-first.claim.json',Path(__file__)]:
    (inputs/source.name).write_bytes(source.read_bytes())
tree('matrix-integration-inputs',inputs)
records['retention']=json.loads((base/'task128-matrix-integration-retention/result.json').read_text())
(out/'records.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps({'trees':len(records['trees']),'logs':len(records['logs'])},indent=2))
