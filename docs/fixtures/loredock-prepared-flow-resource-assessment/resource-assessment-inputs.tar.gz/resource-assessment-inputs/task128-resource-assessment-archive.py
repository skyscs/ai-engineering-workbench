from pathlib import Path
import json
import re

base=Path('/home/toshiba/aew');helper=base/'task128-kernel-archive.py'
exec(helper.read_text().split("for name in ['core', 'browser', 'crash', 'interruption']:")[0])
repo=base/'worktrees/task128-resource-assessment';out=repo/'docs/fixtures/loredock-prepared-flow-resource-assessment';out.mkdir(exist_ok=True)
accepted=json.loads((base/'task128-integration-handoff.json').read_text())['latestAccepted'];assert accepted['pr']==152 and accepted['testsPerEvent']==990
records={'schemaVersion':'prepared-flow-resource-assessment-development/1','resourceQualification':False,'modelCalls':0,'reservedFamilyReads':0,'trees':[],'logs':[],'acceptedBrowserMeasurements':accepted}
for name in ['resource-assessment-first','resource-assessment-check','resource-assessment-retention']:tree(name,base/('task128-'+name))
history=base/'task128-ordered-history-second/run'
for name,source in [('sources',history/'sources'),('checkpoint-20',history/'capacity/checkpoint-20'),('checkpoint-64',history/'capacity/checkpoint-64')]:tree('resource-assessment-reused-'+name,source)
for name in ['resource-assessment-first','resource-assessment-check','resource-assessment-install','resource-assessment-build','resource-assessment-owner-tests-first','resource-assessment-tests-first','resource-assessment-browser-tests','resource-assessment-retention','resource-assessment-seal-check','browser-measurements-ci-push','browser-measurements-ci-pr']:log(name,base/('task128-'+name+'.log'))
for kind in ['owner-tests-first','browser-tests']:
    text=(base/('task128-resource-assessment-'+kind+'.log')).read_text()
    locations=re.findall(r'Retained (?:kernel-owner|catalog-declaration|browser-lifetime) test: (/tmp/[A-Za-z0-9-]+)',text)
    for i,location in enumerate(locations):tree('resource-assessment-'+kind+'-'+str(i+1),Path(location))
inputs=base/'task128-resource-assessment-inputs';inputs.mkdir()
for source in [repo/'scripts/loredock-prepared-flow'/name for name in ['kernel-owner.py','resource-assess.mjs','resource-assessment-development.mjs']]+[
    repo/'scripts/tests/loredock-kernel-owner.test.mjs',repo/'scripts/tests/loredock-resource-assessment.test.mjs',repo/'scripts/tests/loredock-browser-lifetime.test.mjs',helper,
    base/'task128-resource-assessment-check.mjs',base/'task128-resource-assessment-retention.py',repo/'docs/fixtures/loredock-prepared-flow-history/ordered-history-second.inventory.json.gz',Path(__file__)]:
    (inputs/source.name).write_bytes(source.read_bytes())
tree('resource-assessment-inputs',inputs)
records['retention']=json.loads((base/'task128-resource-assessment-retention/result.json').read_text())
(out/'records.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps({'trees':len(records['trees']),'logs':len(records['logs'])},indent=2))
