import assert from 'node:assert/strict';
import { mkdir } from 'node:fs/promises';
import { assessRecordedOwner } from './worktrees/task128-resource-assessment/scripts/loredock-prepared-flow/resource-assess.mjs';
import { inventory, save } from './worktrees/task128-resource-assessment/scripts/loredock-prepared-flow/io.mjs';
const root = '/home/toshiba/aew/task128-resource-assessment-first';
const output = '/home/toshiba/aew/task128-resource-assessment-check';
await mkdir(output);
const before = await inventory(root);
const assessment = await assessRecordedOwner(root);
await save(output + '/result.json', assessment);
assert.deepEqual(await inventory(root), before);
assert.equal(assessment.status, 'passed');
assert.equal(assessment.resourceQualification, false);
console.log(JSON.stringify({ status: assessment.status, checks: assessment.checks, incomplete: assessment.incomplete,
  observed: assessment.observed, finalFiles: Object.keys(assessment.finalInventory).length, inputUnchanged: true, resourceQualification: false }, null, 2));
