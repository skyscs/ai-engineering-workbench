from pathlib import Path
import json
import shutil

base=Path('/home/toshiba/aew');helper=base/'task128-kernel-archive.py'
exec(helper.read_text().split("for name in ['core', 'browser', 'crash', 'interruption']:")[0])
repo=base/'worktrees/task128-browser-fences';out=repo/'docs/fixtures/loredock-prepared-flow-browser-fences';out.mkdir(exist_ok=True)
accepted=json.loads((base/'task128-integration-handoff.json').read_text())['latestAccepted']
assert accepted['pr']==145 and accepted['testsPerEvent']==982
records={'schemaVersion':'prepared-flow-browser-fences-development/1','resourceQualification':False,
         'modelCalls':0,'reservedFamilyReads':0,'trees':[],'logs':[],'acceptedNetworkCases':accepted,'screenshots':[]}
tree('browser-fences-first',base/'task128-browser-fences-first')
tree('browser-fences-retention',base/'task128-browser-fences-retention')
prior=base/'task128-network-cases-first/run'
for name,source in [('sources',prior/'sources'),('cold-checkpoint',prior/'base/checkpoint'),
                    ('history-checkpoint',prior/'lost-admission/history-checkpoint')]:
    tree('browser-fences-reused-'+name,source)
for name in ['browser-fences-first','browser-fences-install','browser-fences-build',
             'browser-fences-retention','browser-fences-seal-check','network-cases-ci-push','network-cases-ci-pr']:
    log(name,base/('task128-'+name+'.log'))
inputs=base/'task128-browser-fences-inputs';inputs.mkdir()
for source in [repo/'scripts/loredock-prepared-flow/network-cases.mjs',repo/'scripts/loredock-prepared-flow/browser-fence-cases.mjs',
               repo/'scripts/loredock-prepared-flow/browser-fences-development.mjs',
               helper,base/'task128-browser-fences-retention.py',
               prior/'sources.json',prior/'lost-admission/controlled/request-1.json',
               base/'worktrees/task128-network-cases/docs/fixtures/loredock-prepared-flow-network-cases/network-cases-first.inventory.json.gz',Path(__file__)]:
    (inputs/source.name).write_bytes(source.read_bytes())
tree('browser-fences-inputs',inputs)
for case,name in [('preparation-review','review-context-hidden'),('history-review','historical-review-labelled'),('history-revoke','revoked-content-hidden')]:
    source=base/'task128-browser-fences-first/run'/case/'browser'/(name+'.png');raw=source.read_bytes();target=out/source.name
    with target.open('xb') as file:file.write(raw)
    records['screenshots'].append({'path':target.name,'source':str(source),'bytes':len(raw),'sha256':sha(raw)})
records['retention']=json.loads((base/'task128-browser-fences-retention/result.json').read_text())
(out/'records.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps({'trees':len(records['trees']),'logs':len(records['logs']),'screenshots':len(records['screenshots'])},indent=2))
