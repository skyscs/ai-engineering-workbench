from pathlib import Path
import gzip
import hashlib
import json
import shutil
import sqlite3

base=Path('/home/toshiba/aew');root=base/'task128-browser-fences-first';run=root/'run'
prior=base/'task128-network-cases-first/run';output=base/'task128-browser-fences-retention';output.mkdir()
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def read(file):return json.loads(file.read_text())
def inventory(directory):
    result={}
    for p in sorted(directory.rglob('*')):
        if p.is_symlink():result[str(p.relative_to(directory))]={'kind':'symlink','target':str(p.readlink())}
        elif p.is_file():result[str(p.relative_to(directory))]={'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}
    return result
before=inventory(root);owner=read(root/'result.json');driver=read(run/'result.json');inputs=read(run/'inputs.json')
assert owner['reason']=='completed' and owner['driverExit']['exit']==0 and owner['errors']==[] and owner['survivors']==[]
assert driver['errors']==[] and [x['id'] for x in driver['cases']]==['preparation-review','history-review','history-revoke']
report={'resourceQualification':False,'modelCalls':0,'reservedFamilyReads':0,'catalogs':[],'browsers':[],'httpBodies':0,'redactedSessions':0}
# Bind reused ordinary inputs to the preceding committed archive, not only their new descriptors.
archived=json.loads(gzip.decompress((base/'worktrees/task128-network-cases/docs/fixtures/loredock-prepared-flow-network-cases/network-cases-first.inventory.json.gz').read_bytes()))
selected=['sources/','base/checkpoint/','lost-admission/history-checkpoint/']
bound=0
for name,info in archived.items():
    if any(name.startswith('run/'+prefix) for prefix in selected):
        raw=(prior.parent/name).read_bytes();assert len(raw)==info['bytes'] and sha(raw)==info['sha256'];bound+=1
for checkpoint in [inputs['base'],inputs['history']]:assert inventory(Path(checkpoint['data']))==checkpoint['files']
report['reusedInputFilesBoundToPreviousArchive']=bound
for requests in run.rglob('requests.jsonl'):
    pending={};responses=set()
    for line in requests.read_text().splitlines():
        row=json.loads(line);key=row['id'];assert row['event']!='failure'
        if row['event']=='request':assert key not in pending;pending[key]=row
        if row['event']=='response':
            assert key in pending and key not in responses;responses.add(key)
            raw=(requests.parent/(key+'.json')).read_bytes()
            if pending[key]['route']=='/session':assert json.loads(raw)['token']=='[removed-session-token]';report['redactedSessions']+=1
            else:assert len(raw)==row['bytes'];report['httpBodies']+=1
    assert set(pending)==responses
for case in driver['cases']:
    name=case['id'];value=case['value'];directory=run/name
    assert value['errors']==[] and value['inputCheckpointUnchanged'] is True and value['timingQualified'] is False
    assert value['runtime']=={'prepares':0,'calls':0,'closed':0} and value['lateResponseCompleted'] is True
    assert read(directory/'controlled/process.json')['fault'] is True
    events=[json.loads(line)['value'] for line in (directory/'browser/events.jsonl').read_text().splitlines() if json.loads(line)['event']=='protocol']
    requests={};completed=[];preparations=0;admissions=0
    for event in events:
        params=event['params']
        if event['method']=='Network.requestWillBeSent':
            request=params['request'];requests[params['requestId']]=request
            preparations+=request['method']=='POST' and request['url'].endswith('/api/question-preparations')
            admissions+=request['method']=='POST' and request['url'].endswith('/api/prepared-answers')
        if event['method'] in ['Network.loadingFinished','Network.loadingFailed']:
            request=requests.get(params['requestId'],{})
            if request.get('url','').startswith('http://127.0.0.1:4244/api/'):
                assert event['method']=='Network.loadingFinished'
                body=read(directory/'browser'/('response-'+params['requestId'].replace('.','-')+'.json'))
                if request['url'].endswith('/api/session'):assert body['token']=='[removed-session-material]'
                completed.append(params['requestId'])
    assert value['networkId'] in completed and admissions==0
    assert preparations==int(name=='preparation-review')
    if name=='preparation-review':
        assert value['dom']=={'contextPresent':False,'generatePresent':False,'contextInsertions':0}
        assert value['preparation']['value']['status']=='cancelled'
    if name=='history-review':
        assert value['saved']['value']['reviewState']=='changed'
        for key in ['context','nativeContext','answer','usage']:assert value['saved']['value'][key]==inputs['history']['saved']['value'][key]
    if name=='history-revoke':
        assert value['dom']=={'contentPresent':False,'contentInsertions':0}
        assert value['saved']['value']['status']=='fenced'
        for key in ['context','nativeContext','answer']:assert value['saved']['value'][key] is None
        assert not any(x['sourceName']==inputs['sourceName'] for x in inputs['history']['saved']['value']['context']['spans'])
    samples=[json.loads(line) for line in (directory/'browser/process-tree.jsonl').read_text().splitlines()]
    assert max(x['rssBytes'] for x in samples)==value['browser']['maxRssBytes']
    assert sum(not x['complete'] for x in samples)==value['browser']['incompleteMemorySamples']
    report['browsers'].append({'name':name,'completedApiBodies':len(completed),'preparations':preparations,'admissions':admissions,
        'sampledRssBytes':value['browser']['maxRssBytes'],'incompleteSamples':value['browser']['incompleteMemorySamples']})
    original=directory/'data';copied=output/name/'data';copied.parent.mkdir();shutil.copytree(original,copied)
    assert inventory(original)==inventory(copied)
    db=sqlite3.connect('file:'+str(copied/'loredock.db')+'?mode=ro',uri=True)
    try:
        assert db.execute('PRAGMA integrity_check').fetchall()==[('ok',)] and db.execute('PRAGMA foreign_key_check').fetchall()==[]
        states=db.execute('SELECT status,count(*) FROM answer_attempts GROUP BY status').fetchall()
        witnesses=db.execute('SELECT witness,witnessBytes,purged FROM answer_witnesses').fetchall()
        corrections=db.execute('SELECT count(*) FROM corrections').fetchone()[0]
        if name=='preparation-review':assert states==[] and witnesses==[] and corrections==1
        if name=='history-review':
            assert states==[('succeeded',1)] and corrections==1
            witness,size,purged=witnesses[0];assert purged==0 and len(witness.encode())==size
            request=read(prior/'lost-admission/controlled/request-1.json')
            assert json.loads(witness)['prompt']==request['prompt']
            assert json.loads(witness)['compact']==inputs['history']['saved']['value']['nativeContext']
        if name=='history-revoke':
            assert states==[('fenced',1)] and witnesses==[(None,0,1)] and corrections==0
            assert db.execute('SELECT context,result FROM answer_attempts').fetchall()==[(None,None)]
            assert db.execute('SELECT status FROM sources WHERE name=?',(inputs['sourceName'],)).fetchall()==[('revoked',)]
        report['catalogs'].append({'source':str(original),'copy':str(copied),'integrity':'ok','foreignKeyErrors':[],'answerStates':states,'corrections':corrections})
    finally:db.close()
assert inventory(root)==before
for checkpoint in [inputs['base'],inputs['history']]:assert inventory(Path(checkpoint['data']))==checkpoint['files']
report.update(rawInputsUnchanged=True,entries=len(before))
(output/'result.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
