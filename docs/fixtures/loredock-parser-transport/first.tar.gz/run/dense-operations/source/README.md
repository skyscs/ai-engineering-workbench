# Parser compatibility control

Synthetic HTTP functions for transport compatibility.
