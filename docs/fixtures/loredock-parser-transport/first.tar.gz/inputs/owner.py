from pathlib import Path
import hashlib, json, os, resource, signal, subprocess, time

repo = Path('/home/toshiba/aew/worktrees/task138-production-parser')
root = Path('/home/toshiba/aew/task138-transport-first')
root.mkdir()  # Exclusive immutable first attempt.
node = Path('/home/toshiba/aew/toolchain/node-v22.23.2-linux-x64/bin/node')
inputs = root / 'inputs'
inputs.mkdir()
files = []
for directory in ['apps/loredock/src', 'apps/loredock/dist', 'apps/loredock/runtime', 'scripts/loredock-production-parser']:
    for source in sorted((repo / directory).rglob('*')):
        if not source.is_file(): continue
        name = str(source.relative_to(repo)); raw = source.read_bytes()
        target = inputs / name; target.parent.mkdir(parents=True, exist_ok=True); target.write_bytes(raw)
        files.append({'path': name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
owner = Path(__file__).read_bytes(); (inputs / 'owner.py').write_bytes(owner)
assert not subprocess.check_output(['git', 'status', '--porcelain=v1'], cwd=repo)
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
command = [str(node), 'scripts/loredock-production-parser/transport.mjs', str(root / 'run')]
(root / 'execution.json').write_text(json.dumps({'head': head, 'command': command, 'cwd': str(repo),
    'nodeSha256': hashlib.sha256(node.read_bytes()).hexdigest(), 'files': files,
    'ownerSha256': hashlib.sha256(owner).hexdigest(), 'resourceQualification': False, 'modelCalls': 0}, indent=2) + '\n')
env = os.environ.copy()
env['PATH'] = str(node.parent) + ':/home/toshiba/node-v18.20.2-linux-x64/bin:/usr/bin:/bin'
started = time.monotonic(); timed_out = False
before = resource.getrusage(resource.RUSAGE_CHILDREN)
with (root / 'stdout.log').open('xb') as stdout, (root / 'stderr.log').open('xb') as stderr:
    child = subprocess.Popen(command, cwd=repo, env=env, stdout=stdout, stderr=stderr, start_new_session=True)
    try: code = child.wait(timeout=60)
    except subprocess.TimeoutExpired:
        timed_out = True; os.killpg(child.pid, signal.SIGTERM)
        try: code = child.wait(timeout=10)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid, signal.SIGKILL); code = child.wait()
after = resource.getrusage(resource.RUSAGE_CHILDREN)
for entry in files:
    assert hashlib.sha256((repo / entry['path']).read_bytes()).hexdigest() == entry['sha256']
result = {'exitCode': code, 'timedOut': timed_out, 'wallMs': (time.monotonic()-started)*1000,
    'childUserSeconds': after.ru_utime-before.ru_utime, 'childSystemSeconds': after.ru_stime-before.ru_stime,
    'childHighWaterRssKiB': after.ru_maxrss,
    'observer': 'Complete child exit and kernel CPU/high-water diagnostics only; no interval, startup or aggregate heap qualification.'}
(root / 'owner.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
