from pathlib import Path
import json
import re

base = Path('/home/toshiba/aew'); helper = base / 'task128-kernel-archive.py'
exec(helper.read_text().split("for name in ['core', 'browser', 'crash', 'interruption']:")[0])
repo = base / 'worktrees/task128-flow-coordinator'
out = repo / 'docs/fixtures/loredock-prepared-flow-coordinator'
out.mkdir(exist_ok=True)
records = {'schemaVersion': 'prepared-flow-coordinator-development/1', 'resourceQualification': False,
           'modelCalls': 0, 'reservedFamilyReads': 0, 'tests': 970, 'trees': [], 'logs': [],
           'acceptedLifetime': {'pr': 139, 'head': '288aad65b827641cf0ee5709069aa7d2670a69e9',
              'merge': 'c86041dc0b9be5889479436f29d4ecb7e3aa8f2b',
              'push': 42011188758, 'pull_request': 42011219339, 'testsPerEvent': 962}}
for name in ['coordinator-install', 'coordinator-build', 'coordinator-focused-first', 'coordinator-focused-second',
             'coordinator-focused-final', 'coordinator-focused-reviewed', 'coordinator-check-first',
             'coordinator-check-reviewed', 'coordinator-seal-check', 'coordinator-retention',
             'lifetime-ci-push', 'lifetime-ci-pr']:
    raw = log(name, base / ('task128-' + name + '.log'))
    for kind, pattern in [('sequence', r'Retained flow-coordinator test: (/tmp/loredock-flow-coordinator-[A-Za-z0-9]+)'),
                          ('lifetime', r'Retained browser-lifetime test: (/tmp/loredock-browser-lifetime-[A-Za-z0-9]+)'),
                          ('owner', r'Retained kernel-owner test: (/tmp/loredock-kernel-(?:adoption|owner)-[A-Za-z0-9]+)'),
                          ('checkpoint', r'Retained history-checkpoint test: (/tmp/loredock-history-checkpoint-[A-Za-z0-9]+)')]:
        if name.startswith('lifetime-ci-'):
            continue  # Remote CI temporary directories are not local artifacts.
        for index, location in enumerate(re.findall(pattern, raw)):
            tree(name + '-' + kind + '-' + str(index + 1), Path(location),
                 'Earlier ordinary control revision; no executable seal or qualification. Earliest focused revisions have logs and outputs but no exact source snapshot.' if name.endswith(('first', 'second')) else None)
tree('coordinator-retention', base / 'task128-coordinator-retention')
tree('coordinator-first-inputs', base / 'task128-coordinator-first-inputs')
inputs = base / 'task128-coordinator-inputs'; inputs.mkdir()
for source in [repo / 'scripts/loredock-prepared-flow/coordinator.mjs', repo / 'scripts/loredock-prepared-flow/io.mjs',
               repo / 'scripts/tests/loredock-flow-coordinator.test.mjs', helper, base / 'task128-coordinator-retention.py', Path(__file__)]:
    (inputs / source.name).write_bytes(source.read_bytes())
tree('coordinator-inputs', inputs)
records['retention'] = json.loads((base / 'task128-coordinator-retention/result.json').read_text())
(out / 'records.json').write_text(json.dumps(records, indent=2) + '\n')
print(json.dumps({'trees': len(records['trees']), 'logs': len(records['logs']), 'tests': records['tests']}, indent=2))
