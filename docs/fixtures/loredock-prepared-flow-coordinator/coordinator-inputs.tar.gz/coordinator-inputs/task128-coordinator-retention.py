from pathlib import Path
import hashlib
import json
import re

base = Path('/home/toshiba/aew')
output = base / 'task128-coordinator-retention'
output.mkdir()
sha = lambda value: hashlib.sha256(value).hexdigest()
logs = sorted(base.glob('task128-coordinator-focused-*.log')) + [base / ('task128-coordinator-check-' + name + '.log') for name in ['first', 'reviewed']]
roots = sorted({Path(location) for log in logs for location in re.findall(r'Retained flow-coordinator test: (/tmp/loredock-flow-coordinator-[A-Za-z0-9]+)', log.read_text())})
assert roots
order = [row['id'] for row in json.loads((base / 'worktrees/task128-flow-coordinator/fixtures/loredock-prepared-flow/protocol.json').read_text())['resourceCases']]

def inventory(root):
    result = {}
    for file in sorted(root.rglob('*')):
        name = str(file.relative_to(root))
        if file.is_symlink():
            result[name] = {'symlink': str(file.readlink())}
        elif file.is_file():
            raw = file.read_bytes()
            result[name] = {'bytes': len(raw), 'sha256': sha(raw)}
    return result

report = {'schemaVersion': 'prepared-flow-coordinator-retention/1', 'resourceQualification': False,
          'modelCalls': 0, 'reservedFamilyReads': 0, 'roots': [], 'evidenceFiles': 0, 'abruptExits': 0}
for root in roots:
    before = inventory(root)
    journals = list(root.glob('*/sequence.jsonl'))
    # Two competing attempts may leave two directories, but only one owns the marker.
    assert len(journals) <= 1
    row = {'root': str(root), 'files': len(before), 'journals': []}
    marker = root / 'consumed.json'
    for journal in journals:
        claim = json.loads(marker.read_text())
        assert claim['family'] == 'ordinary-sequence-control'
        assert claim['directory'] == str(journal.parent)
        events = [json.loads(line) for line in journal.read_text().splitlines()]
        assert events[0]['event'] == 'started'
        assert events[0]['order'] == order
        started = [event['id'] for event in events if event['event'] == 'case-started']
        assert len(started) == len(set(started))
        assert started == [case for case in order if case in started]
        result_file = journal.parent / 'result.json'
        detail = {'path': str(journal.relative_to(root)), 'startedCases': started}
        if not result_file.exists():
            assert [event['event'] for event in events] == ['started', 'case-started']
            assert started == order[:1]
            report['abruptExits'] += 1
            detail['complete'] = False
        else:
            result = json.loads(result_file.read_text())
            assert result['qualification'] is False and result['modelEligibility'] is False
            assert result['errors'] == []
            assert [case['id'] for case in result['cases']] == order
            finished = [event for event in events if event['event'] == 'case-finished']
            assert [event['id'] for event in finished] == order
            assert events[-1]['event'] == 'finished'
            all_passed = all(case['status'] == 'passed' for case in result['cases'])
            assert result['allCasesPassed'] == events[-1]['allCasesPassed'] == all_passed
            for case, event in zip(result['cases'], finished):
                assert all(event[key] == value for key, value in case.items())
                if case['status'] == 'not-run':
                    assert case['id'] not in started
                    continue
                directory = journal.parent / case['id']
                assert json.loads((directory / 'coordinator-outcome.json').read_text()) == case
                for evidence in case.get('artifacts', []):
                    file = directory / evidence['path']
                    assert file.resolve() == file and file.is_file()
                    raw = file.read_bytes()
                    assert evidence['bytes'] == len(raw) and evidence['sha256'] == sha(raw)
                    report['evidenceFiles'] += 1
            detail.update(complete=True, allCasesPassed=all_passed)
        row['journals'].append(detail)
    assert inventory(root) == before
    row['unchanged'] = True
    report['roots'].append(row)
report['testRoots'] = len(roots)
assert report['abruptExits'] == len(logs)
(output / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({key: value for key, value in report.items() if key != 'roots'}, indent=2))
