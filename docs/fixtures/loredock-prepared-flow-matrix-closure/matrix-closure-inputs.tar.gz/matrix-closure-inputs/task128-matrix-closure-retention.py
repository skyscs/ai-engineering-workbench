from pathlib import Path
import hashlib
import json
import os
import shutil
import sqlite3

base=Path('/home/toshiba/aew');root=base/'task128-matrix-closure-first';run=root/'run'
output=base/'task128-matrix-closure-retention';output.mkdir()
sha=lambda raw:hashlib.sha256(raw).hexdigest()
read=lambda file:json.loads(file.read_text())
def inventory(directory):
    result={}
    for parent,dirs,files in os.walk(directory,followlinks=False):
        for name in sorted(dirs+files):
            p=Path(parent)/name;k=str(p.relative_to(directory))
            if p.is_symlink():
                target=os.readlink(p);result[k]={'kind':'symlink','target':target,'sha256':sha(target.encode())}
            elif p.is_file():
                raw=p.read_bytes();result[k]={'bytes':len(raw),'sha256':sha(raw)}
    return result
before=inventory(root);owner=read(root/'result.json');result=read(run/'result.json')
assert owner['reason']=='completed' and owner['driverExit']['exit']==0 and owner['errors']==[] and owner['survivors']==[]
assert result['errors']==[] and result['originalInputsUnchanged'] is True
for key in ['candidatePreparations','controlledCalls','modelCalls','reservedFamilyReads']:assert result[key]==0
assert result['resourceQualification'] is False and result['modelEligibility'] is False
assert result['content']['errors']==[] and result['content']['inputUnchanged'] is True
assert result['content']['assessment']['status']=='passed' and result['content']['assessment']['rows']==3
coverage=result['coverage'];assert len(coverage['bound'])==4 and len(coverage['unmatched'])==11
assert coverage['operationWorkComplete'] is False and coverage['privateBoundaryCoverageComplete'] is False and coverage['transientOwnershipProven'] is False
original=base/'task128-matrix-first';expected=read(run/'input-inventory.json')
assert inventory(original)==expected
matrix=read(original/'run/matrix/result.json');assert result['originalOutcomes']==[{'id':row['id'],'status':row['status']} for row in matrix['cases']]
assert result['originalResultSha256']==sha((original/'run/matrix/result.json').read_bytes())
assert result['lifetime']==read(original/'run/matrix/R15-accounting/representative-lifetime.json')
assert result['lifetime']['status']=='passed' and len(result['lifetime']['checks'])==16
assert result['lifetime']['diagnosticTimingUsed'] is False and result['lifetime']['exactPerOperationDurations'] is False
data=run/'content/data';copied=output/'catalog';shutil.copytree(data,copied);assert inventory(data)==inventory(copied)
db=sqlite3.connect('file:'+str(copied/'loredock.db')+'?mode=ro',uri=True)
try:
    assert db.execute('PRAGMA integrity_check').fetchall()==[('ok',)] and db.execute('PRAGMA foreign_key_check').fetchall()==[]
    rows=db.execute('SELECT w.answerId,w.reviewedHash,w.contextHash,w.witness,w.witnessBytes,a.context FROM answer_witnesses w JOIN answer_attempts a ON a.id=w.answerId WHERE w.purged=0 ORDER BY w.answerId').fetchall()
    assert len(rows)==3
    for answer,reviewed,context_hash,witness,witness_bytes,context in rows:
        assert sha(context.encode())==context_hash and len(witness.encode())==witness_bytes==66336
    for binding in result['content']['boundReviews']:
        assert binding['transientOwnershipProven'] is False and binding['resourceQualification'] is False
        if binding['name'] in coverage['bound']:
            assert binding['status']=='passed' and binding['contextAndWitnessIdentity'] is True
            assert binding['retainedAnswerIds']==[row[0] for row in rows]
            assert all(row[1]==binding['reviewedHash'] for row in rows)
            measured=binding['content']['measured'];assert measured=={'witnessRowBytes':66336,'retainedPreparationBytes':91335,
                'promptBytes':23232,'nativeAndLegacyDerivedBytes':7519,'sourceEvidenceBytes':2259,'sourceEvidenceSpans':11}
        else:assert binding['status']=='incomplete' and binding['content'] is None and binding['retainedAnswerIds']==[]
finally:db.close()
assert inventory(root)==before
report={'catalogIntegrity':'ok','foreignKeys':[],'catalogs':1,'witnessRows':3,'boundReviews':4,'unmatchedReviews':11,
    'lifetimeChecks':16,'originalMatrixEntries':len(expected),'closureEntries':len(before),'rawInputsUnchanged':True,
    'originalOutcomesUnchanged':True,'candidatePreparations':0,'controlledCalls':0,'modelCalls':0,'reservedFamilyReads':0,
    'resourceQualification':False,'modelEligibility':False}
(output/'result.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
