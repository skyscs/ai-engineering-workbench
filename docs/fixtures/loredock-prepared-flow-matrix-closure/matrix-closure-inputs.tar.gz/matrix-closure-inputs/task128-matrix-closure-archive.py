from pathlib import Path
import json

base=Path('/home/toshiba/aew');helper=base/'task128-kernel-archive.py'
exec(helper.read_text().split("for name in ['core', 'browser', 'crash', 'interruption']:")[0])
repo=base/'worktrees/task128-matrix-closure';out=repo/'docs/fixtures/loredock-prepared-flow-matrix-closure';out.mkdir(exist_ok=True)
accepted=json.loads((base/'task128-integration-handoff.json').read_text())['latestAccepted']
assert accepted['pr']==157 and accepted['testsPerEvent']==1012
records={'schemaVersion':'prepared-flow-matrix-closure-development/1','resourceQualification':False,'modelCalls':0,
         'reservedFamilyReads':0,'trees':[],'logs':[],'acceptedMatrixIntegration':accepted}
for name in ['matrix-closure-first','matrix-closure-first-inputs','matrix-closure-retention']:tree(name,base/('task128-'+name))
for name in ['matrix-closure-first','matrix-closure-tests-first','matrix-closure-install','matrix-closure-build','matrix-closure-seal','matrix-closure-retention','matrix-integration-ci-push','matrix-integration-ci-pr']:
    log(name,base/('task128-'+name+'.log'))
inputs=base/'task128-matrix-closure-inputs';inputs.mkdir()
for source in [repo/'scripts/loredock-prepared-flow'/name for name in ['content-assess.mjs','lifetime-assess.mjs','matrix-closure-development.mjs','io.mjs','kernel-owner.py']]+[
    repo/'scripts/tests/loredock-content-assessment.test.mjs',helper,base/'task128-matrix-closure-retention.py',Path(__file__)]:
    (inputs/source.name).write_bytes(source.read_bytes())
tree('matrix-closure-inputs',inputs)
records['retention']=json.loads((base/'task128-matrix-closure-retention/result.json').read_text())
(out/'records.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps({'trees':len(records['trees']),'logs':len(records['logs'])},indent=2))
