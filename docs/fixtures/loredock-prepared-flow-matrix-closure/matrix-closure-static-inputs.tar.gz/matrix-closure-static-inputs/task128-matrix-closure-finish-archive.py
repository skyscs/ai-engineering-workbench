from pathlib import Path
import json

base=Path('/home/toshiba/aew')
exec((base/'task128-kernel-archive.py').read_text().split("for name in ['core', 'browser', 'crash', 'interruption']:")[0])
out=base/'worktrees/task128-matrix-closure/docs/fixtures/loredock-prepared-flow-matrix-closure'
records=json.loads((out/'records.json').read_text())
inputs=base/'task128-matrix-closure-static-inputs';inputs.mkdir()
for source in [base/'task128-matrix-closure-static.py',Path(__file__)]:
    (inputs/source.name).write_bytes(source.read_bytes())
tree('matrix-closure-static-inputs',inputs)
log('matrix-closure-static-first',base/'task128-matrix-closure-static-first.log')
(out/'records.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps({'trees':len(records['trees']),'logs':len(records['logs'])},indent=2))
