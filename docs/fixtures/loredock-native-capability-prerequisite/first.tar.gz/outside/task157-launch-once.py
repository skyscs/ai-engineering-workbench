"""Consume the separately sealed Task 157 launch exactly once."""
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time

sys.dont_write_bytecode = True
root = Path("/home/toshiba/aew")
seal = json.loads((root / "task157-launch-seal.json").read_text())
manifest = Path(seal["manifest"])
assert not Path(seal["firstOutput"]).exists()
assert not Path(seal["firstOutput"] + ".claim").exists()
helper = manifest.parent / "probe.py"
spec = importlib.util.spec_from_file_location("sealed_direct_probe", helper)
probe = importlib.util.module_from_spec(spec)
spec.loader.exec_module(probe)
acquisition, _ = probe.bootstrap(manifest, seal["sha256"])
command = ["/usr/bin/python3", "-I", "-S", "-B", str(helper), "--run-first", str(manifest), seal["sha256"]]
started = time.monotonic_ns()
acquisition.retain(root / "task157-launch-intent.json", {"manifestSha256": seal["sha256"], "command": command,
    "candidateHead": seal["candidateHead"], "startedAtNs": str(started),
    "status": "Intent retained before the sole launch; outcome is recorded separately."})
record = {"manifestSha256": seal["sha256"], "command": command, "candidateHead": seal["candidateHead"]}
with (root / "task157-direct-birth-launch-first.log").open("xb") as stream:
    try:
        result = subprocess.run(command, stdin=subprocess.DEVNULL, stdout=stream, stderr=subprocess.STDOUT,
            timeout=45, env={"PATH": "/usr/bin:/bin", "LANG": "C.UTF-8", "XDG_RUNTIME_DIR": "/run/user/1000",
                            "DBUS_SESSION_BUS_ADDRESS": "unix:path=/run/user/1000/bus"})
        record.update(exitCode=result.returncode, failure=None)
    except (Exception, KeyboardInterrupt) as error:
        record.update(exitCode=None, failure=type(error).__name__, message=str(error)[:4096])
    stream.flush()
    os.fsync(stream.fileno())
record["durationNs"] = str(time.monotonic_ns() - started)
acquisition.retain(root / "task157-direct-birth-launch-first.json", record)
print(json.dumps(record, separators=(",", ":")))
raise SystemExit(0 if record["exitCode"] == 0 and record["failure"] is None else 1)
