from pathlib import Path
import hashlib
import json
import shutil
import sqlite3

base=Path('/home/toshiba/aew');output=base/'task128-expiry-case-retention';output.mkdir()
sha=lambda value:hashlib.sha256(value).hexdigest()
def inventory(root):
    result={}
    for file in sorted(root.rglob('*')):
        if file.is_symlink():result[str(file.relative_to(root))]={'symlink':str(file.readlink())}
        elif file.is_file():
            raw=file.read_bytes();result[str(file.relative_to(root))]={'bytes':len(raw),'sha256':sha(raw)}
    return result
report={'resourceQualification':False,'modelCalls':0,'reservedFamilyReads':0,'runs':[]}
for name in ['first','visible']:
    root=base/('task128-expiry-case-'+name);before=inventory(root);run=root/'run';case=run/'expiry'
    owner=json.loads((root/'result.json').read_text());driver=json.loads((run/'result.json').read_text());result=json.loads((case/'result.json').read_text())
    assert owner['reason']=='completed' and owner['errors']==[] and owner['survivors']==[] and owner['driverExit']['exit']==0
    assert driver['errors']==[] and result['errors']==[]
    observation=result['observation'];assert observation['preparations']==1 and observation['admissions']==0 and observation['answerAttempts']==0
    assert observation['scalarPolls']>=590 and observation['fakeClock'] is False
    assert observation['findStarted']+600000<=observation['clearedObserved']<=observation['findStarted']+602000
    if name=='visible':
        assert result['readyVisible'] is True and observation['browser']['noticeVisible'] is True
        assert result['timingBounds']['conservativeClearDeadline']==observation['findStarted']+602000
    events=[json.loads(line) for line in (case/'browser/events.jsonl').read_text().splitlines()]
    requests={};completed_api=0;expired=0;ready=0
    for event in events:
        value=event.get('value',{});params=value.get('params',{})
        if value.get('method')=='Network.requestWillBeSent':requests[params['requestId']]=params['request']
        if value.get('method')=='Network.loadingFinished':
            request=requests.get(params['requestId'],{})
            if request.get('url','').startswith('http://127.0.0.1:4244/api/'):
                file=case/'browser'/('response-'+params['requestId'].replace('.','-')+'.json')
                body=json.loads(file.read_text());completed_api+=1
                if request['url'].endswith('/api/session'):assert body['token']=='[removed-session-material]'
                if '/api/question-preparations/' in request['url'] and not request['url'].endswith('/review'):
                    expired+=body.get('status')=='expired';ready+=body.get('status')=='ready'
    assert expired==1 and ready>=590
    samples=[json.loads(line) for line in (case/'production/memory-timer.jsonl').read_text().splitlines()]
    assert samples[0]['event']=='start' and samples[-1]['event']=='exit-0'
    trees=[json.loads(line) for line in (case/'browser/process-tree.jsonl').read_text().splitlines()]
    assert max(row['rssBytes'] for row in trees)==result['browser']['maxRssBytes']
    assert sum(not row['complete'] for row in trees)==result['browser']['incompleteMemorySamples']
    sources=json.loads((run/'sources.json').read_text())
    for row in sources['originals']:
        raw=(run/'sources'/row['source']/row['path']).read_bytes();assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
    copied=output/name/'data';copied.parent.mkdir();shutil.copytree(case/'data',copied)
    assert inventory(copied)==inventory(case/'data')
    database=sqlite3.connect('file:'+str(copied/'loredock.db')+'?mode=ro',uri=True)
    try:
        assert database.execute('PRAGMA integrity_check').fetchall()==[('ok',)]
        assert database.execute('PRAGMA foreign_key_check').fetchall()==[]
        for table in ['answer_attempts','answer_witnesses']:assert database.execute('SELECT count(*) FROM '+table).fetchone()==(0,)
        assert database.execute('SELECT status,candidates FROM code_analyses').fetchall()==[('completed',5)]
    finally:database.close()
    assert inventory(root)==before
    report['runs'].append({'name':name,'entries':len(before),'rawInputsUnchanged':True,'catalogCopyIntegrity':'ok',
       'completedBrowserApiBodies':completed_api,'readyPollBodies':ready,'expiredPollBodies':expired,
       'findToClearMs':observation['clearedObserved']-observation['findStarted'],
       'readyToClearMs':observation['readyToClearMs'],'browserRssBytes':result['browser']['maxRssBytes'],
       'incompleteBrowserSamples':result['browser']['incompleteMemorySamples'],
       'daemonRawTimerGapMs':max(row['gapMs'] for row in samples),'daemonOsHighWaterRssBytes':max(row['processHighWaterRssBytes'] for row in samples)})
(output/'result.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
