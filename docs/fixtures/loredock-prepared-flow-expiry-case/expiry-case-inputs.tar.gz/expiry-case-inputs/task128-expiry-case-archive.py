from pathlib import Path
import json

base=Path('/home/toshiba/aew');helper=base/'task128-kernel-archive.py'
exec(helper.read_text().split("for name in ['core', 'browser', 'crash', 'interruption']:")[0])
repo=base/'worktrees/task128-expiry-case';out=repo/'docs/fixtures/loredock-prepared-flow-expiry-case'
out.mkdir(exist_ok=True)
records={'schemaVersion':'prepared-flow-expiry-case-development/1','resourceQualification':False,
         'modelCalls':0,'reservedFamilyReads':0,'focusedTests':2,'trees':[],'logs':[],
         'acceptedHttp':{'pr':142,'head':'0c3223208f5f90d28afc42b0535f1cfb3389adaf',
           'merge':'f4389040308b5582539d587148d756a1c53123b0','push':42017449096,'pull_request':42017474717,'testsPerEvent':979}}
tree('expiry-case-first',base/'task128-expiry-case-first',
     'Earlier extracted DOM-expiry control before viewport checks and conservative timing assessment. Ready/expired screenshots show the top of the page. Raw timings separately pass the stronger offline bound.')
tree('expiry-case-visible',base/'task128-expiry-case-visible')
tree('expiry-case-first-inputs',base/'task128-expiry-case-first-inputs')
tree('expiry-case-retention',base/'task128-expiry-case-retention')
for name in ['expiry-case-first','expiry-case-visible','expiry-case-install','expiry-case-build','expiry-case-focused',
             'expiry-case-first-bounds','expiry-case-retention','expiry-case-seal-check','http-assessment-ci-push','http-assessment-ci-pr']:
    log(name,base/('task128-'+name+'.log'))
inputs=base/'task128-expiry-case-inputs';inputs.mkdir()
for source in [repo/'scripts/loredock-prepared-flow/expiry-case.mjs',repo/'scripts/loredock-prepared-flow/expiry-bounds.mjs',
               repo/'scripts/loredock-prepared-flow/expiry-development.mjs',repo/'scripts/tests/loredock-expiry-bounds.test.mjs',
               helper,base/'task128-expiry-case-retention.py',base/'task128-expiry-case-first-bounds.json',Path(__file__)]:
    (inputs/source.name).write_bytes(source.read_bytes())
tree('expiry-case-inputs',inputs)
records['retention']=json.loads((base/'task128-expiry-case-retention/result.json').read_text())
(out/'records.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps({'trees':len(records['trees']),'logs':len(records['logs']),'focusedTests':2},indent=2))
