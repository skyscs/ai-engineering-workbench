// Independent write comparison unit 0.
