// Independent write comparison unit 1.
