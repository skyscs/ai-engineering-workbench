from pathlib import Path
import json
import re

base=Path('/home/toshiba/aew');helper=base/'task128-kernel-archive.py'
exec(helper.read_text().split("for name in ['core', 'browser', 'crash', 'interruption']:")[0])
repo=base/'worktrees/task128-worker-accounting-case';out=repo/'docs/fixtures/loredock-prepared-flow-worker-accounting-case';out.mkdir(exist_ok=True)
accepted=json.loads((base/'task128-integration-handoff.json').read_text())['latestAccepted'];assert accepted['pr']==149
records={'schemaVersion':'prepared-flow-worker-accounting-case-development/1','resourceQualification':False,'modelCalls':0,'reservedFamilyReads':0,'trees':[],'logs':[],'acceptedCatalogFaults':accepted}
for name in ['worker-accounting-case-first','worker-accounting-case-retention','worker-accounting-case-retention-second']:tree(name,base/('task128-'+name))
for name in ['worker-accounting-case-first','worker-accounting-case-install','worker-accounting-case-build','worker-accounting-case-tests','worker-accounting-case-retention','worker-accounting-case-retention-second','worker-accounting-case-seal-check','catalog-faults-ci-push','catalog-faults-ci-pr']:log(name,base/('task128-'+name+'.log'))
testlog=(base/'task128-worker-accounting-case-tests.log').read_text()
for i,location in enumerate(re.findall(r'Retained worker-accounting checkpoint test: (/tmp/loredock-worker-accounting-checkpoint-[A-Za-z0-9]+)',testlog)):tree('worker-accounting-case-test-'+str(i+1),Path(location))
inputs=base/'task128-worker-accounting-case-inputs';inputs.mkdir()
for source in [repo/'scripts/loredock-prepared-flow/cold-warm-cases.mjs',repo/'scripts/loredock-prepared-flow/worker-accounting-case.mjs',repo/'scripts/loredock-prepared-flow/worker-accounting-case-development.mjs',repo/'scripts/tests/loredock-worker-accounting-checkpoint.test.mjs',helper,base/'task128-worker-accounting-case-retention-first.py',base/'task128-worker-accounting-case-retention.py',Path(__file__)]:
    (inputs/source.name).write_bytes(source.read_bytes())
tree('worker-accounting-case-inputs',inputs)
records['retention']=json.loads((base/'task128-worker-accounting-case-retention-second/result.json').read_text())
(out/'records.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps({'trees':len(records['trees']),'logs':len(records['logs'])},indent=2))
