export function readOrder() { return fetch("/orders", { headers: { "X-Tenant": "synthetic" } }); }
export function publishOrder(event: unknown) { kafka.send("orders-created", event); }
