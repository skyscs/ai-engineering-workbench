# Observation control

A synthetic order reader publishes an order event. No deployment or business behavior is asserted.
