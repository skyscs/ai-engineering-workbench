import importlib.util,json,subprocess,time,types
from pathlib import Path
spec=importlib.util.spec_from_file_location('kernel',"/home/toshiba/aew/worktrees/task128-cold-warm/scripts/loredock-prepared-flow/kernel-owner.py")
kernel=importlib.util.module_from_spec(spec);spec.loader.exec_module(kernel)
root=Path("/tmp/loredock-browser-lifetime-UjckgU");outer=root/'outer';outer.mkdir()
owner=kernel.Owner(types.SimpleNamespace(output=outer,wall_ms=15000,storage_bytes=2147483648,grace_ms=200))
try:
 owner.bootstrap()
 parent=subprocess.Popen(["/home/toshiba/aew/toolchain/node-v22.23.2-linux-x64/bin/node",'-e',"const{spawn}=require('node:child_process');const fs=require('node:fs');\n    const child=spawn('python3',[...[\"-I\",\"-S\",\"-B\",\"/home/toshiba/aew/worktrees/task128-cold-warm/scripts/loredock-prepared-flow/browser-lifetime.py\",\"--executable\",\"/home/toshiba/aew/toolchain/node-v22.23.2-linux-x64/bin/node\",\"--output\",\"/tmp/loredock-browser-lifetime-UjckgU/lifetime\",\"--grace-ms\",\"200\"],'--parent-pid',String(process.pid),'--','-e',\"require('node:fs').writeFileSync(\\\"/tmp/loredock-browser-lifetime-UjckgU/browser-ready\\\",'ready');setInterval(()=>{},1000);\"],{detached:true,stdio:'ignore'});child.unref();\n    const timer=setInterval(()=>{if(fs.existsSync(\"/tmp/loredock-browser-lifetime-UjckgU/browser-ready\")){clearInterval(timer);process.exit(0);}},10);"],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 stdout,stderr=parent.communicate(timeout=5)
 (root/'launcher-stdout.log').write_bytes(stdout);(root/'launcher-stderr.log').write_bytes(stderr)
 assert parent.returncode==0
 result=Path("/tmp/loredock-browser-lifetime-UjckgU/lifetime/result.json")
 deadline=time.monotonic()+10
 while not result.exists():
  assert time.monotonic()<deadline
  time.sleep(0.025)
 report=json.loads(result.read_text())
 assert report['reason']=='parent-exited' and not report['errors'] and not report['survivors']
 assert report['driverExit']['exit']==-15
 deadline=time.monotonic()+5
 while owner.descendants():
  owner.reap();assert time.monotonic()<deadline;time.sleep(0.025)
 owner.reap();assert len(owner.report['reaped'])==1 and owner.report['reaped'][0]['exit']==1
 kernel.save(outer/'result.json',owner.report)
finally:
 owner.cleanup();owner.log.close();owner.samples.close()
