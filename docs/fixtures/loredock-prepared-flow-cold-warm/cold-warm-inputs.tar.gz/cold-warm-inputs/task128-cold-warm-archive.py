from pathlib import Path
import json
import re

base = Path('/home/toshiba/aew'); helper = base / 'task128-kernel-archive.py'
exec(helper.read_text().split("for name in ['core', 'browser', 'crash', 'interruption']:")[0])
repo = base / 'worktrees/task128-cold-warm'; out = repo / 'docs/fixtures/loredock-prepared-flow-cold-warm'
records = {'schemaVersion': 'prepared-flow-cold-warm-development/1', 'resourceQualification': False,
           'modelCalls': 0, 'reservedFamilyReads': 0, 'tests': 973, 'trees': [], 'logs': [],
           'acceptedCoordinator': {'pr': 140, 'head': '3ad4c5c1ba0b4029807059f8c746a05ef18d9cec',
              'merge': 'c875fa2a6ffceaf5c158f3b5c4c8cb8c24310ee2', 'push': 42013967631,
              'pull_request': 42014009139, 'testsPerEvent': 970}}
tree('cold-warm-first', base / 'task128-cold-warm-first',
     'Failed twenty-source scaling control: partial inventory at 240 files; no subsequent cold/warm candidate run. Earlier report predates explicit notRun/metric aggregation.')
tree('cold-warm-unscaled', base / 'task128-cold-warm-unscaled',
     'Separate established four-source control; three functional warm lifetimes, two daemon timer failures. Does not rescue scaling failure.')
tree('cold-warm-retention', base / 'task128-cold-warm-retention')
tree('cold-warm-first-inputs', base / 'task128-cold-warm-first-inputs')
for name in ['cold-warm-first', 'cold-warm-unscaled', 'cold-warm-install', 'cold-warm-build',
             'cold-warm-focused-first', 'cold-warm-check-first', 'cold-warm-seal-check',
             'cold-warm-retention', 'cold-warm-gap-inspection', 'coordinator-ci-push', 'coordinator-ci-pr']:
    raw = log(name, base / ('task128-' + name + '.log'))
    if name != 'cold-warm-check-first': continue
    for kind, pattern in [('sequence', r'Retained flow-coordinator test: (/tmp/loredock-flow-coordinator-[A-Za-z0-9]+)'),
                          ('lifetime', r'Retained browser-lifetime test: (/tmp/loredock-browser-lifetime-[A-Za-z0-9]+)'),
                          ('owner', r'Retained kernel-owner test: (/tmp/loredock-kernel-(?:adoption|owner)-[A-Za-z0-9]+)'),
                          ('checkpoint', r'Retained history-checkpoint test: (/tmp/loredock-history-checkpoint-[A-Za-z0-9]+)')]:
        for index, location in enumerate(re.findall(pattern, raw)):
            tree(name + '-' + kind + '-' + str(index + 1), Path(location))
inputs = base / 'task128-cold-warm-inputs'; inputs.mkdir()
for source in [repo / 'scripts/loredock-prepared-flow/cold-warm-cases.mjs', repo / 'scripts/loredock-prepared-flow/cold-warm-development.mjs',
               repo / 'scripts/tests/loredock-cold-warm.test.mjs', helper, base / 'task128-cold-warm-retention.py',
               base / 'task128-cold-warm-gap-inspection.py', Path(__file__)]:
    (inputs / source.name).write_bytes(source.read_bytes())
tree('cold-warm-inputs', inputs)
records['retention'] = json.loads((base / 'task128-cold-warm-retention/result.json').read_text())
(out / 'records.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps({'trees': len(records['trees']), 'logs': len(records['logs']), 'tests': records['tests']},indent=2))
