from pathlib import Path
import hashlib
import json
import shutil
import sqlite3
import subprocess

base = Path('/home/toshiba/aew'); output = base / 'task128-cold-warm-retention'; output.mkdir()
sha = lambda value: hashlib.sha256(value).hexdigest()
def inventory(root):
    return {str(p.relative_to(root)): {'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())}
            for p in sorted(root.rglob('*')) if p.is_file()}
report = {'resourceQualification': False, 'modelCalls': 0, 'reservedFamilyReads': 0,
          'runs': [], 'catalogs': [], 'sourceRepositories': 0, 'httpBodies': 0, 'warmLifetimes': 0}
for name in ['first', 'unscaled']:
    root = base / ('task128-cold-warm-' + name); run = root / 'run'; before = inventory(root)
    owner = json.loads((root / 'result.json').read_text())
    assert owner['reason'] == 'driver-failure' and owner['driverExit']['exit'] == 1
    assert owner['errors'] == [] and owner['survivors'] == []
    result = json.loads((run / 'result.json').read_text())
    for source_file in run.glob('input-*/sources.json'):
        sources = json.loads(source_file.read_text()); source_root = source_file.parent / 'sources'
        for row in sources['originals']:
            raw = (source_root / row['source'] / row['path']).read_bytes()
            assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
        for source, revision in sources['revisions'].items():
            command = ['git', '-c', 'core.hooksPath=/dev/null', 'rev-parse', 'HEAD', 'HEAD^{tree}']
            actual = subprocess.check_output(command, cwd=source_root / source,
              env={'PATH': '/usr/bin:/bin', 'GIT_CONFIG_NOSYSTEM': '1', 'GIT_CONFIG_GLOBAL': '/dev/null'}, text=True).splitlines()
            assert actual == [revision['revision'], revision['tree']]
            report['sourceRepositories'] += 1
    for requests in run.rglob('requests.jsonl'):
        routes = {}
        for line in requests.read_text().splitlines():
            event = json.loads(line)
            if event['event'] == 'request': routes[event['id']] = event['route']
            if event['event'] == 'response':
                raw = (requests.parent / (event['id'] + '.json')).read_bytes()
                if routes[event['id']] == '/session': assert json.loads(raw)['token'] == '[removed-session-token]'
                else: assert len(raw) == event['bytes']; report['httpBodies'] += 1
    for row in result['cases']:
        directory = run / row['id']; value = row['value']
        process_directory = directory / ('production' if row['id'].startswith('cold-') else 'controlled')
        samples = [json.loads(line) for line in (process_directory / 'memory-timer.jsonl').read_text().splitlines()]
        assert samples[0]['event'] == 'start' and samples[-1]['event'] == 'exit-0'
        for metric, field in [('sampledRssBytes','rss'),('osHighWaterRssBytes','processHighWaterRssBytes'),
                              ('heapUsedBytes','heapUsed'),('rawIntervalGapMs','gapMs')]:
            assert value['daemon']['measured'][metric] == max(sample[field] for sample in samples)
        assert value['daemon']['passed'] is False
        assert [check['metric'] for check in value['daemon']['checks'] if not check['passed']] == ['rawIntervalGapMs']
        if row['id'] == 'cold-240':
            assert len(value['errors']) == 1 and "'partial'" in value['errors'][0]['message']
        else: assert value['errors'] == []
    for original in sorted(run.rglob('loredock.db')):
        relative = original.parent.relative_to(run)
        copied = output / name / relative; copied.parent.mkdir(parents=True, exist_ok=True)
        shutil.copytree(original.parent, copied)
        assert inventory(original.parent) == inventory(copied)
        database = sqlite3.connect('file:' + str(copied / 'loredock.db') + '?mode=ro', uri=True)
        try:
            assert database.execute('PRAGMA integrity_check').fetchall() == [('ok',)]
            assert database.execute('PRAGMA foreign_key_check').fetchall() == []
            states = database.execute('SELECT status,count(*) FROM answer_attempts GROUP BY status').fetchall()
            analyses = database.execute('SELECT status,candidates FROM code_analyses').fetchall()
            if name == 'first': assert analyses == [('partial',217)] and states == []
            elif str(relative) == 'warm-12/data':
                assert states == [('succeeded',3)] and analyses == [('completed',5)]
                warm = json.loads((run / 'warm-12/result.json').read_text())
                assert [row['repetition'] for row in warm['repetitions']] == [1,2,3]
                for row in warm['repetitions']:
                    stored = database.execute('SELECT a.context,w.witness,w.reviewedHash FROM answer_attempts a JOIN answer_witnesses w ON w.answerId=a.id WHERE a.id=?', (row['published']['answer']['id'],)).fetchone()
                    assert json.loads(stored[0]) == row['prepared']['review']['context']
                    assert json.loads(stored[1])['prompt'] == row['request']['prompt']
                    assert stored[2] == row['prepared']['review']['reviewedHash']
                    assert row['runtime'] == {'prepares': row['repetition'], 'calls': row['repetition'], 'closed': row['repetition']}
                    report['warmLifetimes'] += 1
            else: assert states == [] and analyses == [('completed',5)]
            report['catalogs'].append({'source': str(original.parent), 'copy': str(copied), 'integrity': 'ok',
                'foreignKeyErrors': [], 'answerStates': states, 'analyses': analyses})
        finally: database.close()
    assert inventory(root) == before
    report['runs'].append({'name': name, 'unchanged': True, 'entries': len(before), 'ownerExit': 1,
                          'observedCases': [row['id'] for row in result['cases']]})
assert len(report['catalogs']) == 4 and report['sourceRepositories'] == 44 and report['warmLifetimes'] == 3
(output / 'result.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
