from pathlib import Path
import json
import sqlite3

root = Path('/home/toshiba/aew/task128-cold-warm-retention')
database = sqlite3.connect('file:' + str(root / 'first/cold-240/data/loredock.db') + '?mode=ro', uri=True)
try:
    counts = database.execute('SELECT status,gapCount,count(*) FROM code_analysis_files GROUP BY status,gapCount').fetchall()
    assert counts == [('parsed', 0, 5), ('parsed', 1, 212)]
    gaps = []
    for raw, in database.execute('SELECT payload FROM code_analysis_files WHERE gapCount>0'):
        payload = json.loads(raw)
        assert payload['facts']['gaps'] == ['unsupported-typescript-profile']
        assert payload['path'].startswith('padding/constant-')
        gaps.append({'source': payload['sourceName'], 'path': payload['path'], 'gaps': payload['facts']['gaps']})
finally:
    database.close()
result = {'source': 'Independent stopped catalog copy; no candidate rerun.', 'counts': counts,
          'paddingGaps': gaps, 'originalFailurePreserved': True, 'resourceQualification': False}
with (root / 'gap-inspection.json').open('x') as file:
    file.write(json.dumps(result,indent=2)+'\n')
print(json.dumps({'parsedWithoutGaps': 5, 'parsedWithExplicitUnsupportedProfile': 212, 'analysisStatus': 'partial'},indent=2))
