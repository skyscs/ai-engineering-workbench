from pathlib import Path
import json

base = Path('/home/toshiba/aew')
helper = base / 'task128-kernel-archive.py'
exec(helper.read_text().split("for name in ['core', 'browser', 'crash', 'interruption']:")[0])
repo = base / 'worktrees/task129-partial-inventory'
out = repo / 'docs/fixtures/loredock-partial-inventory-diagnosis'
records = json.loads((out / 'records.json').read_bytes())
for name in ['partial-static-first', 'partial-archive-first']:
    log(name, base / ('task129-' + name + '.log'))
source = base / 'task129-partial-static-inputs'
source.mkdir()
for file in [base / 'task129-partial-static.py', Path(__file__)]:
    (source / file.name).write_bytes(file.read_bytes())
tree('partial-static-inputs', source)
(out / 'records.json').write_text(json.dumps(records, indent=2) + '\n')
print(json.dumps({'trees': len(records['trees']), 'entries': sum(row['entries'] for row in records['trees']),
                  'logs': len(records['logs'])}, indent=2))
