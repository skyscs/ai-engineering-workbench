export function readOptionalSummary(destination: string) {
  return fetch(destination, { method: "GET" });
}
