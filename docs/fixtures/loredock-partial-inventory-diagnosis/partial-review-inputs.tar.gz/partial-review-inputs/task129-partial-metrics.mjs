// Offline comparison of retained passive measurements, without another application run.
import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { assessDaemonSamples } from './worktrees/task129-partial-inventory/scripts/loredock-prepared-flow/cold-warm-cases.mjs';

const result = { controls: [], resourceQualification: false, modelEligibility: false, newCandidateExecutions: 0 };
for (const id of ['completed', 'constant', 'dynamic-request', 'no-analysis']) {
  const root = '/home/toshiba/aew/task129-partial-first/run/' + id + '/case';
  const raw = await readFile(root + '/production/memory-timer.jsonl', 'utf8'); assert(raw.endsWith('\n'));
  const samples = raw.trimEnd().split('\n').map(JSON.parse), metrics = assessDaemonSamples(samples);
  const stored = JSON.parse(await readFile(root + '/result.json'));
  if (stored.metrics) assert.deepEqual(metrics, stored.metrics);
  result.controls.push({ id, ...metrics, firstIntervalMs: samples[1].gapMs,
    maximumGapIsFirstInterval: metrics.measured.rawIntervalGapMs === samples[1].gapMs });
}
await writeFile('/home/toshiba/aew/task129-partial-metrics.json', JSON.stringify(result, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify(result, null, 2));
