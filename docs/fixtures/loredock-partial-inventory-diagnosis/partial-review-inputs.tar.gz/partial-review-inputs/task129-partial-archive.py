from pathlib import Path
import json

base = Path('/home/toshiba/aew')
helper = base / 'task128-kernel-archive.py'
exec(helper.read_text().split("for name in ['core', 'browser', 'crash', 'interruption']:")[0])
repo = base / 'worktrees/task129-partial-inventory'
out = repo / 'docs/fixtures/loredock-partial-inventory-diagnosis'
assert not (out / 'records.json').exists()
records = {'schemaVersion': 'ordinary-partial-inventory-diagnosis/1',
           'base': '6150630d6c708d1ee3e0a09562d5c4d518823dd6',
           'functionalPassed': True, 'resourceQualification': False, 'modelEligibility': False,
           'modelCalls': 0, 'reservedFamilyReads': 0, 'trees': [], 'logs': []}
for name in ['partial-first', 'partial-first-inputs', 'partial-retention']:
    tree(name, base / ('task129-' + name))
for name in ['partial-install', 'partial-build', 'partial-tests-first', 'partial-input-seal',
             'partial-first', 'partial-retain-first', 'partial-metrics-first']:
    log(name, base / ('task129-' + name + '.log'))
inputs = base / 'task129-partial-review-inputs'
inputs.mkdir()
for file in [helper, Path(__file__), base / 'task129-partial-first-launch.py', base / 'task129-partial-retain.py',
             base / 'task129-partial-metrics.mjs', base / 'task129-partial-metrics.json']:
    (inputs / file.name).write_bytes(file.read_bytes())
tree('partial-review-inputs', inputs)
records['retention'] = json.loads((base / 'task129-partial-retention/result.json').read_bytes())
records['metrics'] = json.loads((base / 'task129-partial-metrics.json').read_bytes())
(out / 'records.json').write_text(json.dumps(records, indent=2) + '\n')
print(json.dumps({'trees': len(records['trees']), 'entries': sum(row['entries'] for row in records['trees']),
                  'logs': len(records['logs']), 'functionalPassed': True, 'resourceQualification': False}, indent=2))
