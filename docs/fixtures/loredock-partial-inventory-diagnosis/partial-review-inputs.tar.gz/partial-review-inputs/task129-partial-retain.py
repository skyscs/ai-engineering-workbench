"""Independent stopped-copy/original/HTTP review of the four first ordinary controls."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import sqlite3
import subprocess

base = Path('/home/toshiba/aew')
root = base / 'task129-partial-first'
output = base / 'task129-partial-retention'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
read = lambda file: json.loads(file.read_bytes())


def inventory(directory):
    result = {}
    for parent, directories, files in os.walk(directory, followlinks=False):
        for name in sorted(directories + files):
            file = Path(parent) / name
            relative = str(file.relative_to(directory))
            if file.is_symlink():
                result[relative] = {'target': os.readlink(file)}
            elif file.is_file():
                raw = file.read_bytes()
                result[relative] = {'bytes': len(raw), 'sha256': sha(raw)}
    return result


before = inventory(root)
owner = read(root / 'result.json')
assert owner['reason'] == 'completed' and owner['driverExit']['exit'] == 0
assert owner['errors'] == owner['survivors'] == []
result = read(root / 'run/result.json')
assert result['errors'] == [] and result['functionalPassed'] is True
assert result['modelCalls'] == result['reservedFamilyReads'] == 0
plan = read(base / 'task129-partial-first-inputs/execution.json')
assert owner['catalogRoots'] == plan['catalogRoots'] and len(owner['observedCatalogRoots']) == 5
output.mkdir()
report = {'catalogs': [], 'gitIdentities': 0, 'sourceFiles': 0, 'httpResponses': 0, 'sessionRedactions': 0,
          'preparations': 0, 'admissions': 0, 'originalChecks': 0, 'stableRepeatedReviews': 0,
          'modelCalls': 0, 'reservedFamilyReads': 0, 'resourceQualification': False, 'modelEligibility': False}
env = {'PATH': '/usr/bin:/bin', 'LC_ALL': 'C', 'GIT_CONFIG_NOSYSTEM': '1',
       'GIT_CONFIG_GLOBAL': '/dev/null', 'GIT_OPTIONAL_LOCKS': '0'}
for row in result['cases']:
    name, value = row['id'], row['value']
    assert value['errors'] == value['assessmentErrors'] == [] and value['preparations'] == 1
    assert value.get('functionalPassed', value.get('passed')) is True
    declared = next(item for item in plan['inputs'] if item['id'] == name)
    sources = read(root / 'run' / name / 'sources.json')
    review = value.get('prepared', {}).get('review', value.get('review'))
    for source, files in declared['corpus'].items():
        directory = root / 'run' / name / 'sources' / source
        for key, ref in [('revision', 'HEAD'), ('tree', 'HEAD^{tree}')]:
            actual = subprocess.check_output(['/usr/bin/git', '-c', 'core.hooksPath=/dev/null', '-c', 'core.fsmonitor=false',
                                             'rev-parse', ref], cwd=directory, env=env, text=True).strip()
            assert actual == sources['revisions'][source][key]
        assert not subprocess.check_output(['/usr/bin/git', '-c', 'core.hooksPath=/dev/null', '-c', 'core.fsmonitor=false',
                                            'status', '--porcelain'], cwd=directory, env=env)
        report['gitIdentities'] += 1
        for relative, text in files.items():
            raw = (directory / relative).read_bytes()
            assert raw == text.encode()
            original = next(item for item in sources['originals'] if item['source'] == source and item['path'] == relative)
            assert len(raw) == original['bytes'] and sha(raw) == original['sha256']
            report['sourceFiles'] += 1
    for reference in plan['references'].values():
        matches = [span for span in review['context']['spans'] if span['sourceName'] == reference['source'] and
                   span['path'] == reference['path'] and reference['quote'] in span['text']]
        assert matches
        original = declared['corpus'][reference['source']][reference['path']].splitlines()
        for span in matches:
            assert span['text'] == '\n'.join(original[span['startLine'] - 1:span['endLine']])
            assert span['revision'] == sources['revisions'][reference['source']]['revision']
        report['originalChecks'] += 1
    requests, responses, reviews = {}, set(), []
    http = root / 'run' / name / 'case/http'
    for entry in map(json.loads, (http / 'requests.jsonl').read_text().splitlines()):
        key = entry['id']
        if entry['event'] == 'request':
            assert key not in requests
            requests[key] = entry
            report['preparations'] += entry['method'] == 'POST' and entry['route'] == '/question-preparations'
            report['admissions'] += entry['method'] == 'POST' and entry['route'] == '/prepared-answers'
        else:
            assert entry['event'] == 'response' and key in requests and key not in responses
            responses.add(key)
            raw = (http / (key + '.json')).read_bytes()
            assert entry['status'] < 400
            if requests[key]['route'] == '/session':
                assert json.loads(raw)['token'] == '[removed-session-token]'
                report['sessionRedactions'] += 1
            else:
                assert len(raw) == entry['bytes']
            if requests[key]['route'].endswith('/review'):
                assert json.loads(raw) == review
                reviews.append(raw)
            report['httpResponses'] += 1
    assert set(requests) == responses
    assert len(reviews) == (1 if name == 'no-analysis' else 2)
    if len(reviews) == 2:
        assert reviews[0] == reviews[1]
        report['stableRepeatedReviews'] += 1
for original in sorted(root.rglob('loredock.db')):
    relative = str(original.parent.relative_to(root))
    assert relative in owner['catalogRoots']
    copied = output / relative
    copied.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(original.parent, copied)
    assert inventory(original.parent) == inventory(copied)
    database = sqlite3.connect('file:' + str(copied / 'loredock.db') + '?mode=ro', uri=True)
    try:
        assert database.execute('PRAGMA integrity_check').fetchall() == [('ok',)]
        assert database.execute('PRAGMA foreign_key_check').fetchall() == []
        assert database.execute('SELECT count(*) FROM answer_attempts').fetchone()[0] == 0
        assert database.execute('SELECT count(*) FROM answer_witnesses').fetchone()[0] == 0
    finally:
        database.close()
    report['catalogs'].append({'source': str(original.parent), 'copy': str(copied), 'integrity': 'ok', 'attempts': 0, 'witnesses': 0})
assert len(report['catalogs']) == 5 and report['gitIdentities'] == 16 and report['sourceFiles'] == 50
assert report['preparations'] == 4 and report['admissions'] == 0 and report['originalChecks'] == 32
assert report['stableRepeatedReviews'] == 3
assert inventory(root) == before
report.update(rawEntries=len(before), rawInputsUnchanged=True)
(output / 'raw-input-inventory.json').write_text(json.dumps(before, indent=2) + '\n')
(output / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({**report, 'catalogs': len(report['catalogs'])}, indent=2))
