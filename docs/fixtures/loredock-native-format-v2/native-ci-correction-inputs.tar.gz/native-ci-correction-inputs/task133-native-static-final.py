from pathlib import Path
from urllib.parse import unquote
import ast
import gzip
import hashlib
import json
import re
import subprocess
import tarfile

root = Path('/home/toshiba/aew/worktrees/task133-native-context-v2')
out = root / 'docs/fixtures/loredock-native-format-v2'
sha = lambda value: hashlib.sha256(value).hexdigest()
counts = {'trees': 0, 'entries': 0, 'logs': 0, 'localLinks': 0}
data = json.loads((out / 'records.json').read_bytes())
for row in data['logs']:
    raw = (out / row['path']).read_bytes()
    assert sha(raw) == row['archiveSha256']
    value = gzip.decompress(raw)
    assert len(value) == row['rawBytes'] and sha(value) == row['rawSha256']
    counts['logs'] += 1
for row in data['trees']:
    assert sha((out / row['path']).read_bytes()) == row['sha256']
    raw = (out / row['inventory']).read_bytes()
    assert sha(raw) == row['inventorySha256']
    expected = json.loads(gzip.decompress(raw))
    prefix = row['path'].removesuffix('.tar.gz') + '/'
    with tarfile.open(out / row['path'], 'r:gz') as archive:
        assert {member.name.removeprefix(prefix) for member in archive.getmembers()} == set(expected)
        for name, info in expected.items():
            member = archive.getmember(prefix + name)
            if info['kind'] == 'symlink':
                assert member.issym() and member.linkname == info['target']
            else:
                assert member.isfile()
                raw = archive.extractfile(member).read()
                assert len(raw) == info['bytes'] and sha(raw) == info['sha256']
            counts['entries'] += 1
    counts['trees'] += 1
base = 'd43cb05611fe41dea1107404cb6448441d18a0c5'
def changed(*paths, options=()):
    return subprocess.check_output(['git', 'diff', '--name-only', *options, base, '--', *paths], cwd=root, text=True).splitlines()
assert not changed('packages', 'fixtures', 'scripts/loredock-prepared-flow', '.github', 'pnpm-lock.yaml', 'package.json',
    'docs/loredock/PREPARED_QUESTION_API.md', 'tasks/128-loredock-prepared-flow-resource-qualification.md', 'docs/loredock/PREPARED_FLOW_QUALIFICATION.md',
    'docs/fixtures/loredock-prepared-flow-execution-seal', 'docs/fixtures/loredock-prepared-flow-result')
allowed = {'apps/loredock-web/src/AnswerPanel.tsx', 'apps/loredock-web/src/NativeQuestionContext.tsx', 'apps/loredock/src/answer-history.ts', 'apps/loredock/src/answer-witness-store.ts', 'apps/loredock/src/question-context.ts', 'apps/loredock/src/question-native-format.ts', 'apps/loredock/src/question-preparation-types.ts', 'apps/loredock/src/question-witness.ts'}
assert set(changed('apps/loredock/src', 'apps/loredock-web/src')) == allowed
execution = json.loads(Path('/home/toshiba/aew/task133-native-v2-first-inputs/execution.json').read_bytes())
for name, identity in execution['workspaceModules'].items():
    raw = (root / name).read_bytes()
    assert len(raw) == identity['bytes'] and sha(raw) == identity['sha256'], name
assert not [file for file in changed('apps/loredock/tests/fixtures', options=('--diff-filter=DM',)) if file.endswith(('.txt', '.json'))]
files = set(changed() + subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=root, text=True).splitlines())
for name in files:
    file = root / name
    if file.suffix not in ('.md', '.json', '.ts', '.mjs', '.py'):
        continue
    text = file.read_text()
    assert not re.search('[А-Яа-яЁё]', text), name
    if file.suffix == '.json':
        json.loads(text)
    if file.suffix == '.py':
        ast.parse(text)
    if file.suffix != '.md':
        continue
    text = re.sub(r'```[^\n]*\n.*?```', '', text, flags=re.S)
    text = re.sub(r'`[^`\n]*`', '', text)
    for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)', text):
        if re.match(r'^(https?://|mailto:|#)', target):
            continue
        target = unquote(target.split('#')[0].split(' "')[0].strip('<>'))
        if target:
            assert (file.parent / target).exists(), (name, target)
            counts['localLinks'] += 1
print(json.dumps({**counts, 'firstObservedApplicationBytesUnchanged': True, 'compiledModules': len(execution['workspaceModules']),
    'oldManifestsAndFrozenInputsUnchanged': True, 'resourceQualification': False}, indent=2))
