from pathlib import Path
import json
import subprocess
base = Path('/home/toshiba/aew')
helper = base / 'task128-kernel-archive.py'
exec(helper.read_text().split("for name in ['core', 'browser', 'crash', 'interruption']:")[0])
repo = base / 'worktrees/task133-native-context-v2'
out = repo / 'docs/fixtures/loredock-native-format-v2'
records = json.loads((out / 'records.json').read_bytes())
assert len(records['trees']) == 7 and len(records['logs']) == 14
for name in ['native-ci-push-first', 'native-ci-pr-first', 'native-api-after-ci']:
    log(name, base / ('task133-' + name + '.log'))
inputs = base / 'task133-native-ci-correction-inputs'; inputs.mkdir()
for file in [Path(__file__), base / 'task133-native-static-final.py']:
    (inputs / file.name).write_bytes(file.read_bytes())
for commit, name in [('65e9eee', 'changed-public-contract.md'), ('d43cb05', 'frozen-public-contract.md')]:
    (inputs / name).write_bytes(subprocess.check_output(['git', 'show', commit + ':docs/loredock/PREPARED_QUESTION_API.md'], cwd=repo))
(inputs / 'NATIVE_QUESTION_FORMAT.md').write_bytes((repo / 'docs/loredock/NATIVE_QUESTION_FORMAT.md').read_bytes())
tree('native-ci-correction-inputs', inputs)
records['initialCi'] = {'head': '65e9eee29f3a28acc340de566ed7d8db1beab34d',
    'push': 42120037324, 'pullRequest': 42120048796, 'passedEach': 1044, 'failedEach': 1,
    'reason': 'A post-test documentation edit changed the frozen API contract. Restored exact bytes and moved v2 extension to a separate document.',
    'productChanged': False, 'affectedLocalTests': 9, 'affectedLocalFailures': 0}
(out / 'records.json').write_text(json.dumps(records, indent=2) + '\n')
print(json.dumps({'trees':len(records['trees']), 'entries':sum(row['entries'] for row in records['trees']), 'logs':len(records['logs'])}))
