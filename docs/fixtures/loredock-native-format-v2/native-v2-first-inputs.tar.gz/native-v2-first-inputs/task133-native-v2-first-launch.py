"""Freeze the versioned-format observation inputs before the first bounded owner."""
from pathlib import Path
import hashlib
import json
import os
import socket
import subprocess

base = Path('/home/toshiba/aew')
repository = base / 'worktrees/task133-native-context-v2'
node = base / 'toolchain/node-v22.23.2-linux-x64/bin/node'
python = Path('/usr/bin/python3').resolve()
output = base / 'task133-native-v2-first'
snapshot = base / 'task133-native-v2-first-inputs'
assert not output.exists() and not snapshot.exists()
environment = {'PATH': str(node.parent) + ':/usr/bin:/bin', 'LC_ALL': 'C', 'HOME': str(output / 'home')}
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=repository)
with socket.socket() as listener:
    listener.bind(('127.0.0.1', 4244))
data = json.loads(subprocess.check_output([str(node), '--input-type=module', '-e',
    "import {plan} from './scripts/loredock-native-size/factored-plan.mjs';console.log(JSON.stringify({plan,catalogRoots:plan.catalogRoots}));"],
    cwd=repository, env=environment))
command = [str(python), '-I', '-S', '-B', str(repository / 'scripts/loredock-prepared-flow/kernel-owner.py'),
           '--node', str(node), '--script', str(repository / 'scripts/loredock-native-size/factored.mjs'),
           '--output', str(output), '--cwd', str(repository), '--wall-ms', '300000']
for root in data['catalogRoots']:
    command.extend(['--catalog-root', root])
command.extend(['--', str(base / 'task133-native-v1-first'), str(base / 'task131-history-first')])
snapshot.mkdir()
for directory in ['scripts/loredock-native-size', 'scripts/loredock-prepared-flow', 'scripts/loredock-native-qualification']:
    for source in sorted((repository / directory).glob('*')):
        if source.is_file() and source.suffix in ['.py', '.mjs']:
            destination = snapshot / directory / source.name
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(source.read_bytes())
for name in ['scripts/loredock-native-assessment/fixture.mjs', 'pnpm-lock.yaml', '.node-version',
             'apps/loredock/node_modules/typescript/lib/typescript.js',
             'apps/loredock/node_modules/typescript/LICENSE.txt']:
    destination = snapshot / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes((repository / name).read_bytes())
for source in sorted((repository / 'apps/loredock/public').rglob('*')):
    if source.is_file():
        destination = snapshot / source.relative_to(repository)
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(source.read_bytes())
hashes = {}
for parent in ['apps', 'packages']:
    for source in sorted((repository / parent).glob('*/dist/**/*.js')):
        raw = source.read_bytes()
        name = str(source.relative_to(repository))
        hashes[name] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
        destination = snapshot / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(raw)
compiler = (repository / 'apps/loredock/node_modules/typescript/lib/typescript.js').resolve()
(snapshot / Path(__file__).name).write_bytes(Path(__file__).read_bytes())
data.update(command=command, environment=environment,
            codeCommit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repository, text=True).strip(),
            nodeVersion=subprocess.check_output([str(node), '--version'], text=True).strip(),
            nodeSha256=hashlib.sha256(node.read_bytes()).hexdigest(),
            compiler={'path': str(compiler), 'sha256': hashlib.sha256(compiler.read_bytes()).hexdigest()},
            workspaceModules=hashes, resourceQualification=False, modelCalls=0, reservedFamilyReads=0)
data['retainedInputRoots'] = [str(base / 'task133-native-v1-first'), str(base / 'task131-history-first')]
data['browser'] = {'wrapper': '/usr/bin/google-chrome', 'binary': '/opt/google/chrome/chrome', 'sha256': hashlib.sha256(Path('/opt/google/chrome/chrome').read_bytes()).hexdigest()}
(snapshot / 'execution.json').write_text(json.dumps(data, indent=2) + '\n')
os.execve(command[0], command, environment)
