# Cancellation endpoint
The supplied handler is empty.
