final class Cancellation { void cancel(String tenant) {} }
