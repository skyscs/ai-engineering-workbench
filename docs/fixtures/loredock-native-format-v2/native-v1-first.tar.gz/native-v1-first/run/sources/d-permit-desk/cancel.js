define(["dojo/request"], function (request) {
  return { cancelPermit: function (tenant) {
    return request.post("/permits/cancel", { headers: { "X-Cancel-Tenant": tenant } });
  } };
});
