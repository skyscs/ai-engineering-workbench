# Permit cancellation desk
The legacy helper sends a cancellation request.
