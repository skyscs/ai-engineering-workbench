# Permit monitor
readPermit requests a permit summary.
