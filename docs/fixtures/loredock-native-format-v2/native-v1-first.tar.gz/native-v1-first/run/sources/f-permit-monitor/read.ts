export function readPermit(tenant: string) {
  return fetch("/permits/status", { method: "GET", headers: { "X-Read-Tenant": tenant } });
}
