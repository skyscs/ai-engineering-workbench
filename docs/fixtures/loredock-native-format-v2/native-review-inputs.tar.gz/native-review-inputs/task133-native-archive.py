from pathlib import Path
import json
base = Path('/home/toshiba/aew')
helper = base / 'task128-kernel-archive.py'
exec(helper.read_text().split("for name in ['core', 'browser', 'crash', 'interruption']:")[0])
repo = base / 'worktrees/task133-native-context-v2'
out = repo / 'docs/fixtures/loredock-native-format-v2'
assert not (out / 'records.json').exists()
records = {'schemaVersion': 'ordinary-native-format-v2/1', 'base': 'd43cb05611fe41dea1107404cb6448441d18a0c5',
    'baselineCode': '9890186', 'implementationCode': '451e7bb', 'realModelCalls': 0, 'controlledRuntimeCalls': 1,
    'reservedFamilyReads': 0, 'resourceQualification': False, 'trees': [], 'logs': []}
for name in ['native-v1-first', 'native-v1-first-inputs', 'native-v2-first', 'native-v2-first-inputs', 'native-retention', 'native-tests-first-inputs']:
    tree(name, base / ('task133-' + name))
for file in sorted(base.glob('task133-*.log')):
    if file.name not in ['task133-native-archive-first.log', 'task133-native-static-first.log']:
        log(file.stem.removeprefix('task133-'), file)
for event in ['push', 'pr']:
    log('accepted-size-diagnosis-ci-' + event, base / ('task132-native-size-ci-' + event + '.log'))
inputs = base / 'task133-native-review-inputs'; inputs.mkdir()
for file in [helper, Path(__file__), base / 'task133-native-static.py', base / 'task133-native-retain.py',
             base / 'task133-native-v1-first-launch.py', base / 'task133-native-v2-first-launch.py',
             base / 'task133-integration-handoff.json', base / 'task132-integration-handoff.json']:
    (inputs / file.name).write_bytes(file.read_bytes())
tree('native-review-inputs', inputs)
records['retention'] = json.loads((base / 'task133-native-retention/result.json').read_bytes())
(out / 'records.json').write_text(json.dumps(records, indent=2) + '\n')
print(json.dumps({'trees': len(records['trees']), 'entries': sum(row['entries'] for row in records['trees']),
    'logs': len(records['logs']), 'resourceQualification': False}, indent=2))
