"""Verify stopped copies, exact original bytes, prompt versions and first observations."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import sqlite3
import subprocess

base = Path('/home/toshiba/aew')
roots = [base / 'task133-native-v1-first', base / 'task133-native-v2-first']
out = base / 'task133-native-retention'
out.mkdir()
read = lambda file: json.loads(file.read_bytes())
sha = lambda raw: hashlib.sha256(raw).hexdigest()
encode = lambda value: json.dumps(value, ensure_ascii=False, separators=(',', ':')).encode()
def inventory(directory):
    found = {}
    for parent, dirs, files in os.walk(directory, followlinks=False):
        for name in sorted(dirs + files):
            file = Path(parent) / name
            if file.is_symlink(): found[str(file.relative_to(directory))] = {'target': os.readlink(file)}
            elif file.is_file():
                raw = file.read_bytes()
                found[str(file.relative_to(directory))] = {'bytes': len(raw), 'sha256': sha(raw)}
    return found
before = {root.name: inventory(root) for root in roots}
source = read(roots[0] / 'run/inputs.json')
old_execution = read(base / 'task131-history-first-inputs/execution.json')
old_sources = read(base / 'task131-history-first/run/sources.json')
legacy_item_raw = (roots[0] / 'run/complete-v1-item.json').read_bytes()
legacy_item = json.loads(legacy_item_raw)
report = {'catalogs': [], 'originalChecks': 0, 'sourceFiles': 0, 'gitIdentities': 0,
          'httpResponses': 0, 'sessionRedactions': 0, 'expandedByteParity': 0,
          'resourceQualification': False, 'realModelCalls': 0, 'controlledRuntimeCalls': 1, 'reservedFamilyReads': 0}
env = {'PATH': '/usr/bin:/bin', 'LC_ALL': 'C', 'GIT_CONFIG_NOSYSTEM': '1', 'GIT_CONFIG_GLOBAL': '/dev/null', 'GIT_OPTIONAL_LOCKS': '0'}
for folder, corpus, sources in [(roots[0] / 'run/sources', source['corpus'], source['sources']),
                               (base / 'task131-history-first/run/sources', old_execution['corpus'], old_sources)]:
    for name, files in corpus.items():
        directory = folder / name
        for key, ref in [('revision', 'HEAD'), ('tree', 'HEAD^{tree}')]:
            assert subprocess.check_output(['/usr/bin/git', 'rev-parse', ref], cwd=directory, env=env, text=True).strip() == sources['revisions'][name][key]
        assert not subprocess.check_output(['/usr/bin/git', 'status', '--porcelain'], cwd=directory, env=env)
        report['gitIdentities'] += 1
        for file, text in files.items():
            raw = (directory / file).read_bytes()
            original = next(row for row in sources['originals'] if row['source'] == name and row['path'] == file)
            assert raw == text.encode() and len(raw) == original['bytes'] and sha(raw) == original['sha256']
            report['sourceFiles'] += 1
for root in roots:
    owner, result = read(root / 'result.json'), read(root / 'run/result.json')
    assert owner['reason'] == 'completed' and owner['driverExit']['exit'] == 0
    assert owner['errors'] == owner['survivors'] == result['errors'] == []
    assert set(owner['observedCatalogRoots']) == set(owner['catalogRoots'])
    for relative in owner['catalogRoots']:
        original, copied = root / relative, out / root.name / relative
        copied.parent.mkdir(parents=True, exist_ok=True)
        shutil.copytree(original, copied)
        assert inventory(original) == inventory(copied)
        db = sqlite3.connect('file:' + str(copied / 'loredock.db') + '?mode=ro', uri=True)
        db.row_factory = sqlite3.Row
        try:
            assert [tuple(row) for row in db.execute('PRAGMA integrity_check')] == [('ok',)]
            assert not list(db.execute('PRAGMA foreign_key_check'))
            rows = list(db.execute('SELECT a.*,w.preparationId,w.contextHash,w.reviewedHash,w.witness,w.witnessBytes,w.purged FROM answer_attempts a JOIN answer_witnesses w ON w.answerId=a.id'))
            assert len(rows) == db.execute('SELECT count(*) FROM answer_attempts').fetchone()[0]
            purged = 0
            for row in rows:
                if row['purged']:
                    purged += 1
                    assert row['context'] is None and row['witness'] is None and row['result'] is None and row['witnessBytes'] == 0
                    continue
                assert row['status'] == 'succeeded'
                context, witness = json.loads(row['context']), json.loads(row['witness'])
                assert sha(row['context'].encode()) == row['contextHash']
                assert len(row['witness'].encode()) == row['witnessBytes']
                assert sha(encode([witness['compositionVersion'], row['context'], row['witness']])) == row['reviewedHash']
                assert sha(encode({'preparationId': row['preparationId'], 'reviewedHash': row['reviewedHash']})) == row['payloadHash']
                assert sha(encode({key: value for key, value in context.items() if key != 'inputHash'})) == context['inputHash'] == row['inputHash']
                assert row['promptVersion'] == witness['promptVersion']
                assert sha(witness['prompt'].encode()) == witness['promptHash']
                assert [value[0] for value in db.execute('SELECT sourceId FROM answer_sources WHERE answerId=? ORDER BY sourceId', (row['id'],))] == witness['sourceIds']
                version = 1 if witness['promptVersion'] == 'loredock-prepared-answer-v1' else 2
                corpus, sources = (old_execution['corpus'], old_sources) if version == 1 else (source['corpus'], source['sources'])
                for span in context['spans']:
                    text = corpus[span['sourceName']][span['path']]
                    assert span['text'] == '\n'.join(text.splitlines()[span['startLine'] - 1:span['endLine']])
                    assert span['revision'] == sources['revisions'][span['sourceName']]['revision']
                    report['originalChecks'] += 1
                item = witness['compact']['item']
                assert item['schemaVersion'] == 'native-question-item/' + str(version)
                if version == 2:
                    comparisons = context['interfaces']['comparisons']
                    assert set(item) == set(legacy_item) - {'lexicalInputHash'}
                    expanded = {key: item.get(key) for key in legacy_item}
                    expanded.update(schemaVersion='native-question-item/1', lexicalInputHash=context['inputHash'])
                    expanded['duplicateClues'] = [{'legacyId': comparisons[a]['id'], 'nativeEdge': b} for a, b in item['duplicateClues']]
                    expanded['edges'] = json.loads(json.dumps(item['edges']))
                    for edge in expanded['edges']:
                        if isinstance(edge[8], dict) and 'legacyHeader' in edge[8]: edge[8] = comparisons[edge[8]['legacyHeader']]['headerCheck']
                    assert encode(expanded) == legacy_item_raw
                    assert len(encode(comparisons + [item])) == 8081
                    report['expandedByteParity'] += 1
            report['catalogs'].append({'root': root.name, 'relative': relative, 'rows': len(rows), 'purged': purged, 'integrity': 'ok'})
        finally: db.close()
    for events in root.rglob('requests.jsonl'):
        requests, responses = {}, set()
        for row in map(json.loads, events.read_text().splitlines()):
            key = row['id']
            if row['event'] == 'request':
                assert key not in requests
                requests[key] = row
            else:
                assert row['event'] == 'response' and key in requests and key not in responses
                responses.add(key); raw = (events.parent / (key + '.json')).read_bytes()
                if requests[key]['route'] == '/session':
                    assert json.loads(raw)['token'] == '[removed-session-token]'
                    report['sessionRedactions'] += 1
                else: assert len(raw) == row['bytes']
                report['httpResponses'] += 1
        assert set(requests) == responses
    assert inventory(root) == before[root.name]
result = read(roots[1] / 'run/result.json')
assert result['retainedInputsUnchanged'] and result['controlledRuntimeCalls'] == 1
report['rawEntries'] = {name: len(entries) for name, entries in before.items()}
report['rawUnchanged'] = True
report['observations'] = []
for monitor in roots[1].rglob('memory-timer.jsonl'):
    rows = [json.loads(line) for line in monitor.read_text().splitlines()]
    report['observations'].append({'path': str(monitor.relative_to(roots[1])),
       'maxRawGapMs': max(row['gapMs'] for row in rows), 'maxSampledHeapBytes': max(row['heapUsed'] for row in rows)})
(out / 'raw-inventory.json').write_text(json.dumps(before, indent=2) + '\n')
(out / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
