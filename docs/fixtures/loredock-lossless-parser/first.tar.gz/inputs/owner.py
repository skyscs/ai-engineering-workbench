from pathlib import Path
import hashlib, json, os, re, resource, signal, subprocess, tarfile, time

repo = Path('/home/toshiba/aew/worktrees/task139-lossless-wire')
root = Path('/home/toshiba/aew/task139-lossless-first')
root.mkdir()  # Preserve the first attempt, including any failure.
node = Path('/home/toshiba/aew/toolchain/node-v22.23.2-linux-x64/bin/node')
inputs = root / 'inputs'; inputs.mkdir()
files = []
for directory in ['apps/loredock/src', 'apps/loredock/dist', 'apps/loredock/runtime',
                  'scripts/loredock-lossless-parser', 'apps/loredock/tests/fixtures/parser-transport-reference']:
    for source in sorted((repo / directory).rglob('*')):
        if not source.is_file(): continue
        name = str(source.relative_to(repo)); raw = source.read_bytes()
        target = inputs / name; target.parent.mkdir(parents=True, exist_ok=True); target.write_bytes(raw)
        files.append({'path': name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
owner = Path(__file__).read_bytes(); (inputs / 'owner.py').write_bytes(owner)
assert not subprocess.check_output(['git', 'status', '--porcelain=v1'], cwd=repo)
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
archive = repo / 'docs/fixtures/loredock-parser-transport/first.tar.gz'
expected = re.search(r"sourceArchiveSha256: '([a-f0-9]{64})'", (repo / 'scripts/loredock-lossless-parser/plan.mjs').read_text()).group(1)
assert hashlib.sha256(archive.read_bytes()).hexdigest() == expected
original = root / 'original'; original.mkdir()
originals = []
with tarfile.open(archive, 'r:gz') as stored:
    for member in stored.getmembers():
        relative = Path(member.name)
        assert member.isfile() and not relative.is_absolute() and '..' not in relative.parts
        raw = stored.extractfile(member).read(); target = original / relative
        target.parent.mkdir(parents=True, exist_ok=True); target.write_bytes(raw)
        originals.append({'path': member.name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
command = [str(node), 'scripts/loredock-lossless-parser/compare.mjs', str(root / 'run'), str(original)]
(root / 'execution.json').write_text(json.dumps({'head': head, 'command': command, 'cwd': str(repo),
    'nodeSha256': hashlib.sha256(node.read_bytes()).hexdigest(), 'files': files, 'originals': originals,
    'sourceArchiveSha256': expected, 'ownerSha256': hashlib.sha256(owner).hexdigest(),
    'resourceQualification': False, 'modelCalls': 0}, indent=2) + '\n')
env = os.environ.copy(); env['PATH'] = str(node.parent) + ':/home/toshiba/node-v18.20.2-linux-x64/bin:/usr/bin:/bin'
started = time.monotonic(); timed_out = False; before = resource.getrusage(resource.RUSAGE_CHILDREN)
with (root / 'stdout.log').open('xb') as stdout, (root / 'stderr.log').open('xb') as stderr:
    child = subprocess.Popen(command, cwd=repo, env=env, stdout=stdout, stderr=stderr, start_new_session=True)
    try: code = child.wait(timeout=60)
    except subprocess.TimeoutExpired:
        timed_out = True; os.killpg(child.pid, signal.SIGTERM)
        try: code = child.wait(timeout=10)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid, signal.SIGKILL); code = child.wait()
after = resource.getrusage(resource.RUSAGE_CHILDREN)
for entry in files:
    assert hashlib.sha256((repo / entry['path']).read_bytes()).hexdigest() == entry['sha256']
for entry in originals:
    assert hashlib.sha256((original / entry['path']).read_bytes()).hexdigest() == entry['sha256']
assert hashlib.sha256(archive.read_bytes()).hexdigest() == expected
result = {'exitCode': code, 'timedOut': timed_out, 'wallMs': (time.monotonic()-started)*1000,
    'childUserSeconds': after.ru_utime-before.ru_utime, 'childSystemSeconds': after.ru_stime-before.ru_stime,
    'childHighWaterRssKiB': after.ru_maxrss,
    'observer': 'Complete child exit and kernel diagnostics only; no startup, event-loop or aggregate heap qualification.'}
(root / 'owner.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
