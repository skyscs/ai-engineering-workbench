import type { CatalogStore } from '../src/store.js';
import type { DatabaseSync } from 'node:sqlite';

/** Remove schema-11 additions only from owned fixtures without prepared answers. */
export function removeAnswerWitnessSchema(db: DatabaseSync) {
  if (db.prepare('PRAGMA user_version').get()!.user_version !== 11) return;
  if (db.prepare('SELECT count(*) AS n FROM answer_witnesses').get()!.n !== 0
    || db.prepare("SELECT count(*) AS n FROM answer_attempts WHERE inputKind!='legacy'").get()!.n !== 0) throw new Error('Legacy fixtures must have no prepared answers.');
  for (const name of ['answer_input_kind_immutable','prepared_answer_identity','prepared_answer_replace','prepared_answer_context',
    'prepared_sources_insert','prepared_sources_update','prepared_sources_delete']) db.exec('DROP TRIGGER ' + name);
  db.exec('DROP TABLE answer_witnesses; DROP INDEX answer_source_purge; ALTER TABLE answer_attempts DROP COLUMN inputKind; PRAGMA user_version=10;');
}

/** Remove schema-10 additions only in empty-native-store owned legacy fixtures. */
export function removeNativeReceiptSchema(db: DatabaseSync) {
  removeAnswerWitnessSchema(db);
  db.exec('DROP TABLE IF EXISTS catalog_identity; PRAGMA user_version=9;');
}

/** Recreate schema-8 literal storage only in owned migration fixtures. */
export function removeExternalSearchSchema(db: DatabaseSync) {
  removeNativeReceiptSchema(db);
  const settings = db.prepare("SELECT k,v FROM search_config WHERE k<>'version' ORDER BY k").all();
  db.exec(`BEGIN IMMEDIATE;
    CREATE TABLE legacy_test_content AS SELECT rowid,spanId,text FROM search;
    DROP TABLE search;
    DROP VIEW literal_search_content;
    DROP TABLE literal_search_documents;
    CREATE VIRTUAL TABLE search USING fts5(spanId UNINDEXED,text);
    INSERT INTO search(rowid,spanId,text) SELECT rowid,spanId,text FROM legacy_test_content;
    DROP TABLE legacy_test_content;
    PRAGMA user_version=8; COMMIT;`);
  for (const setting of settings) db.prepare('INSERT INTO search(search,rank) VALUES (?,?)').run(setting.k!, typeof setting.v === 'number' ? BigInt(setting.v) : setting.v!);
}

/** Remove only refresh additions from owned test fixtures before legacy migration tests. */
export function removeRefreshSchema(store: CatalogStore) {
  removeReconciliationSchema(store);
  store.db.exec(`ALTER TABLE files DROP COLUMN extractionHash;
    ALTER TABLE files DROP COLUMN reusedFromFileId;
    ALTER TABLE files DROP COLUMN gitReadAttempts;
    ALTER TABLE files DROP COLUMN cacheRejected;
    ALTER TABLE builds DROP COLUMN baselineBuildId;
    ALTER TABLE builds DROP COLUMN refreshVersion;`);
}

/** Remove only schema 6 additions from owned legacy migration fixtures. */
export function removeReconciliationSchema(store: CatalogStore) {
  removeOnboardingSchema(store);
  store.db.exec('DROP TABLE correction_reapplications;');
}

/** Remove only schema 7 additions from owned legacy migration fixtures. */
export function removeOnboardingSchema(store: CatalogStore) {
  removeCodeAnalysisSchema(store);
  store.db.exec('DROP TABLE source_registrations; ALTER TABLE builds DROP COLUMN allocation;');
}

/** Remove only schema 8 additions from owned legacy migration fixtures. */
export function removeCodeAnalysisSchema(store: CatalogStore) {
  removeExternalSearchSchema(store.db);
  store.db.exec('DROP TRIGGER code_analysis_boundary; DROP TABLE code_analysis_files; DROP TABLE code_analysis_sources; DROP TABLE code_analyses;');
}
