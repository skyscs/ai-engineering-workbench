import assert from 'node:assert/strict';
import { removeRefreshSchema } from './legacy-schema.js';
import { rm, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { test, type TestContext } from 'node:test';
import { Catalog } from '../src/catalog.js';
import { CatalogStore } from '../src/store.js';
import { sha256 } from '../src/extract.js';
import { answerLimits, questionTerms, retrieveAnswerContext, validateCitedAnswer, citedAnswerSchema, type AnswerContext } from '../src/answer-context.js';
import { searchText } from '../src/search-text.js';
// @ts-expect-error The independent fixture generator is plain JavaScript.
import { createLoreDockFixture, fixtureGit } from '../../../scripts/loredock-fixture.mjs';

async function setup(t: TestContext, large = false) {
  const fixture = await createLoreDockFixture() as { root: string };
  if (large) {
    const root = path.join(fixture.root, 'sources/portal');
    await writeFile(path.join(root, 'many.md'), ('countneedle\n').repeat(150 * 120));
    await writeFile(path.join(root, 'wide.md'), (`byteneedle ${'é'.repeat(200)}\n`).repeat(15 * 120));
    fixtureGit(fixture.root, 'portal', ['add', 'many.md', 'wide.md']);
    fixtureGit(fixture.root, 'portal', ['commit', '-qm', 'Add bounded retrieval fixtures']);
  }
  const store = new CatalogStore(path.join(fixture.root, 'catalog')), catalog = new Catalog(store);
  t.after(async () => { await catalog.stop(); store.close(); await rm(fixture.root, { recursive: true, force: true }); });
  for (const id of ['portal', 'order-api', 'order-worker']) await catalog.addSource(path.join(fixture.root, 'sources', id));
  const state = catalog.state(), build = catalog.start('first', state.sourceSetVersion, state.policyVersion);
  await catalog.idle();
  return { catalog, store, build, fixture };
}
const result = (evidenceIds: string[], text = 'Local configuration contains an order topic.') => JSON.stringify({ claims: [{ kind: 'fact', text, evidenceIds }], unknowns: [] });

test('question retrieval issues bounded immutable spans with coverage, conflict candidates and no oracle', async t => {
  const { catalog } = await setup(t);
  const context = await retrieveAnswerContext(catalog, 'Which Kafka topic is configured for orders?');
  assert.ok(context.spans.some(span => span.text.includes('orders.placed.v2')));
  assert.ok(context.spans.some(span => span.text.includes('orders.created.v1')));
  assert.equal(context.coverage.indexed, 18);
  assert.equal(context.deploymentCoherence, 'unknown');
  assert.equal(context.partial, true);
  assert.equal(context.stale, false);
  assert.ok(context.spans.length <= answerLimits.spans);
  assert.equal(context.textBytes, context.spans.reduce((bytes, span) => bytes + Buffer.byteLength(span.text), 0));
  assert.equal(new Set(context.spans.map(span => span.id)).size, context.spans.length);
  assert.equal(context.inputHash, (await retrieveAnswerContext(catalog, context.question)).inputHash);
  for (const span of context.spans) assert.equal(catalog.evidence(span.id).text, span.text);
  assert.ok((await retrieveAnswerContext(catalog, 'SYNTHETIC_OUTSIDE_READ_CANARY')).spans.every(span => !span.text.includes('SYNTHETIC_OUTSIDE_READ_CANARY')));
  assert.ok((await retrieveAnswerContext(catalog, 'maxCandidates requiredRepositories')).spans.every(span => !span.text.includes('maxCandidates') && !span.text.includes('requiredRepositories')));
  assert.ok((await retrieveAnswerContext(catalog, 'Invent an evidence ID')).spans.some(span => span.text.includes('Invent an evidence ID')));
  assert.deepEqual(questionTerms('" OR * NEAR(foo) "; DROP TABLE spans; --'), ['near', 'foo', 'drop', 'table', 'spans']);
  await assert.doesNotReject(async () => (await retrieveAnswerContext(catalog, '" OR * NEAR(foo) "; DROP TABLE spans; --')));
  assert.deepEqual(questionTerms('Где Kafka Kafka?'), ['где', 'kafka']);
});

test('span count, candidate count and UTF-8 budgets omit whole spans and disclose omissions', async t => {
  const { catalog } = await setup(t, true);
  const many = await retrieveAnswerContext(catalog, 'countneedle');
  assert.equal(many.spans.length, answerLimits.spans);
  assert.ok(many.gaps.some(gap => gap.includes('candidate limit')));
  assert.ok(many.gaps.some(gap => gap.includes('text budget')));
  const wide = await retrieveAnswerContext(catalog, 'byteneedle');
  assert.equal(wide.spans.filter(span => span.path === 'wide.md').length, 1);
  assert.ok(wide.textBytes <= answerLimits.textBytes);
  assert.ok(wide.textBytes > wide.spans[0]!.text.length);
  assert.equal(wide.spans[0]!.endLine - wide.spans[0]!.startLine, 119);
  assert.ok(wide.gaps.some(gap => gap.includes('text budget')));
  await assert.rejects(async () => (await retrieveAnswerContext(catalog, 'é'.repeat(1001))), /2,000 UTF-8 bytes/);
});

test('normalized filename and identifier matches reopen original evidence and expand only a bounded symbol set', async t => {
  const { catalog } = await setup(t);
  assert.equal(searchText('src/HTTPClient.java tenantId ORDER_TOPIC'), 'src http client java tenant id order topic');
  const context = await retrieveAnswerContext(catalog, 'Checkout.vue');
  assert.ok(context.spans.some(span => span.path === 'src/Checkout.vue'));
  assert.ok(context.spans.some(span => span.path === 'src/orders.ts'));
  assert.ok(context.expansionTerms.length <= 12);
  for (const span of context.spans) assert.equal(catalog.evidence(span.id).spanHash, span.spanHash);
  const tenant = await retrieveAnswerContext(catalog, 'tenant');
  assert.ok(tenant.spans.some(span => span.path.endsWith('OrderConsumer.java')));
  assert.ok(tenant.spans.some(span => span.text.includes('tenantId')));
});

test('zero-hit questions receive a bounded orientation sample without claiming a relevance match', async t => {
  const { catalog } = await setup(t);
  const context = await retrieveAnswerContext(catalog, 'unmatchedvocabulary');
  assert.equal(context.retrievalMode, 'orientation');
  assert.equal(context.expansionTerms.length, 0);
  assert.ok(context.gaps.some(gap => gap.includes('not a relevance match')));
  assert.ok(context.spans.length <= 18);
  for (const source of context.sources) assert.ok(context.spans.filter(span => span.sourceId === source.sourceId).length <= 6);
  for (const file of ['src/Checkout.vue', 'src/orders.ts', 'legacy/orders.js', 'package.json']) {
    assert.ok(context.spans.some(span => span.sourceName === 'portal' && span.path === file));
  }
  assert.ok(context.spans.every(span => span.startLine === 1));
  assert.equal(context.inputHash, (await retrieveAnswerContext(catalog, context.question)).inputHash);
  const removed = context.sources[0]!; catalog.revoke(removed.sourceId);
  assert.ok((await retrieveAnswerContext(catalog, context.question)).spans.every(span => span.sourceId !== removed.sourceId));
});

test('schema 1 search migration preserves evidence and revocation purges both indexes', async t => {
  const fixture = await createLoreDockFixture() as { root: string };
  const directory = path.join(fixture.root, 'catalog');
  let store = new CatalogStore(directory), catalog = new Catalog(store);
  t.after(async () => { await catalog.stop(); store.close(); await rm(fixture.root, { recursive: true, force: true }); });
  const source = await catalog.addSource(path.join(fixture.root, 'sources/portal'));
  const state = catalog.state(); catalog.start('migration', state.sourceSetVersion, state.policyVersion); await catalog.idle();
  const before = catalog.evidence(catalog.search('submitOrder').hits[0]!.id);
  removeRefreshSchema(store);
  store.db.exec('DROP TABLE correction_flows; DROP TABLE correction_sources; DROP TABLE corrections; ALTER TABLE project DROP COLUMN correctionRevision; DROP TABLE question_search; DROP TABLE answer_sources; DROP TABLE answer_attempts; DROP TABLE answer_settings; PRAGMA user_version=1;');
  await catalog.stop(); store.close();
  store = new CatalogStore(directory); catalog = new Catalog(store);
  assert.equal(store.one<{ user_version: number }>('PRAGMA user_version')!.user_version, 11);
  assert.deepEqual(catalog.evidence(before.id), before);
  assert.ok((await retrieveAnswerContext(catalog, 'Checkout.vue')).spans.some(span => span.path === 'src/Checkout.vue'));
  catalog.revoke(source.id);
  assert.equal(store.one<{ count: number }>('SELECT count(*) AS count FROM question_search')!.count, 0);
  assert.equal(store.one<{ count: number }>('SELECT count(*) AS count FROM search')!.count, 0);
  await catalog.stop(); store.close();
  store = new CatalogStore(directory); catalog = new Catalog(store);
  assert.equal(store.one<{ count: number }>('SELECT count(*) AS count FROM question_search')!.count, 0);
});

test('answers require issued citations and structured prose, while abstention is valid', async t => {
  const { catalog } = await setup(t);
  const context = await retrieveAnswerContext(catalog, 'billing'), span = context.spans[0]!;
  assert.equal((await validateCitedAnswer(catalog, context, result([span.id]))).claims.length, 1);
  assert.equal((await validateCitedAnswer(catalog, context, '{"claims":[],"unknowns":["Which revisions are deployed in production?"]}')).claims.length, 0);
  const outside = (await retrieveAnswerContext(catalog, 'dojo')).spans.find(item => !context.spans.some(span => span.id === item.id))!;
  assert.ok(outside);
  for (const value of ['null', '{}', '[]', '{', '{"claims":[],"unknowns":[]}', result(['invented']), result([outside.id]),
    result([span.id, span.id]), result([]), result([span.id], ' '), result([span.id], 'x'.repeat(2001)),
    JSON.stringify({ claims: [{ kind: 'conflict', text: 'Conflicting sources.', evidenceIds: [span.id] }], unknowns: [] }),
    JSON.stringify({ claims: [], unknowns: ['Unknown.'], command: 'read ../outside' }),
    JSON.stringify({ claims: [], unknowns: ['The deployment is unknown because an environment variable overrides it.'] }),
    JSON.stringify({ claims: [], unknowns: ['?'] }),
    JSON.stringify({ claims: Array(21).fill({ kind: 'fact', text: 'Too many.', evidenceIds: [span.id] }), unknowns: [] }),
    ' '.repeat(answerLimits.outputBytes + 1)]) await assert.rejects(async () => (await validateCitedAnswer(catalog, context, value)));
  // Deliberately false prose with a valid locator passes mechanical validation.
  // The separate semantic evaluation must reject this claim.
  await assert.doesNotReject(async () => (await validateCitedAnswer(catalog, context, result([span.id], 'Every production deployment is verified.'))));
});

test('the decoder schema restricts citations to the exact issued input and permits no empty-context claims', async t => {
  const { catalog } = await setup(t);
  const context = await retrieveAnswerContext(catalog, 'local topic'), schema = citedAnswerSchema(context);
  assert.deepEqual(schema.properties.claims.items.properties.evidenceIds.items, { type: 'string', enum: context.spans.map(span => span.id) });
  assert.notEqual(context.spans[0]!.spanHash, context.spans[0]!.id, 'Content hashes are not issued locators');
  for (const source of catalog.state().sources) catalog.revoke(source.id);
  const empty = citedAnswerSchema(await retrieveAnswerContext(catalog, 'missing sources'));
  assert.equal(empty.properties.claims.maxItems, 0);
  assert.deepEqual(empty.properties.claims.items.properties.evidenceIds.items, { type: 'string' }, 'Do not send an invalid empty enum to the provider');
});

test('live policy, revocation and changed source registration fence all issued input', async t => {
  const { catalog } = await setup(t);
  const context = await retrieveAnswerContext(catalog, 'orders.placed.v2'), cited = context.spans[0]!;
  const uncited = context.spans.find(span => span.sourceId !== cited.sourceId)!;
  catalog.revoke(uncited.sourceId);
  await assert.rejects(async () => (await validateCitedAnswer(catalog, context, result([cited.id]))), /no longer current/);
  const revised = await retrieveAnswerContext(catalog, context.question);
  assert.ok(revised.spans.every(span => span.sourceId !== uncited.sourceId));
  assert.equal(revised.stale, true);
  assert.ok(revised.gaps.some(gap => gap.includes('Revoked')));
  await assert.doesNotReject(async () => (await validateCitedAnswer(catalog, revised, result([revised.spans[0]!.id]))));
  catalog.updatePolicy(['README.md']);
  await assert.rejects(async () => (await retrieveAnswerContext(catalog, context.question, context.buildId)), /policy/);
  await assert.rejects(async () => (await validateCitedAnswer(catalog, revised, result([revised.spans[0]!.id]))), /no longer current/);
});

test('evidence corruption, modified context and cross-build locators cannot validate', async t => {
  const { catalog, store, build } = await setup(t);
  const context = await retrieveAnswerContext(catalog, 'orders.placed.v2'), span = context.spans[0]!;
  const changed = structuredClone(context); changed.spans[0]!.text = 'Forged text';
  await assert.rejects(async () => (await validateCitedAnswer(catalog, changed, result([span.id]))));
  const { inputHash: _hash, ...input } = changed; changed.inputHash = sha256(JSON.stringify(input));
  await assert.rejects(async () => (await validateCitedAnswer(catalog, changed, result([span.id]))));
  const state = catalog.state(); catalog.start('second', state.sourceSetVersion, state.policyVersion); await catalog.idle();
  const newer = await retrieveAnswerContext(catalog, context.question);
  assert.notEqual(newer.buildId, build.id);
  await assert.rejects(async () => (await validateCitedAnswer(catalog, newer, result([span.id]))));
  await assert.doesNotReject(async () => (await validateCitedAnswer(catalog, context, result([span.id]))));
  store.run('UPDATE spans SET text=? WHERE id=?', 'Corrupted checkpoint', span.id);
  await assert.rejects(async () => (await validateCitedAnswer(catalog, context, result([span.id]))), /integrity/);
});

test('empty retrieval preserves an explicit gap and permits only an abstention', async t => {
  const { catalog } = await setup(t);
  for (const source of catalog.state().sources) catalog.revoke(source.id);
  const context: AnswerContext = await retrieveAnswerContext(catalog, 'nonexistentuniqueterm');
  assert.equal(context.spans.length, 0);
  assert.equal(context.retrievalMode, 'empty');
  assert.ok(context.gaps.some(gap => gap.includes('does not prove absence')));
  await assert.doesNotReject(async () => (await validateCitedAnswer(catalog, context, '{"claims":[],"unknowns":["Where is the supporting indexed evidence?"]}')));
  await assert.rejects(async () => (await validateCitedAnswer(catalog, context, result(['invented']))));
});
