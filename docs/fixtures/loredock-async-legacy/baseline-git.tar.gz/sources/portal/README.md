# Source-only orientation

The portal repository requires a deployment review.
