<script setup lang="ts">
import { requestPermit } from "./request";
const props = defineProps<{ tenant: string; permit: string }>();
const renew = () => requestPermit(props.tenant, props.permit);
</script>
<template><button @click="renew">Request permit</button></template>
