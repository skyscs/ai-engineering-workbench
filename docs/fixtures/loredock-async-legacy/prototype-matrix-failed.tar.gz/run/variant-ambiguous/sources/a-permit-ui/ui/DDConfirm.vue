<script setup lang="ts">
import { requestPermit } from "./request";
const props = defineProps<{ tenant: string; permit: string }>();
const confirm = () => requestPermit(props.tenant, props.permit);
</script>
<template><button @click="confirm">Request permit</button></template>
