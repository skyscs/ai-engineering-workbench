<script setup lang="ts">
import { requestPermit } from "./request";
const props = defineProps<{ tenant: string; permit: string }>();
const retry = () => requestPermit(props.tenant, props.permit);
</script>
<template><button @click="retry">Request permit</button></template>
