export function budgetReference0(value: string) { return fetch("/budget/reference/0", { method: "POST", headers: { "X-Budget-0": value } }); }
export function budgetReference1(value: string) { return fetch("/budget/reference/1", { method: "POST", headers: { "X-Budget-1": value } }); }
export function budgetReference2(value: string) { return fetch("/budget/reference/2", { method: "POST", headers: { "X-Budget-2": value } }); }
export function budgetReference3(value: string) { return fetch("/budget/reference/3", { method: "POST", headers: { "X-Budget-3": value } }); }
export function budgetReference4(value: string) { return fetch("/budget/reference/4", { method: "POST", headers: { "X-Budget-4": value } }); }
