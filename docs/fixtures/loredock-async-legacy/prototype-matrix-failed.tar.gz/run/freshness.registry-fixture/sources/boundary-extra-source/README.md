# Explicit registry change
