export const adapterPadding = 1;
