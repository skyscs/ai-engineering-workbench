from pathlib import Path
import hashlib
import json
import os
import shutil
import sqlite3
import subprocess

base=Path('/home/toshiba/aew');root=base/'task128-execution-adapter-first';run=root/'run'
output=base/'task128-execution-adapter-retention';output.mkdir()
sha=lambda raw:hashlib.sha256(raw).hexdigest()
read=lambda file:json.loads(file.read_text())
def inventory(directory):
    result={}
    for parent,dirs,files in os.walk(directory,followlinks=False):
        for name in sorted(dirs+files):
            p=Path(parent)/name;k=str(p.relative_to(directory))
            if p.is_symlink():result[k]={'target':os.readlink(p)}
            elif p.is_file():
                raw=p.read_bytes();result[k]={'bytes':len(raw),'sha256':sha(raw)}
    return result
before=inventory(root);owner=read(root/'result.json');result=read(run/'result.json')
assert owner['reason']=='completed' and owner['driverExit']['exit']==0 and owner['errors']==[] and owner['survivors']==[]
assert result['errors']==[] and result['fullMatrix'] is False and len(result['cases'])==7
assert result['resourceQualification'] is False and result['modelCalls']==0 and result['reservedFamilyReads']==0
assert len(owner['catalogRoots'])==31 and len(owner['observedCatalogRoots'])==19
report={'catalogs':[],'sourceGitIdentities':0,'sourceFiles':0,'httpResponses':0,'redactedSessions':0,
        'failedFreshProofs':0,'controlledCalls':0,'resourceQualification':False,'modelCalls':0,'reservedFamilyReads':0}
env={**os.environ,'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null','GIT_OPTIONAL_LOCKS':'0'}
for file in run.rglob('sources.json'):
    sources=read(file)
    for name,identity in sources['revisions'].items():
        directory=Path(next(p for p in sources['paths'] if Path(p).name==name));assert directory.is_relative_to(root)
        for key,ref in [('revision','HEAD'),('tree','HEAD^{tree}')]:
            assert subprocess.check_output(['git','-c','core.hooksPath=/dev/null','-c','core.fsmonitor=false','rev-parse',ref],cwd=directory,env=env,text=True).strip()==identity[key]
        assert not subprocess.check_output(['git','-c','core.hooksPath=/dev/null','-c','core.fsmonitor=false','status','--porcelain'],cwd=directory,env=env)
        report['sourceGitIdentities']+=1
    for original in sources['originals']:
        directory=Path(next(p for p in sources['paths'] if Path(p).name==original['source']));raw=(directory/original['path']).read_bytes()
        assert len(raw)==original['bytes'] and sha(raw)==original['sha256'];report['sourceFiles']+=1
for file in run.rglob('requests.jsonl'):
    requests={};responses=set()
    for row in map(json.loads,file.read_text().splitlines()):
        key=row['id'];assert row['event']!='failure'
        if row['event']=='request':assert key not in requests;requests[key]=row
        else:
            assert row['event']=='response' and key in requests and key not in responses;responses.add(key)
            raw=(file.parent/(key+'.json')).read_bytes()
            if requests[key]['route']=='/session':assert json.loads(raw)['token']=='[removed-session-token]';report['redactedSessions']+=1
            else:assert len(raw)==row['bytes']
            assert row['status']<400;report['httpResponses']+=1
    assert set(requests)==responses
for file in run.rglob('runtime-stats.json'):
    value=read(file);assert value['prepares']==value['closed'];report['controlledCalls']+=value['calls']
proofs={}
for file in run.rglob('failed-fresh-setup.json'):
    value=read(file);assert value['attempts']==value['witnesses']==value['controlledCalls']==value['preparationRequests']==value['expectedRows']==0
    assert value['resultSha256']==sha((file.parent/'result.json').read_bytes())
    failed=read(file.parent/'result.json');assert len(failed['errors'])==1 and failed['errors'][0]['code']=='INCOMPLETE_CODE_ANALYSIS'
    if value['kind']=='oracle':assert failed['preparations']==0 and failed['passed'] is False
    if value['kind']=='history':assert failed['admissions']==[] and failed['returnResultOnFailure'] is True
    proofs[value['data']]=value;report['failedFreshProofs']+=1
for file in run.glob('*/run/matrix/*/case-assessment.json'):
    value=read(file);assert value['errors']==[] and value['safeToContinue'] is True and value['status'] in ['failed','incomplete']
    for data,proof in value['failedSetups'].items():assert proofs[proof['data']]==proof
positive=run/'positive/run/matrix';cold=read(positive/'R01-representative-cold/cold/result.json')
warm=read(positive/'R03-fixed-warm-flow/representative/result.json');diagnostic=read(positive/'R15-accounting/representative-worker/result.json')
for value in [cold['assessment'],diagnostic['assessment'],*[row['sourceAssessment'] for row in warm['repetitions']]]:
    assert [row['id'] for row in value['requiredOriginals']]==['vue','request','write']
assert len(warm['repetitions'])==3 and diagnostic['outputParity'] is True and diagnostic['storedByteParity'] is True
note=result['note'];assert note['passed'] is True and note['note']['provenance']=='human' and note['note']['verification']=='unverified'
for original in sorted(run.rglob('loredock.db')):
    relative=original.parent.relative_to(root);assert str(relative) in owner['catalogRoots']
    copied=output/relative;copied.parent.mkdir(parents=True,exist_ok=True);shutil.copytree(original.parent,copied)
    assert inventory(original.parent)==inventory(copied)
    db=sqlite3.connect('file:'+str(copied/'loredock.db')+'?mode=ro',uri=True)
    try:
        assert db.execute('PRAGMA integrity_check').fetchall()==[('ok',)] and db.execute('PRAGMA foreign_key_check').fetchall()==[]
        rows=db.execute('SELECT w.contextHash,w.witness,w.witnessBytes,a.context FROM answer_witnesses w JOIN answer_attempts a ON a.id=w.answerId').fetchall()
        for context_hash,witness,witness_bytes,context in rows:assert sha(context.encode())==context_hash and len(witness.encode())==witness_bytes
        attempts=db.execute('SELECT count(*) FROM answer_attempts').fetchone()[0]
        if str(original.parent) in proofs:assert attempts==0 and rows==[]
        report['catalogs'].append({'source':str(original.parent),'copy':str(copied),'integrity':'ok','foreignKeys':[], 'attempts':attempts,'witnesses':len(rows)})
    finally:db.close()
assert len(report['catalogs'])==19 and report['failedFreshProofs']==12 and report['controlledCalls']==4
assert inventory(root)==before
report.update(rawInputsUnchanged=True,entries=len(before),requiredOriginalReviews=5,sourceOnlySetup=True,unverifiedNoteSetup=True)
(output/'result.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({**report,'catalogs':len(report['catalogs'])},indent=2))
