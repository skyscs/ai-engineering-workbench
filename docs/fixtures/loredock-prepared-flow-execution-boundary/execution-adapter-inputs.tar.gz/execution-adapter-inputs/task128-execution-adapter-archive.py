from pathlib import Path
import json

base=Path('/home/toshiba/aew');helper=base/'task128-kernel-archive.py'
exec(helper.read_text().split("for name in ['core', 'browser', 'crash', 'interruption']:")[0])
repo=base/'worktrees/task128-execution-boundary';out=repo/'docs/fixtures/loredock-prepared-flow-execution-boundary'
assert not (out/'records.json').exists()
records={'schemaVersion':'prepared-flow-execution-adapter-development/1','resourceQualification':False,'modelCalls':0,
         'reservedFamilyReads':0,'trees':[],'logs':[],'base':'d61149ac354265190deb9ecfb99c90ff67bd4f25'}
for name in ['execution-adapter-first','execution-adapter-first-inputs','execution-adapter-retention']:tree(name,base/('task128-'+name))
for name in ['execution-adapter-first','execution-adapter-tests-first','execution-adapter-install','execution-adapter-build','execution-adapter-seal','execution-adapter-retention']:
    log(name,base/('task128-'+name+'.log'))
inputs=base/'task128-execution-adapter-inputs';inputs.mkdir()
for source in sorted((repo/'scripts/loredock-prepared-flow').glob('*')):
    if source.is_file() and source.suffix in ['.mjs','.py']:(inputs/source.name).write_bytes(source.read_bytes())
for source in [repo/'scripts/tests/loredock-matrix-adapter.test.mjs',helper,base/'task128-execution-adapter-retention.py',Path(__file__)]:
    (inputs/source.name).write_bytes(source.read_bytes())
tree('execution-adapter-inputs',inputs)
records['retention']=json.loads((base/'task128-execution-adapter-retention/result.json').read_text())
(out/'records.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps({'trees':len(records['trees']),'logs':len(records['logs'])},indent=2))
