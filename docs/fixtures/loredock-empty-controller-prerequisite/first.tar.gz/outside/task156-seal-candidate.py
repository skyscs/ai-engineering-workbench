"""Seal the reviewed Task 156 candidate without starting the prerequisite."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import uuid

root = Path("/home/toshiba/aew")
checkout = root / "worktrees/task156-empty-controller-prerequisite"
def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module
probe = load(checkout / "scripts/loredock-empty-controller-prerequisite/probe.py", "sealing_probe")
acquisition = load(checkout / "scripts/loredock-user-namespace-prerequisite/probe.py", "sealing_acquisition")
support = load(checkout / "scripts/loredock-namespace-prerequisite/probe.py", "sealing_support")
assert not subprocess.check_output(["git", "status", "--porcelain"], cwd=checkout).strip()
head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=checkout, text=True).strip()
review = json.loads((root / "task156-local-check-review.json").read_text())
assert review["fullTests"] == 1207 and review["failures"] == review["cancelled"] == 0
for row in review["sources"]:
    assert acquisition.digest(checkout / row["path"]) == row["sha256"]
inputs = root / "task156-direct-birth-inputs"
inputs.mkdir(mode=0o700)
originals = {"acquisition": checkout / "scripts/loredock-user-namespace-prerequisite/probe.py",
             "support": checkout / "scripts/loredock-namespace-prerequisite/probe.py",
             "validator": checkout / "scripts/loredock-user-service-ownership/assess.py",
             "payload": checkout / "scripts/loredock-namespace-prerequisite/payload.py",
             **{name: checkout / "scripts/loredock-direct-birth-prerequisite" / filename
                for name, filename in (("nativeSource", "native.c"), ("capture", "capture.py"), ("protocol", "protocol.py"))}}
for name, filename in probe.LOCAL.items():
    if name == "native":
        continue
    target = inputs / filename
    if name == "canary":
        target.write_bytes(b"Task 156 immutable read-only sandbox canary.\n")
    else:
        shutil.copyfile(originals.get(name, checkout / "scripts/loredock-empty-controller-prerequisite" / filename), target)
command = ["/usr/bin/cc", *probe.BUILD_FLAGS, str(inputs / "native.c"), "-o", str(inputs / "native")]
compiled = subprocess.run(command, capture_output=True, timeout=30, env={"PATH": "/usr/bin:/bin", "LANG": "C.UTF-8"})
with (root / "task156-native-sealed-build.log").open("xb") as stream:
    stream.write(compiled.stdout + compiled.stderr)
assert compiled.returncode == 0
previous = json.loads((root / "task155-direct-birth-inputs/manifest.json").read_text())
assert acquisition.digest(inputs / "native") == previous["files"]["native"]["sha256"]
dependencies = subprocess.check_output(["/usr/bin/cc", *probe.BUILD_FLAGS, "-M", str(inputs / "native.c")], text=True, env={"PATH": "/usr/bin:/bin", "LANG": "C.UTF-8"})
headers = shlex.split(dependencies.replace("\\\n", "").split(":", 1)[1])
build_inputs = []
for name in ("cc1", "as", "ld"):
    value = subprocess.check_output(["/usr/bin/cc", "-print-prog-name=" + name], text=True).strip()
    headers.append(value if Path(value).is_absolute() else shutil.which(value))
for filename in sorted(set(headers)):
    path = Path(filename).resolve(strict=True)
    build_inputs.append({"path": filename, "resolved": str(path), "bytes": path.stat().st_size,
                         "sha256": hashlib.sha256(path.read_bytes()).hexdigest()})
build = {"candidateHead": head, "command": command, "exitCode": 0, "nativeExecuted": False,
         "compilerVersion": subprocess.check_output(["/usr/bin/cc", "--version"], text=True),
         "inputs": build_inputs, "binarySha256": acquisition.digest(inputs / "native"),
         "limits": "Observed compiler/header/linker inputs and final executable are pinned; the complete operating system is not sealed."}
acquisition.retain(root / "task156-native-build-record.json", build)
run_id = str(uuid.uuid4())
manifest = {"schemaVersion": "loredock-empty-controller-prerequisite/1", "contractSha256": acquisition.CONTRACT,
            "runId": run_id, "unit": "loredock-task156-" + run_id + ".service",
            "uid": os.getuid(), "gid": os.getgid(), "output": str(root / "task156-direct-birth-first"),
            "bounds": dict(acquisition.BOUNDS, clone3Attempts=1, nativeWallSeconds=4, nativeCaptureSeconds=5),
            "candidateHead": head, "buildCommand": command,
            "buildRecordSha256": acquisition.digest(root / "task156-native-build-record.json"), "files": {}}
for name in set(probe.FIXED) | set(probe.LOCAL):
    path = Path(probe.FIXED[name]) if name in probe.FIXED else inputs / probe.LOCAL[name]
    resolved = path.resolve(strict=True)
    manifest["files"][name] = {"path": str(path), "resolved": str(resolved), "sha256": acquisition.digest(resolved)}
path = inputs / "manifest.json"
manifest["serviceCommandTemplate"] = support.service_command(manifest, path, "MANIFEST_SHA256")
manifest["sandboxCommand"] = support.sandbox_command(manifest)
acquisition.retain(path, manifest)
sha = acquisition.digest(path)
assert probe.load_manifest(path, sha, acquisition) == manifest
acquisition.retain(root / "task156-first-expectations.json", {
    "candidateHead": head, "manifestSha256": sha, "attempt": 1,
    "expected": ["Fresh exact service ownership", "One real clone3 with requested flags",
                 "Direct child placement and identity independently retained before payload permit",
                 "All unchanged namespace/payload predicates", "Actual direct-child normal wait",
                 "Terminal owned target and service empty without forced cleanup", "Pinned inputs unchanged"],
    "missingCapability": "Ends candidate path; no fallback or environment changes.",
    "executorQualified": False, "resourceQualification": False, "liveAttemptStarted": False})
acquisition.retain(root / "task156-launch-seal.json", {"manifest": str(path), "sha256": sha,
    "candidateHead": head, "firstOutput": manifest["output"], "unit": manifest["unit"], "runId": run_id,
    "status": "Prepared and verified; not launched.", "consumedTask152And154And155Unchanged": True})
for item in inputs.iterdir():
    item.chmod(0o555 if item.name == "native" else 0o600 if item.name == "canary" else 0o444)
inputs.chmod(0o500)
print(json.dumps({"manifestSha256": sha, "candidateHead": head, "unit": manifest["unit"], "buildInputs": len(build_inputs)}))
