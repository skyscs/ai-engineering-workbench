from pathlib import Path
import hashlib
import json
import shutil
import subprocess

helper = Path('/home/toshiba/aew/task128-kernel-archive.py')
exec(helper.read_text().split("for name in ['core', 'browser', 'crash', 'interruption']:")[0])
repo = base / 'worktrees/task136-file-parser'
out = repo / 'docs/fixtures/loredock-file-parser'
records = json.loads((out / 'records.json').read_bytes())
execution = json.loads((base / 'task136-parser-first/execution.json').read_bytes())
names = ['apps/loredock/src/file-parser-owner.ts', 'apps/loredock/dist/file-parser-owner.js']
delta = {name: {'before': execution['modules'][name],
                'after': {'bytes': (repo / name).stat().st_size, 'sha256': sha((repo / name).read_bytes())}} for name in names}
assert all(row['before'] != row['after'] for row in delta.values())
final = base / 'task136-parser-deadline-final-inputs'
final.mkdir()
for name in names + ['apps/loredock/tests/file-parser.test.ts']:
    target = final / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(repo / name, target)
shutil.copy2(Path(__file__), final / Path(__file__).name)
record = {'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip(),
          'reason': 'Recheck absolute deadlines after identity initialization and around reply validation; do not rely only on timers.',
          'resourceQualification': False, 'resourceObservationRerun': False, 'implementationDelta': delta}
(final / 'correction.json').write_text(json.dumps(record, indent=2) + '\n')
(final / 'owner.patch').write_bytes(subprocess.check_output(['git', 'diff', '5036ad57dbe39cd9dd66de7b44ba624ec11510e8', '--', names[0]], cwd=repo))
tree('deadline-first-inputs', base / 'task136-late-deadline-first-inputs')
tree('deadline-final-inputs', final)
present = {row['path'] for row in records['logs']}
for p in sorted(base.glob('task136-*.log')):
    if p.stem + '.log.gz' not in present:
        log(p.stem, p)
records['postObservationCorrection'] = record
(out / 'records.json').write_text(json.dumps(records, indent=2) + '\n')
print(json.dumps({'trees': len(records['trees']), 'entries': sum(row['entries'] for row in records['trees']),
                  'logs': len(records['logs']), 'correctedImplementationFiles': names}, indent=2))
