from pathlib import Path
import hashlib
import json
import shutil

helper = Path('/home/toshiba/aew/task128-kernel-archive.py')
exec(helper.read_text().split("for name in ['core', 'browser', 'crash', 'interruption']:")[0])
repo = Path('/home/toshiba/aew/worktrees/task136-file-parser')
out = repo / 'docs/fixtures/loredock-file-parser'
out.mkdir()
records = {'schemaVersion': 'loredock-file-parser-development/1', 'resourceQualification': False,
           'realModelCalls': 0, 'controlledModelCalls': 0, 'applicationCatalogs': 0,
           'observedCommit': '5036ad57dbe39cd9dd66de7b44ba624ec11510e8',
           'trees': [], 'logs': [], 'assessment': json.loads((base / 'task136-parser-assessment-first.json').read_text())}
review = base / 'task136-parser-review-inputs'
review.mkdir()
for p in [Path(__file__), base / 'task136-parser-first-launch.py', base / 'task136-parser-retention-first.json',
          base / 'task136-parser-assessment-first.json', base / 'task136-pre-observation-static.json',
          base / 'task135-design-ci-review.json', base / 'task135-design-static-first.json',
          base / 'task135-design-import-review.json']:
    shutil.copy2(p, review / p.name)
shutil.copy2(base / 'toolchain/task136-node-minimum/identity.json', review / 'minimum-node-identity.json')
shutil.copy2(base / 'toolchain/task136-node-minimum/SHASUMS256.txt', review / 'minimum-node-SHASUMS256.txt')
shutil.copy2(repo / 'apps/loredock/tests/file-parser.test.ts', review / 'final-file-parser.test.ts')
for name, source in [('parser-first', base / 'task136-parser-first'),
                     ('typecheck-first-inputs', base / 'task136-first-typecheck-inputs'),
                     ('source-loading-first-inputs', base / 'task136-first-source-loading-inputs'),
                     ('review-inputs', review)]:
    tree(name, source)
for p in sorted(base.glob('task136-*.log')):
    log(p.stem, p)
for event in ['push', 'pr']:
    log('task135-design-ci-' + event, base / ('task135-design-ci-' + event + '.log'))
retained = json.loads((base / 'task136-parser-retention-first.json').read_text())
for name, identity in retained['files'].items():
    raw = (base / 'task136-parser-first' / name).read_bytes()
    assert len(raw) == identity['bytes'] and sha(raw) == identity['sha256'], name
records['rawEntriesUnchanged'] = retained['entries']
(out / 'records.json').write_text(json.dumps(records, indent=2) + '\n')
print(json.dumps({'trees': len(records['trees']), 'entries': sum(row['entries'] for row in records['trees']),
                  'logs': len(records['logs']), 'rawEntriesUnchanged': retained['entries']}, indent=2))
