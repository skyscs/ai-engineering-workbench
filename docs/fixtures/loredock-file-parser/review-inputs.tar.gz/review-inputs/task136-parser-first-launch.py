from pathlib import Path
import hashlib
import json
import os
import shutil
import signal
import subprocess
import time

root = Path('/home/toshiba/aew/worktrees/task136-file-parser')
out = Path('/home/toshiba/aew/task136-parser-first')
out.mkdir()
inputs = out / 'inputs'
inputs.mkdir()
node = Path('/home/toshiba/aew/toolchain/node-v22.23.2-linux-x64/bin/node')
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root)
sha = lambda raw: hashlib.sha256(raw).hexdigest()
execution = json.loads(Path('/home/toshiba/aew/task134-browser-first-inputs/execution.json').read_bytes())
names = set(execution['workspaceModules'])
names.update(str(p.relative_to(root)) for p in (root / 'apps/loredock/dist').glob('file-parser*.js'))
names.update(str(p.relative_to(root)) for p in (root / 'apps/loredock/src').glob('*.ts'))
names.update(['pnpm-lock.yaml', 'package.json', 'apps/loredock/package.json', 'apps/loredock/runtime/file-parser-source.mjs',
              'docs/loredock/FILE_PARSER_ADAPTER.md', 'scripts/loredock-file-parser/probe.mjs',
              'scripts/loredock-file-parser/assess.mjs', 'apps/loredock/tests/file-parser.test.ts',
              'scripts/tests/loredock-file-parser.test.mjs'])
manifest = {}
for name in sorted(names):
    source = root / name
    target = inputs / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)
    raw = source.read_bytes()
    manifest[name] = {'bytes': len(raw), 'sha256': sha(raw)}
compiler = (root / 'apps/loredock/node_modules/typescript/lib/typescript.js').resolve()
shutil.copy2(compiler, inputs / 'typescript.js')
identity = {'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
            'node': str(node), 'nodeSha256': sha(node.read_bytes()), 'compiler': str(compiler),
            'compilerSha256': sha(compiler.read_bytes()), 'modules': manifest,
            'resourceQualification': False, 'ownerWallMs': 30000, 'ownerCleanupMs': 2000}
(out / 'execution.json').write_text(json.dumps(identity, indent=2) + '\n')
began = time.monotonic()
report = {'startedUtc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), 'timeout': False, 'survivors': []}
with (out / 'stdout.log').open('xb') as stdout, (out / 'stderr.log').open('xb') as stderr:
    child = subprocess.Popen([str(node), str(root / 'scripts/loredock-file-parser/probe.mjs'), str(out / 'run')],
                             cwd=root, env={'PATH': '/usr/bin:/bin', 'LANG': 'C.UTF-8'},
                             stdout=stdout, stderr=stderr, start_new_session=True)
    report['pid'] = child.pid
    try:
        child.wait(timeout=30)
    except subprocess.TimeoutExpired:
        report['timeout'] = True
        os.killpg(child.pid, signal.SIGTERM)
        try:
            child.wait(timeout=2)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid, signal.SIGKILL)
            child.wait(timeout=2)
    report['exitCode'] = child.returncode
for item in Path('/proc').iterdir():
    if not item.name.isdecimal():
        continue
    try:
        stat = (item / 'stat').read_text().rsplit(')', 1)[1].split()
        if int(stat[2]) == child.pid:
            report['survivors'].append(int(item.name))
    except (FileNotFoundError, ProcessLookupError):
        pass
report['elapsedMs'] = (time.monotonic() - began) * 1000
(out / 'owner.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
assert report['exitCode'] == 0 and not report['timeout'] and not report['survivors'], report
