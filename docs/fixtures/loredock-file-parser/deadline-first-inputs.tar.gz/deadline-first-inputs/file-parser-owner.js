import { randomUUID } from 'node:crypto';
import { decodeParserReply, encodeParserFrame, fileParserDigest, fileParserLimits, fileParserProtocol, FileParserError, requireParser, validateParserFacts, validateParserInput } from './file-parser-protocol.js';
export class FileParserOwner {
    dependencies;
    generation = randomUUID();
    state = 'new';
    identity;
    worker;
    initializing;
    initialization = new AbortController();
    pending;
    joining;
    stopped;
    exit;
    exited = false;
    exitCode = null;
    threadId = null;
    sequence = 0;
    terminalCode = null;
    cleanupIncomplete = false;
    workerError = null;
    outputBytes = 0;
    cleanupMs;
    constructor(dependencies) {
        this.dependencies = dependencies;
        this.cleanupMs = dependencies.cleanupMs ?? fileParserLimits.cleanupMs;
        requireParser(Number.isSafeInteger(this.cleanupMs) && this.cleanupMs > 0 && this.cleanupMs <= fileParserLimits.cleanupMs, 'PARSER_OPTIONS');
    }
    operation(options) {
        requireParser(options && Number.isFinite(options.deadline) && options.deadline > performance.now()
            && options.deadline - performance.now() <= fileParserLimits.wallMs, 'PARSER_DEADLINE');
        requireParser(options.signal === undefined || options.signal instanceof AbortSignal, 'PARSER_OPTIONS');
        requireParser(!options.signal?.aborted, 'PARSER_CANCELLED');
    }
    waiting(options, request) {
        return new Promise((resolve, reject) => {
            const abort = () => this.fail(new FileParserError('PARSER_CANCELLED'));
            const timer = setTimeout(() => this.fail(new FileParserError('PARSER_DEADLINE')), Math.max(0, options.deadline - performance.now()));
            options.signal?.addEventListener('abort', abort, { once: true });
            this.pending = { resolve: value => resolve(value), reject,
                release: () => { clearTimeout(timer); options.signal?.removeEventListener('abort', abort); }, ...(request ? { request } : {}) };
        });
    }
    async start(options) {
        requireParser(this.state === 'new', 'PARSER_STATE');
        this.operation(options);
        this.state = 'starting';
        const ready = this.waiting(options);
        this.initializing = this.initialize();
        void this.initializing.catch(() => this.fail(new FileParserError('PARSER_START_FAILED')));
        return ready;
    }
    async initialize() {
        const identity = await this.dependencies.identify(this.initialization.signal);
        requireParser(/^[a-f0-9]{64}$/.test(identity), 'PARSER_IDENTITY');
        if (this.state !== 'starting')
            return;
        this.identity = identity;
        const worker = this.dependencies.spawn(this.generation);
        this.worker = worker;
        this.threadId = worker.threadId;
        this.exit = new Promise(resolve => worker.once('exit', code => {
            this.exited = true;
            this.exitCode = code;
            resolve();
            if (this.state !== 'stopping')
                this.fail(new FileParserError('PARSER_EXIT'));
        }));
        worker.on('message', this.message);
        worker.on('messageerror', this.messageError);
        worker.on('error', this.error);
        worker.stdout?.on('data', this.output);
        worker.stderr?.on('data', this.output);
    }
    output = (value) => {
        this.outputBytes = Math.min(4097, this.outputBytes + value.byteLength);
        if (this.outputBytes > 4096)
            this.fail(new FileParserError('PARSER_OUTPUT_LIMIT'));
    };
    messageError = () => this.fail(new FileParserError('PARSER_MESSAGE_ERROR'));
    error = (error) => {
        const safe = (value) => typeof value === 'string' && /^[A-Za-z0-9_]{1,80}$/.test(value) ? value : null;
        this.workerError = { name: safe(error.name) ?? 'Error', code: safe(error.code) };
        this.fail(new FileParserError('PARSER_WORKER_ERROR'));
    };
    message = (frame) => {
        if (this.state === 'stopping' || this.state === 'closed')
            return;
        try {
            const reply = decodeParserReply(frame), pending = this.pending;
            requireParser(reply.generation === this.generation && reply.identity === this.identity && pending);
            if (reply.type === 'ready') {
                requireParser(this.state === 'starting' && !pending.request);
                pending.release();
                this.pending = undefined;
                this.state = 'ready';
                pending.resolve();
                return;
            }
            const request = pending.request;
            requireParser(this.state === 'busy' && request && reply.id === request.id && reply.digest === request.digest);
            if (reply.type === 'error')
                throw new FileParserError(reply.code);
            validateParserFacts(reply.facts, request.content);
            pending.release();
            this.pending = undefined;
            this.state = 'ready';
            pending.resolve(reply.facts);
        }
        catch (error) {
            this.fail(error instanceof FileParserError ? error : new FileParserError('PARSER_PROTOCOL'));
        }
    };
    async parse(path, content, options) {
        // Reject before validating/encoding text or retaining a second caller's document.
        requireParser(this.state !== 'busy' && this.state !== 'starting', 'PARSER_BUSY');
        requireParser(this.state === 'ready' && this.worker && this.identity, 'PARSER_STATE');
        this.operation(options);
        validateParserInput(path, content);
        requireParser(this.sequence < Number.MAX_SAFE_INTEGER, 'PARSER_SEQUENCE');
        const request = { version: fileParserProtocol, generation: this.generation, identity: this.identity,
            type: 'parse', id: ++this.sequence, path, content, digest: fileParserDigest(path, content) };
        const frame = encodeParserFrame(request, fileParserLimits.requestBytes);
        // Encoding time consumes the same absolute deadline.
        this.operation(options);
        this.state = 'busy';
        const result = this.waiting(options, request);
        try {
            this.worker.postMessage(frame, [frame]);
        }
        catch {
            this.fail(new FileParserError('PARSER_SEND_FAILED'));
        }
        return result;
    }
    fail(error) { void this.close(error).catch(() => undefined); }
    close(error) {
        if (this.stopped)
            return this.stopped;
        this.state = 'stopping';
        this.terminalCode = error.code;
        this.initialization.abort();
        const pending = this.pending;
        this.pending = undefined;
        pending?.release();
        this.joining = (async () => {
            await this.initializing?.catch(() => undefined);
            if (this.worker && !this.exited) {
                // An unsuccessful termination request does not prove that the thread exited.
                void this.worker.terminate().catch(() => { this.cleanupIncomplete = true; });
                await this.exit;
            }
            if (this.worker) {
                this.worker.off('message', this.message);
                this.worker.off('messageerror', this.messageError);
                this.worker.off('error', this.error);
                this.worker.stdout?.off('data', this.output);
                this.worker.stderr?.off('data', this.output);
            }
            this.worker = undefined;
            this.identity = undefined;
            this.state = 'closed';
        })();
        this.stopped = new Promise((resolve, reject) => {
            const timer = setTimeout(() => { this.cleanupIncomplete = true; reject(new FileParserError('PARSER_CLEANUP_TIMEOUT')); }, this.cleanupMs);
            void this.joining.then(() => { clearTimeout(timer); resolve(); }, () => { clearTimeout(timer); this.cleanupIncomplete = true; reject(new FileParserError('PARSER_CLEANUP_FAILED')); });
        });
        // Settlement normally follows exit. On cleanup timeout, ownership remains visible.
        void this.stopped.then(() => pending?.reject(error), failure => pending?.reject(failure));
        void this.stopped.catch(() => undefined);
        return this.stopped;
    }
    stop() { return this.close(new FileParserError('PARSER_STOPPED')); }
    snapshot() {
        return { generation: this.generation, state: this.state, threadId: this.threadId,
            owned: Boolean(this.worker && !this.exited), exitCode: this.exitCode, requests: this.sequence,
            terminalCode: this.terminalCode, cleanupIncomplete: this.cleanupIncomplete,
            workerError: this.workerError ? { ...this.workerError } : null, outputBytes: this.outputBytes };
    }
}
