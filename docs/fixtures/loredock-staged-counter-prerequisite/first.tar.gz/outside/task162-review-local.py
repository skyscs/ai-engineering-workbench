"""Review the closed local check and immutable inputs without executing a workload."""
from pathlib import Path
import hashlib
import json
import re
import subprocess

root = Path('/home/toshiba/aew/worktrees/task162-staged-counter-prerequisite')
outer = root.parent.parent
log = outer / 'task162-full-check.log'
raw = log.read_bytes()
text = raw.decode()
review = json.loads((outer / 'task162-source-review.json').read_text())
for row in review['sources']:
    assert hashlib.sha256((root / row['path']).read_bytes()).hexdigest() == row['sha256']
groups = list(map(int, re.findall(r'# tests (\d+)', text)))
assert groups == [17, 18, 43, 728, 57, 374]
for name in ('fail', 'cancelled', 'skipped'):
    assert list(map(int, re.findall(r'# ' + name + r' (\d+)', text))) == [0] * 6
assert len(re.findall(r'typecheck: Done', text)) == 10
assert len(re.findall(r'build: Done', text[text.rfind('# tests '):])) == 10
assert 'Ran 24 tests' in text and 'Ran 28 tests' in text
baseline = outer / 'worktrees/task147-container-inputs'
paths = sorted([*root.glob('apps/*/dist/**/*.js'), *root.glob('packages/*/dist/**/*.js')])
assert len(paths) == 148
for path in paths:
    assert path.read_bytes() == (baseline / path.relative_to(root)).read_bytes(), str(path)
links, broken = [], []
for path in [*root.glob('*.md'), *root.glob('docs/**/*.md'), *root.glob('tasks/*.md')]:
    content = re.sub(r'`[^`\n]*`', '', path.read_text())
    for match in re.finditer(r'\]\(([^)]+)\)', content):
        target = match.group(1).split('#')[0]
        if not target or re.match(r'[a-z]+:', target) or target.startswith('/') or ' ' in target:
            continue
        links.append(target)
        if not (path.parent / target).exists():
            broken.append([str(path.relative_to(root)), target])
assert not broken, broken
normal = outer / 'ai-engineering-workbench-v0.1'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=normal, text=True).strip() == '592bbc085d9405db86461d47fda5f3382bbaccde'
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=normal).strip()
result = {'task': 162, 'fullTests': sum(groups), 'testGroups': groups, 'pythonCases': 24, 'focusedNodeCases': 12,
          'priorPythonCases': [16, 28, 4, 18, 34, 28, 20, 20, 16], 'failures': 0, 'cancelled': 0, 'skipped': 0,
          'typechecks': 10, 'finalBuilds': 10, 'fullCheckLog': str(log), 'fullCheckBytes': len(raw),
          'fullCheckSha256': hashlib.sha256(raw).hexdigest(), 'sources': review['sources'],
          'sourceHashesStable': True, 'unchangedLoreDockModules': 95, 'unchangedTotalEmittedModules': len(paths),
          'localLinks': len(links), 'brokenLinks': broken, 'normalCheckoutUnchanged': True,
          'productAndFrozenInputsUnchanged': True, 'diffReviewed': True, 'liveAttemptStarted': False,
          'linkReviewNote': 'Inline code examples are excluded; all actual relative Markdown targets resolve.'}
(outer / 'task162-local-check-review.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: value for key, value in result.items() if key != 'sources'}))
