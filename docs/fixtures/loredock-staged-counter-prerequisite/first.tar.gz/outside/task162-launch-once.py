"""Consume the separately sealed Task 162 launch exactly once."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time

sys.dont_write_bytecode = True
root = Path("/home/toshiba/aew")
seal = json.loads((root / "task162-launch-seal.json").read_text())
manifest = Path(seal["manifest"])
assert not Path(seal["firstOutput"]).exists()
assert not Path(seal["firstOutput"] + ".claim").exists()
helper = manifest.parent / "probe.py"
spec = importlib.util.spec_from_file_location("sealed_direct_probe", helper)
probe = importlib.util.module_from_spec(spec)
spec.loader.exec_module(probe)
acquisition, manifest_data = probe.bootstrap(manifest, seal["sha256"])
profile_path = root / 'task162-runtime-profile.json'
assert acquisition.digest(profile_path) == manifest_data['runtimeProfileSha256']
profile = json.loads(profile_path.read_text())
def check_profile():
    path = Path(profile['path'])
    info = path.stat()
    assert hashlib.sha256(path.read_bytes()).hexdigest() == profile['sha256']
    assert info.st_size == profile['bytes'] and info.st_uid == profile['uid'] and info.st_gid == profile['gid']
    assert oct(info.st_mode & 0o7777) == profile['mode']
    assert os.uname().release == profile['kernelRelease']
    assert Path('/proc/sys/kernel/random/boot_id').read_text().strip() == profile['bootId']
    for name, value in profile['sysctls'].items():
        assert Path('/proc/sys/kernel/' + name).read_text() == value
check_profile()
command = ["/usr/bin/python3", "-I", "-S", "-B", str(helper), "--run-first", str(manifest), seal["sha256"]]
started = time.monotonic_ns()
acquisition.retain(root / "task162-launch-intent.json", {"manifestSha256": seal["sha256"], "command": command,
    "candidateHead": seal["candidateHead"], "startedAtNs": str(started),
    "status": "Intent retained before the sole launch; outcome is recorded separately."})
record = {"manifestSha256": seal["sha256"], "command": command, "candidateHead": seal["candidateHead"]}
with (root / "task162-staged-counter-launch-first.log").open("xb") as stream:
    try:
        result = subprocess.run(command, stdin=subprocess.DEVNULL, stdout=stream, stderr=subprocess.STDOUT,
            timeout=45, env={"PATH": "/usr/bin:/bin", "LANG": "C.UTF-8", "XDG_RUNTIME_DIR": "/run/user/1000",
                            "DBUS_SESSION_BUS_ADDRESS": "unix:path=/run/user/1000/bus"})
        record.update(exitCode=result.returncode, failure=None)
    except (Exception, KeyboardInterrupt) as error:
        record.update(exitCode=None, failure=type(error).__name__, message=str(error)[:4096])
    stream.flush()
    os.fsync(stream.fileno())
record["durationNs"] = str(time.monotonic_ns() - started)
try:
    check_profile()
    record['runtimeProfileUnchanged'] = True
except (Exception, KeyboardInterrupt) as error:
    record.update(runtimeProfileUnchanged=False, profileCheckError=type(error).__name__)
acquisition.retain(root / "task162-staged-counter-launch-first.json", record)
print(json.dumps(record, separators=(",", ":")))
raise SystemExit(0 if record["exitCode"] == 0 and record["failure"] is None and record["runtimeProfileUnchanged"] else 1)
